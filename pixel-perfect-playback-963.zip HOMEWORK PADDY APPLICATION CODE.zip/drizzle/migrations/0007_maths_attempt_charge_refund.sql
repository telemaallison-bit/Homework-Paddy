CREATE TABLE public.maths_attempts (id uuid PRIMARY KEY, user_id uuid NOT NULL, refunded boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT ON public.maths_attempts TO authenticated;
GRANT ALL ON public.maths_attempts TO service_role;
ALTER TABLE public.maths_attempts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own maths attempts" ON public.maths_attempts FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE OR REPLACE FUNCTION public.begin_maths_attempt(_request_id uuid) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining integer;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(_request_id::text,0));
 IF EXISTS (SELECT 1 FROM public.maths_attempts WHERE id=_request_id) THEN RAISE EXCEPTION 'Request already started'; END IF;
 remaining := public.spend_credit('solve');
 IF remaining < 0 THEN RETURN -1; END IF;
 INSERT INTO public.maths_attempts(id,user_id) VALUES (_request_id,auth.uid());
 RETURN remaining;
END $$;
REVOKE ALL ON FUNCTION public.begin_maths_attempt(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.begin_maths_attempt(uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.refund_maths_attempt(_request_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE owner_id uuid;
BEGIN
 UPDATE public.maths_attempts SET refunded=true WHERE id=_request_id AND refunded=false RETURNING user_id INTO owner_id;
 IF owner_id IS NOT NULL THEN UPDATE public.wallets SET credits=credits+1 WHERE user_id=owner_id; END IF;
END $$;
REVOKE ALL ON FUNCTION public.refund_maths_attempt(uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.refund_maths_attempt(uuid) TO service_role;