CREATE TABLE public.user_security (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  twofa_enabled boolean NOT NULL DEFAULT false,
  backup_codes text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_security TO authenticated;
GRANT ALL ON public.user_security TO service_role;
ALTER TABLE public.user_security ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own security" ON public.user_security FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.suggestions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  category text NOT NULL,
  rating integer NOT NULL,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.suggestions TO authenticated;
GRANT ALL ON public.suggestions TO service_role;
ALTER TABLE public.suggestions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own suggestions insert" ON public.suggestions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own suggestions read" ON public.suggestions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "admin suggestions read" ON public.suggestions FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.set_twofa(_enabled boolean, _codes text[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_security (user_id, twofa_enabled, backup_codes)
  VALUES (auth.uid(), _enabled, _codes)
  ON CONFLICT (user_id) DO UPDATE SET twofa_enabled = _enabled, backup_codes = _codes;
END;
$$;
REVOKE ALL ON FUNCTION public.set_twofa(boolean, text[]) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_twofa(boolean, text[]) TO authenticated;

CREATE OR REPLACE FUNCTION public.use_backup_code(_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ok boolean;
BEGIN
  SELECT _code = ANY(backup_codes) INTO ok FROM public.user_security WHERE user_id = auth.uid() AND twofa_enabled;
  IF ok THEN
    UPDATE public.user_security SET backup_codes = array_remove(backup_codes, _code) WHERE user_id = auth.uid();
  END IF;
  RETURN COALESCE(ok, false);
END;
$$;
REVOKE ALL ON FUNCTION public.use_backup_code(text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.use_backup_code(text) TO authenticated;