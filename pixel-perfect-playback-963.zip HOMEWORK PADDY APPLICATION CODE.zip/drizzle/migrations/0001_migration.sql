create or replace function public.add_credits(_user_id uuid, _n integer) returns integer language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  insert into public.wallets(user_id) values (_user_id) on conflict do nothing;
  update public.wallets set credits = credits + _n where user_id = _user_id returning credits into n;
  return n;
end $$;
revoke execute on function public.add_credits(uuid, integer) from public, anon, authenticated;
grant execute on function public.add_credits(uuid, integer) to service_role;