CREATE TABLE public.ai_access_state (model text PRIMARY KEY, blocked boolean NOT NULL DEFAULT false, reason text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ai_access_state TO service_role;
REVOKE ALL ON public.ai_access_state FROM anon, authenticated;
ALTER TABLE public.ai_access_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service manages AI access state" ON public.ai_access_state FOR ALL TO service_role USING (true) WITH CHECK (true);