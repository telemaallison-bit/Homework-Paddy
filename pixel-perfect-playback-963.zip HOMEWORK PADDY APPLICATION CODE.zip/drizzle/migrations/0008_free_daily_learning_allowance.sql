CREATE TABLE public.daily_learning_allowance (user_id uuid NOT NULL, day date NOT NULL, used integer NOT NULL DEFAULT 0 CHECK(used>=0), bonus integer NOT NULL DEFAULT 0 CHECK(bonus>=0), ad_claims integer NOT NULL DEFAULT 0 CHECK(ad_claims>=0), PRIMARY KEY(user_id,day));
GRANT SELECT ON public.daily_learning_allowance TO authenticated;
GRANT ALL ON public.daily_learning_allowance TO service_role;
ALTER TABLE public.daily_learning_allowance ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own daily allowance" ON public.daily_learning_allowance FOR SELECT TO authenticated USING (user_id=auth.uid());
ALTER TABLE public.maths_attempts ADD COLUMN allowance_day date DEFAULT NULL;
CREATE OR REPLACE FUNCTION public.get_free_solves() RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer; d date := (now() AT TIME ZONE 'Africa/Lagos')::date;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 SELECT greatest(0,3+bonus-used) INTO n FROM public.daily_learning_allowance WHERE user_id=auth.uid() AND day=d;
 RETURN coalesce(n,3);
END $$;
REVOKE ALL ON FUNCTION public.get_free_solves() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.get_free_solves() TO authenticated;
CREATE OR REPLACE FUNCTION public.spend_credit(_feature text) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer; d date := (now() AT TIME ZONE 'Africa/Lagos')::date;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 IF _feature NOT IN ('solve','tryon','spell') THEN RAISE EXCEPTION 'Bad feature'; END IF;
 IF _feature='solve' THEN
  INSERT INTO public.daily_learning_allowance(user_id,day) VALUES(auth.uid(),d) ON CONFLICT DO NOTHING;
  UPDATE public.daily_learning_allowance SET used=used+1 WHERE user_id=auth.uid() AND day=d AND used<3+bonus RETURNING 3+bonus-used INTO n;
  IF n IS NULL THEN RETURN -1; END IF;
 ELSE n:=public.get_free_solves(); END IF;
 INSERT INTO public.usage_events(user_id,kind) VALUES(auth.uid(),_feature);
 RETURN n;
END $$;
CREATE OR REPLACE FUNCTION public.begin_maths_attempt(_request_id uuid) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(_request_id::text,0));
 IF EXISTS(SELECT 1 FROM public.maths_attempts WHERE id=_request_id) THEN RAISE EXCEPTION 'Request already started'; END IF;
 n:=public.spend_credit('solve'); IF n<0 THEN RETURN -1; END IF;
 INSERT INTO public.maths_attempts(id,user_id,allowance_day) VALUES(_request_id,auth.uid(),(now() AT TIME ZONE 'Africa/Lagos')::date);
 RETURN n;
END $$;
CREATE OR REPLACE FUNCTION public.refund_maths_attempt(_request_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE owner_id uuid; d date;
BEGIN
 UPDATE public.maths_attempts SET refunded=true WHERE id=_request_id AND refunded=false RETURNING user_id,allowance_day INTO owner_id,d;
 IF owner_id IS NOT NULL THEN
  IF d IS NOT NULL THEN UPDATE public.daily_learning_allowance SET used=greatest(0,used-1) WHERE user_id=owner_id AND day=d;
  ELSE UPDATE public.wallets SET credits=credits+1 WHERE user_id=owner_id; END IF;
 END IF;
END $$;
REVOKE ALL ON FUNCTION public.refund_maths_attempt(uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.refund_maths_attempt(uuid) TO service_role;
CREATE OR REPLACE FUNCTION public.claim_ad_reward() RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer; d date:=(now() AT TIME ZONE 'Africa/Lagos')::date;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 INSERT INTO public.daily_learning_allowance(user_id,day) VALUES(auth.uid(),d) ON CONFLICT DO NOTHING;
 UPDATE public.daily_learning_allowance SET bonus=bonus+2,ad_claims=ad_claims+1 WHERE user_id=auth.uid() AND day=d AND ad_claims<3 RETURNING greatest(0,3+bonus-used) INTO n;
 IF n IS NULL THEN RETURN -1; END IF;
 INSERT INTO public.usage_events(user_id,kind) VALUES(auth.uid(),'ad'); RETURN n;
END $$;
COMMENT ON TABLE public.wallets IS 'Historical purchased balances preserved; free-for-now solving uses daily_learning_allowance instead.';
COMMENT ON FUNCTION public.add_credits(uuid,integer) IS 'Historical payment support only; purchases disabled while premium is coming soon.';