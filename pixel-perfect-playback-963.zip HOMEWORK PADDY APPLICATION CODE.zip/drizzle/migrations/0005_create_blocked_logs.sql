CREATE TABLE public.blocked_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.blocked_logs TO authenticated;
GRANT ALL ON public.blocked_logs TO service_role;
ALTER TABLE public.blocked_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users log their own blocked attempts" ON public.blocked_logs FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins read blocked logs" ON public.blocked_logs FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));