CREATE TABLE public.hair_tryon_attempts (id uuid PRIMARY KEY, user_id uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT ON public.hair_tryon_attempts TO authenticated;
GRANT ALL ON public.hair_tryon_attempts TO service_role;
ALTER TABLE public.hair_tryon_attempts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own hair attempts" ON public.hair_tryon_attempts FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE OR REPLACE FUNCTION public.begin_hair_tryon(_request_id uuid) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining integer; existing_user uuid;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(_request_id::text, 0));
 SELECT user_id INTO existing_user FROM public.hair_tryon_attempts WHERE id = _request_id;
 IF existing_user IS NOT NULL THEN
  IF existing_user <> auth.uid() THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  SELECT credits INTO remaining FROM public.wallets WHERE user_id = auth.uid();
  RETURN remaining;
 END IF;
 remaining := public.spend_credit('tryon');
 IF remaining < 0 THEN RETURN -1; END IF;
 INSERT INTO public.hair_tryon_attempts(id, user_id) VALUES (_request_id, auth.uid());
 RETURN remaining;
END $$;
REVOKE ALL ON FUNCTION public.begin_hair_tryon(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.begin_hair_tryon(uuid) TO authenticated;