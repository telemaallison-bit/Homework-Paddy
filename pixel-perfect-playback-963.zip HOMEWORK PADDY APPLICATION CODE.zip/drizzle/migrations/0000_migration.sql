create type public.app_role as enum ('admin','user');
create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade not null, role app_role not null, unique(user_id, role));
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create table public.wallets (user_id uuid primary key, credits integer not null default 5 check (credits >= 0), created_at timestamptz not null default now());
grant select on public.wallets to authenticated;
grant all on public.wallets to service_role;
alter table public.wallets enable row level security;
create policy "own wallet" on public.wallets for select to authenticated using (auth.uid() = user_id);

create table public.transactions (id uuid primary key default gen_random_uuid(), user_id uuid not null, amount integer not null, credits_bought integer not null, payment_method text not null check (payment_method in ('Paystack','Flutterwave')), reference text not null unique, date timestamptz not null default now());
grant select on public.transactions to authenticated;
grant all on public.transactions to service_role;
alter table public.transactions enable row level security;
create policy "own tx" on public.transactions for select to authenticated using (auth.uid() = user_id);
create policy "admin tx" on public.transactions for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.usage_events (id uuid primary key default gen_random_uuid(), user_id uuid not null, kind text not null, created_at timestamptz not null default now());
grant select on public.usage_events to authenticated;
grant all on public.usage_events to service_role;
alter table public.usage_events enable row level security;
create policy "own usage" on public.usage_events for select to authenticated using (auth.uid() = user_id);
create policy "admin usage" on public.usage_events for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin wallets" on public.wallets for select to authenticated using (public.has_role(auth.uid(),'admin'));

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.wallets(user_id) values (new.id) on conflict do nothing;
  insert into public.user_roles(user_id, role) values (new.id, 'user') on conflict do nothing;
  if lower(coalesce(new.email,'')) = 'telema.allison@yahoo.com' then
    insert into public.user_roles(user_id, role) values (new.id, 'admin') on conflict do nothing;
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- spend 1 credit atomically
create or replace function public.spend_credit(_feature text) returns integer language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if _feature not in ('solve','tryon','spell') then raise exception 'bad feature'; end if;
  insert into public.wallets(user_id) values (auth.uid()) on conflict do nothing;
  update public.wallets set credits = credits - 1 where user_id = auth.uid() and credits > 0 returning credits into n;
  if n is null then return -1; end if;
  insert into public.usage_events(user_id, kind) values (auth.uid(), _feature);
  return n;
end $$;
revoke execute on function public.spend_credit(text) from public, anon;
grant execute on function public.spend_credit(text) to authenticated;

-- ad reward: 2 credits, max 3 per day
create or replace function public.claim_ad_reward() returns integer language plpgsql security definer set search_path = public as $$
declare c integer; n integer;
begin
  select count(*) into c from public.usage_events where user_id = auth.uid() and kind = 'ad' and created_at > now() - interval '1 day';
  if c >= 3 then return -1; end if;
  insert into public.wallets(user_id) values (auth.uid()) on conflict do nothing;
  update public.wallets set credits = credits + 2 where user_id = auth.uid() returning credits into n;
  insert into public.usage_events(user_id, kind) values (auth.uid(), 'ad');
  return n;
end $$;
revoke execute on function public.claim_ad_reward() from public, anon;
grant execute on function public.claim_ad_reward() to authenticated;