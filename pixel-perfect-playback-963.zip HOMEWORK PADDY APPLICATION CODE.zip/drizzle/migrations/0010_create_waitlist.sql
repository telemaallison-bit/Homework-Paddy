CREATE TABLE public.waitlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  email text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.waitlist TO authenticated;
GRANT ALL ON public.waitlist TO service_role;
ALTER TABLE public.waitlist ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own waitlist insert" ON public.waitlist FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND char_length(email) BETWEEN 5 AND 254);
CREATE POLICY "own waitlist read" ON public.waitlist FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "admin waitlist read" ON public.waitlist FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));