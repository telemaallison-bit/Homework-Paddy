CREATE TABLE public.learning_history (
 id uuid PRIMARY KEY,
 user_id uuid NOT NULL,
 question text NOT NULL,
 topic text NOT NULL,
 answer text NOT NULL,
 solution jsonb NOT NULL,
 level text NOT NULL,
 method text NOT NULL,
 lang text NOT NULL CHECK (lang IN ('en','pcm','yo','ig','ha')),
 feature text NOT NULL CHECK (feature IN ('maths','homework')),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.learning_history TO authenticated;
GRANT ALL ON public.learning_history TO service_role;
ALTER TABLE public.learning_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own solved questions" ON public.learning_history FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE INDEX learning_history_user_date ON public.learning_history(user_id,created_at DESC);
COMMENT ON TABLE public.learning_history IS 'Successful homework and maths solutions only; uploaded images are never stored. History begins when this feature is enabled.';
CREATE FUNCTION public.parent_learning_stats() RETURNS jsonb LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
 WITH mine AS (SELECT *, (created_at AT TIME ZONE 'Africa/Lagos')::date AS day FROM public.learning_history WHERE user_id=auth.uid()),
 days AS (SELECT ((now() AT TIME ZONE 'Africa/Lagos')::date - n)::date AS day FROM generate_series(0,6) n),
 activity AS (SELECT days.day, count(mine.id) AS solved FROM days LEFT JOIN mine ON mine.day=days.day GROUP BY days.day)
 SELECT jsonb_build_object(
 'today',(now() AT TIME ZONE 'Africa/Lagos')::date,
 'total',(SELECT count(*) FROM mine),
 'todaySolved',(SELECT count(*) FROM mine WHERE day=(now() AT TIME ZONE 'Africa/Lagos')::date),
 'weekSolved',(SELECT coalesce(sum(solved),0) FROM activity),
 'activeDays',(SELECT count(*) FROM activity WHERE solved>0),
 'topics',(SELECT count(DISTINCT topic) FROM mine),
 'days',(SELECT jsonb_agg(jsonb_build_object('day',day,'solved',solved) ORDER BY day) FROM activity),
 'levels',(SELECT coalesce(jsonb_agg(jsonb_build_object('level',level,'solved',solved)), '[]'::jsonb) FROM (SELECT level,count(*) AS solved FROM mine GROUP BY level ORDER BY level) l)
 );
$$;
REVOKE ALL ON FUNCTION public.parent_learning_stats() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.parent_learning_stats() TO authenticated, service_role;