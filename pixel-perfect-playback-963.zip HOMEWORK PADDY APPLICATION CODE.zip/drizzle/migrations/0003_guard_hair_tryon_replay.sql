ALTER TABLE public.hair_tryon_attempts ADD COLUMN replayed boolean NOT NULL DEFAULT false;
CREATE OR REPLACE FUNCTION public.begin_hair_tryon_request(_request_id uuid, _replay boolean) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining integer; existing_user uuid; already_replayed boolean;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(_request_id::text, 0));
 SELECT user_id, replayed INTO existing_user, already_replayed FROM public.hair_tryon_attempts WHERE id = _request_id;
 IF existing_user IS NOT NULL THEN
  IF existing_user <> auth.uid() OR NOT _replay OR already_replayed THEN RAISE EXCEPTION 'Request already used'; END IF;
  UPDATE public.hair_tryon_attempts SET replayed = true WHERE id = _request_id;
  SELECT credits INTO remaining FROM public.wallets WHERE user_id = auth.uid(); RETURN remaining;
 END IF;
 IF _replay THEN RAISE EXCEPTION 'Missing original request'; END IF;
 remaining := public.spend_credit('tryon');
 IF remaining < 0 THEN RETURN -1; END IF;
 INSERT INTO public.hair_tryon_attempts(id, user_id) VALUES (_request_id, auth.uid()); RETURN remaining;
END $$;
REVOKE ALL ON FUNCTION public.begin_hair_tryon_request(uuid,boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.begin_hair_tryon_request(uuid,boolean) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.begin_hair_tryon(uuid) FROM authenticated;
COMMENT ON FUNCTION public.begin_hair_tryon(uuid) IS 'DEPRECATED: replaced by begin_hair_tryon_request with replay protection';