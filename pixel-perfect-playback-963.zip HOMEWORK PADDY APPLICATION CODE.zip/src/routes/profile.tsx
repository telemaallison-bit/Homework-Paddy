import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getTwoFAStatus } from "@/lib/twofa.functions";
import { Gate } from "@/components/Gate";
import { Header } from "@/components/Header";
import { Screen } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/app-store";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [
    { title: "My Profile | Homework Paddy" },
    { name: "description", content: "Your Homework Paddy account, tries and settings." },
    { property: "og:title", content: "My Profile | Homework Paddy" },
    { property: "og:description", content: "Your Homework Paddy account, tries and settings." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <Gate><Profile /></Gate>,
});

function Profile() {
  const { session, credits, totalPurchased, name, setName, t } = useApp();
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState(name);
  const [twofaOff, setTwofaOff] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    getTwoFAStatus().then((s) => setTwofaOff(!s.enabled)).catch(() => {});
  }, []);
  const email = session?.user?.email ?? "";
  const since = session?.user?.created_at
    ? new Date(session.user.created_at).toLocaleDateString("en-NG", { day: "numeric", month: "long", year: "numeric" })
    : "";
  const logout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  };
  return (
    <Screen>
      <Header title={t("profile")} />
      <div className="flex flex-col gap-4 p-4">
        {twofaOff && (
          <Link to="/settings" className="rounded-2xl border-2 border-yellow-500 bg-yellow-100 p-4 text-sm font-black text-yellow-900 dark:bg-yellow-950 dark:text-yellow-100">
            {t("twofaBanner")}
          </Link>
        )}
        <div className="flex items-center gap-4">
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-full bg-primary text-2xl font-black text-primary-foreground">
            {(name || email || "?").slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="truncate text-xl font-black">{name || email}</p>
            <p className="truncate text-sm text-muted-foreground">{email}</p>
          </div>
        </div>
        {edit ? (
          <div className="flex gap-2">
            <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={t("editName")} aria-label={t("editName")} className="min-w-0 flex-1 rounded-xl border border-border bg-background p-3" />
            <Button onClick={() => { setName(draft.trim()); setEdit(false); }}>{t("saveName")}</Button>
          </div>
        ) : (
          <Button variant="outline" className="min-h-12" onClick={() => { setDraft(name); setEdit(true); }}>✏️ {t("editName")}</Button>
        )}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-muted p-4">
            <p className="text-3xl font-black">⭐ {credits}</p>
            <p className="text-sm font-semibold text-muted-foreground">{t("triesLeft", { n: credits })}</p>
          </div>
          <div className="rounded-2xl bg-muted p-4">
            <p className="text-3xl font-black">{totalPurchased}</p>
            <p className="text-sm font-semibold text-muted-foreground">{t("totalBought")}</p>
          </div>
        </div>
        <p className="text-sm font-semibold text-muted-foreground">{t("memberSince")}: {since}</p>
        <Button variant="destructive" className="min-h-12 text-base font-bold" onClick={logout}>🚪 {t("logout")}</Button>
      </div>
    </Screen>
  );
}
