import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ExternalLink, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { Gate } from "@/components/Gate";
import { Header } from "@/components/Header";
import { Screen } from "@/components/ui-kit";
import { useApp } from "@/lib/app-store";
import { googleSearchUrl, SUGGESTIONS, youtubeSearchUrl, type SearchResult } from "@/lib/search";
import { searchWeb } from "@/lib/search.functions";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>) => ({ q: typeof s["q"] === "string" ? (s["q"] as string) : "" }),
  head: () => ({
    meta: [
      { title: "Homework Paddy - Search" },
      { name: "description", content: "Search hair styles, barbers and tutorials from the internet." },
      { property: "og:title", content: "Homework Paddy - Search" },
      { property: "og:description", content: "Search hair styles, barbers and tutorials from the internet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { t } = useApp();
  const { q } = Route.useSearch();
  const navigate = useNavigate();
  const [text, setText] = useState(q);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setText(q);
    if (!q.trim()) {
      setResults([]);
      return;
    }
    let alive = true;
    setBusy(true);
    searchWeb({ data: { q: q.trim() } })
      .then((r) => {
        if (alive) setResults(r);
      })
      .catch(() => {
        if (alive) setResults([]);
      })
      .finally(() => {
        if (alive) setBusy(false);
      });
    return () => {
      alive = false;
    };
  }, [q]);

  const go = (query: string) => {
    const trimmed = query.trim();
    if (trimmed.length < 2) return;
    void navigate({ to: "/search", search: { q: trimmed } });
  };

  return (
    <Gate>
      <Screen>
        <Header title={t("searchGo")} />
        <form
          className="flex gap-2 p-4"
          onSubmit={(e) => {
            e.preventDefault();
            go(text);
          }}
        >
          <input
            className="min-w-0 flex-1 rounded-2xl border-2 border-border bg-card p-3 text-base font-semibold"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("searchPh")}
            aria-label={t("searchGo")}
          />
          <button type="submit" className="rounded-2xl bg-primary px-4 text-primary-foreground" aria-label={t("searchGo")}>
            <Search className="h-6 w-6" />
          </button>
        </form>

        {!q && (
          <div className="px-4 pb-4">
            <p className="mb-2 text-sm font-bold text-muted-foreground">{t("searchSug")}</p>
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  className="rounded-full bg-muted px-4 py-2 text-sm font-bold"
                  onClick={() => go(s)}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {busy && <p className="p-4 text-center font-bold text-muted-foreground">{t("searching")}</p>}

        {!busy && q && results.length === 0 && (
          <p className="p-4 text-center font-semibold text-muted-foreground">{t("noResults")}</p>
        )}

        <div className="flex flex-col gap-3 px-4 pb-4">
          {results.map((r) => (
            <a
              key={r.url}
              href={r.url}
              target="_blank"
              rel="noreferrer"
              className="block rounded-2xl border-2 border-border bg-card p-4"
            >
              <p className="font-black">{r.title}</p>
              <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{r.snippet}</p>
              <span className="mt-2 inline-flex items-center gap-1 text-sm font-bold text-primary">
                {t("readMore")} <ExternalLink className="h-4 w-4" />
              </span>
            </a>
          ))}
        </div>

        {q && (
          <div className="flex flex-col gap-2 px-4 pb-8">
            <a
              href={googleSearchUrl(q)}
              target="_blank"
              rel="noreferrer"
              className="rounded-2xl bg-muted p-3 text-center text-base font-bold"
            >
              🔎 {t("searchGoogle")}
            </a>
            <a
              href={youtubeSearchUrl(q)}
              target="_blank"
              rel="noreferrer"
              className="rounded-2xl bg-muted p-3 text-center text-base font-bold"
            >
              ▶️ {t("searchYoutube")}
            </a>
          </div>
        )}
      </Screen>
    </Gate>
  );
}
