import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/hair-try-on")({
  server: { handlers: { POST: async ({ request }) => {
    const { handleHairTryOn } = await import("@/lib/hair-route.server");
    return handleHairTryOn(request);
  } } },
});