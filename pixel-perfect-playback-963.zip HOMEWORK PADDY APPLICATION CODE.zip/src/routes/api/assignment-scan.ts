import { createFileRoute } from '@tanstack/react-router';
import { handleAssignmentScan } from '@/lib/assignment.server';
export const Route=createFileRoute('/api/assignment-scan')({server:{handlers:{POST:({request})=>handleAssignmentScan(request)}}});