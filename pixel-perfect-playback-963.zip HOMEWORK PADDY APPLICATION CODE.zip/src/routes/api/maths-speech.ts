import { createFileRoute } from "@tanstack/react-router";
export const Route = createFileRoute("/api/maths-speech")({ server: { handlers: { POST: async ({ request }) => {
  const { handleMathsSpeech } = await import("@/lib/maths/speech.server");
  return handleMathsSpeech(request);
} } } });