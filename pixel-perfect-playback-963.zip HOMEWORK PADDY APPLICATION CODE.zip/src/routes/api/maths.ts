import { createFileRoute } from "@tanstack/react-router";
export const Route = createFileRoute("/api/maths")({ server: { handlers: { POST: async ({ request }) => {
  const { handleMaths } = await import("@/lib/maths/handler.server");
  return handleMaths(request);
} } } });