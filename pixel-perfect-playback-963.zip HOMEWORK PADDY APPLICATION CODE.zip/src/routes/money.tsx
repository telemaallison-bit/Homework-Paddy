import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { Award, ArrowRight, Check, Coins, Minus, PiggyBank, Plus, RotateCcw, Volume2 } from 'lucide-react';
import { Header } from '@/components/Header';
import { Screen } from '@/components/ui-kit';
import { Button } from '@/components/ui/button';
import { useApp } from '@/lib/app-store';
import { LANGS } from '@/lib/i18n';
import { MONEY_COPY, MONEY_EXTRA } from '@/lib/money-copy';
import { AGE_BANDS, budgetLeft, COIN_VALUE, correctBucket, interestLesson, MONEY_ITEMS, parseProgress, progressKey, TOTAL_COINS, type Bucket } from '@/lib/money';
import banksPicture from '@/assets/money-banks.jpg';

export const Route = createFileRoute('/money')({
  head: () => ({ meta: [
    { title: 'Money Paddy - Five Money Lessons | Homework Paddy' },
    { name: 'description', content: 'Learn needs, wants, saving, budgeting and interest with five playful Nigerian money lessons for ages two to adult.' },
    { property: 'og:title', content: 'Money Paddy - Learn Money from Age 2 to Adult' },
    { property: 'og:description', content: 'Five hands-on money levels with pictures and voice in English, Pidgin, Yoruba, Igbo and Hausa.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' },
  ] }),
  component: MoneyPage,
});
const big = 'min-h-20 h-auto whitespace-normal rounded-lg px-4 py-3 text-lg font-extrabold';
const naira = (n: number) => `₦${n.toLocaleString('en-NG')}`;

function MoneyPage() {
  const { lang, setLang, speak, session, ready, awardCorrectAnswer } = useApp();
  const language = lang ?? 'en';
  const copy = MONEY_COPY[language];
  const extra = MONEY_EXTRA[language];
  const [level, setLevel] = useState(0);
  const [done, setDone] = useState<number[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [storageOk, setStorageOk] = useState(true);
  const [sorted, setSorted] = useState<Record<string, Bucket>>({});
  const [selected, setSelected] = useState<string | null>(null);
  const [coins, setCoins] = useState([0, 0, 0]);
  const [plan, setPlan] = useState([0, 0, 0]);
  const [purchases, setPurchases] = useState<string[]>([]);
  const [story, setStory] = useState<'borrow' | 'save' | null>(null);
  const [source, setSource] = useState<'salary' | 'interest' | null>(null);
  const [feedback, setFeedback] = useState<'success' | 'retry' | null>(null);
  const key = progressKey(session?.user.id);

  useEffect(() => {
    if (!ready) return;
    try { setDone(parseProgress(localStorage.getItem(key))); setStorageOk(true); }
    catch { setDone([]); setStorageOk(false); }
    setLoaded(true);
  }, [ready, key]);

  function finish(ok: boolean) {
    setFeedback(ok ? 'success' : 'retry');
    speak(ok ? copy.success : copy.retry, language);
    if (!ok) return;
    if (feedback !== 'success') awardCorrectAnswer();
    const updated = [...new Set([...done, level])];
    setDone(updated);
    try { localStorage.setItem(key, JSON.stringify(updated)); setStorageOk(true); }
    catch { setStorageOk(false); }
  }
  function move(next: number) { setLevel(next); setFeedback(null); setSelected(null); }
  function reset() {
    setSorted({}); setCoins([0,0,0]); setPlan([0,0,0]); setPurchases([]);
    setStory(null); setSource(null); setFeedback(null); setSelected(null);
  }
  function sort(id: string, bucket: Bucket) {
    setSorted(previous => ({ ...previous, [id]: bucket }));
    setSelected(null); setFeedback(null);
    speak(`${copy.items[MONEY_ITEMS.findIndex(item => item.id === id)] ?? ''}. ${bucket === 'need' ? copy.needs : copy.wants}`, language);
  }
  function adjust(values: number[], index: number, change: number, setter: (value: number[]) => void) {
    setter(values.map((value, i) => i === index ? Math.max(0, value + change) : value)); setFeedback(null);
  }
  const coinsLeft = TOTAL_COINS - coins.reduce((a,b) => a+b, 0);
  const remaining = budgetLeft(plan);
  const shop = [{ id:'food', emoji:'🍲', price:400, label:copy.expenses[0] }, { id:'transport', emoji:'🚌', price:200, label:copy.expenses[1] }, { id:'book', emoji:'📚', price:300, label:copy.expenses[2] }, { id:'sweet', emoji:'🍬', price:250, label:copy.expenses[3] }];
  const chosenTotal = shop.filter(item => purchases.includes(item.id)).reduce((sum,item) => sum+item.price,0);
  const interest = interestLesson(10000, 5, 400);
  const title = copy.titles[level] ?? '';
  const lesson = copy.lessons[level] ?? '';
  if (!ready || !loaded) return <Screen className="home-screen"><Header title="Money Paddy 💰" /><div className="p-4" /></Screen>;

  return <Screen className="home-screen money-screen">
    <Header title="Money Paddy 💰" />
    <main className="space-y-6 p-4 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div><h2 className="text-3xl font-black">Money Paddy 💰</h2><p className="mt-1 font-semibold text-muted-foreground">{copy.subtitle}</p></div>
        <div className="flex flex-wrap gap-2" aria-label="Languages">{LANGS.map(l => <Button key={l.id} variant={language===l.id?'default':'secondary'} className={`${big} min-w-20`} onClick={() => { setLang(l.id); speak(MONEY_COPY[l.id].lessons[level] ?? '', l.id); }}>{l.id.toUpperCase()}</Button>)}</div>
      </div>
      <nav className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-5" aria-label="Money levels">
        {copy.titles.map((name,i) => <Button key={i} variant={level===i?'default':'outline'} className={`${big} justify-start gap-3 text-left`} onClick={() => move(i)}>
          {done.includes(i)?<Award className="h-7 w-7 shrink-0" />:<span className="text-2xl">{i+1}</span>}
          <span className="min-w-0"><span className="block text-sm">{copy.level} {i+1} · {AGE_BANDS[i]}</span>{name}</span>
        </Button>)}
      </nav>
      <section className="space-y-5" aria-label={title}>
        <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-2xl font-black">{copy.level} {level+1}: {title}</h2><Button className={`${big} gap-2`} variant="secondary" onClick={() => speak(`${title}. ${lesson}`, language)}><Volume2 className="h-6 w-6 shrink-0" />{copy.listen}</Button></div>
        <p className="max-w-4xl text-lg leading-relaxed">{lesson}</p>

        {level===0 && <>
          <p className="text-sm text-muted-foreground">{extra.instruction}</p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">{MONEY_ITEMS.map((item,i) => <Button key={item.id} variant={selected===item.id?'default':'outline'} className={`${big} touch-none flex-col gap-2`} aria-pressed={selected===item.id} draggable
            onDragStart={e => e.dataTransfer.setData('text/plain', item.id)}
            onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); setSelected(item.id); }}
            onPointerUp={e => { const target = document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-bucket]'); const bucket=target?.getAttribute('data-bucket'); if (bucket==='need'||bucket==='want') sort(item.id,bucket); }}
            onClick={() => setSelected(item.id)}>
            <span className="text-5xl" aria-hidden>{item.emoji}</span><span>{copy.items[i]}</span>
            {sorted[item.id] && <span className="text-xs">{sorted[item.id]==='need'?copy.needs:copy.wants}</span>}
          </Button>)}</div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">{(['need','want'] as const).map(bucket => <Button key={bucket} data-bucket={bucket} variant="outline" className={`${big} min-h-44 flex-col gap-3 border-2 ${bucket==='need'?'bg-secondary text-secondary-foreground border-primary':'bg-accent text-accent-foreground'}`}
            onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault(); const id=e.dataTransfer.getData('text/plain'); if(MONEY_ITEMS.some(item=>item.id===id)) sort(id,bucket);}}
            onClick={()=>{if(selected)sort(selected,bucket);}}><span className="text-2xl">{bucket==='need'?'🧺':'🎁'} {bucket==='need'?copy.needs:copy.wants}</span><span className="min-h-12 text-4xl">{MONEY_ITEMS.filter(item=>sorted[item.id]===bucket).map(item=>item.emoji).join(' ')}</span></Button>)}</div>
          <Button className={`${big} w-full`} onClick={()=>finish(MONEY_ITEMS.every(item=>correctBucket(item.id,sorted[item.id] ?? (item.bucket==='need'?'want':'need'))))}>{copy.check}</Button>
        </>}

        {level===1 && <>
          <img src={banksPicture} alt={copy.banks.join(', ')} width={1152} height={576} className="mx-auto max-h-72 w-full max-w-3xl rounded-lg object-contain" />
          <p className="text-center text-xl font-black">🪙 {coinsLeft} / {TOTAL_COINS} · {naira(COIN_VALUE)}</p>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">{copy.banks.map((bank,i)=><article key={bank} className="rounded-lg border border-border bg-card p-4 text-center">
            <PiggyBank className={`mx-auto h-14 w-14 ${i===0?'text-tile-1':i===1?'text-tile-4':'text-tile-2'}`} /><h3 className="mt-2 text-xl font-black">{bank}</h3><p className="my-3 text-2xl font-black">{coins[i]} 🪙 · {naira((coins[i]??0)*COIN_VALUE)}</p>
            <div className="grid grid-cols-2 gap-2"><Button variant="secondary" className={big} aria-label={`${copy.remove} ${bank}`} disabled={(coins[i]??0)===0} onClick={()=>adjust(coins,i,-1,setCoins)}><Minus /></Button><Button className={big} aria-label={`${copy.add} ${bank}`} disabled={coinsLeft<=0} onClick={()=>adjust(coins,i,1,setCoins)}><Plus /></Button></div>
          </article>)}</div><Button className={`${big} w-full`} onClick={()=>finish(coinsLeft===0 && coins.every(n=>n>0))}>{copy.check}</Button>
        </>}

        {level===2 && <>
          <p className={`text-2xl font-black ${remaining<0?'text-destructive':'text-primary'}`}>{copy.left}: {naira(remaining)} / ₦1,000</p>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">{[copy.needs,copy.banks[0]??'',copy.wants].map((label,i)=><article className="rounded-lg border border-border bg-card p-4 text-center" key={i}><span className="text-5xl">{['🍲🚌','🐷','🧸'][i]}</span><h3 className="my-2 text-xl font-black">{label}</h3><p className="my-3 text-2xl font-black">{naira(plan[i]??0)}</p><div className="grid grid-cols-2 gap-2"><Button className={big} variant="secondary" disabled={(plan[i]??0)===0} aria-label={`${copy.remove} ${label}`} onClick={()=>adjust(plan,i,-100,setPlan)}><Minus /></Button><Button className={big} disabled={remaining<100} aria-label={`${copy.add} ${label}`} onClick={()=>adjust(plan,i,100,setPlan)}><Plus /></Button></div></article>)}</div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{shop.map(item=><Button key={item.id} variant={purchases.includes(item.id)?'default':'outline'} className={`${big} flex-col gap-2`} aria-pressed={purchases.includes(item.id)} onClick={()=>{setPurchases(previous=>previous.includes(item.id)?previous.filter(id=>id!==item.id):[...previous,item.id]);setFeedback(null);}}><span className="text-4xl">{item.emoji}</span>{item.label}<span>{naira(item.price)}</span></Button>)}</div>
          <p className={chosenTotal>1000?'font-bold text-destructive':'font-bold'}>{copy.total}: {naira(chosenTotal)} / ₦1,000</p>
          <Button className={`${big} w-full`} onClick={()=>finish(remaining===0 && (plan[0]??0)>=600 && (plan[1]??0)>0 && purchases.includes('food') && purchases.includes('transport') && chosenTotal<=(plan[0]??0)+(plan[2]??0))}>{copy.check}</Button>
        </>}

        {level===3 && <>
          <div className="flex flex-wrap items-center justify-center gap-6 py-5 text-3xl font-black"><span>👩🏾 ₦1,000</span><ArrowRight className="text-primary" /><span>👟 ₦1,200</span></div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2"><Button className={`${big} flex-col gap-3`} variant={story==='borrow'?'default':'outline'} onClick={()=>{setStory('borrow');finish(false);}}><span className="text-5xl">🤝</span>{extra.borrow}<span className="text-base">₦1,000 + ₦200 → 👟 → −₦200</span></Button><Button className={`${big} flex-col gap-3`} variant={story==='save'?'default':'outline'} onClick={()=>{setStory('save');finish(true);}}><span className="text-5xl">🐷</span>{extra.save}<span className="text-base">₦1,000 + ₦200 → 👟 → ₦0</span></Button></div>
        </>}

        {level===4 && <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2"><article className="space-y-3 rounded-lg border border-border bg-card p-5 text-center"><Coins className="mx-auto h-16 w-16 text-tile-1" /><h3 className="font-black">{copy.saved}</h3><p className="text-3xl font-black">{source==='salary'?'₦9,600':'₦10,000'}</p><p className="font-semibold">{copy.interest}: {source==='interest'?'₦100':naira(interest.interest)}</p></article><article className="space-y-3 rounded-lg border border-border bg-card p-5 text-center"><span className="text-7xl">👟</span><h3 className="font-black">{copy.luxury}</h3><p className="text-3xl font-black">₦400</p></article></div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2"><Button variant={source==='salary'?'default':'outline'} className={big} onClick={()=>{setSource('salary');finish(false);}}>{extra.salary}</Button><Button variant={source==='interest'?'default':'outline'} className={big} onClick={()=>{setSource('interest');finish(interest.affordable);}}>{copy.buy}</Button></div><p className="text-sm text-muted-foreground">{copy.disclaimer}</p>
        </>}

        {feedback && <div role="status" className={`flex items-center gap-3 rounded-lg p-4 font-bold ${feedback==='success'?'bg-secondary text-secondary-foreground':'bg-accent text-accent-foreground'}`}><span className="text-3xl">{feedback==='success'?'🏅':'💡'}</span><span>{feedback==='success'?`${copy.success} ${extra.badge}!`:copy.retry}</span></div>}
        <div className="flex flex-wrap gap-3"><Button className={`${big} flex-1 gap-2`} variant="secondary" onClick={reset}><RotateCcw />{copy.again}</Button>{level<4 && <Button className={`${big} flex-1 gap-2`} onClick={()=>move(level+1)}>{copy.next}<ArrowRight className="shrink-0" /></Button>}</div>
      </section>
      <footer className="border-t border-border pt-5"><div className="flex flex-wrap gap-3">{copy.titles.map((name,i)=><span key={name} className={`inline-flex items-center gap-2 text-sm font-bold ${done.includes(i)?'text-primary':'text-muted-foreground'}`}><Award className="h-6 w-6" />{i+1}{done.includes(i)&&<Check className="h-4 w-4" />}</span>)}</div>{done.length===5&&<p className="mt-3 font-black">🎉 {copy.complete}</p>}<p className="mt-3 text-sm text-muted-foreground">{done.length} / 5 · {storageOk?extra.local:copy.disclaimer}</p></footer>
    </main>
  </Screen>;
}