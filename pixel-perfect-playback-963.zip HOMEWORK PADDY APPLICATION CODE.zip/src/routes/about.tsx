import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Bird, Screen } from "@/components/ui-kit";
import { useApp } from "@/lib/app-store";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [
    { title: "About | Homework Paddy" },
    { name: "description", content: "Homework Paddy helps Nigerian learners solve homework, try hairstyles and learn spelling in their own language." },
    { property: "og:title", content: "About | Homework Paddy" },
    { property: "og:description", content: "Snap, Try, Learn - No Teacher Needed." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: About,
});

function About() {
  const { t } = useApp();
  return (
    <Screen>
      <Header title={t("about")} />
      <div className="flex flex-col items-center gap-4 p-6 text-center">
        <Bird className="h-28 w-28" />
        <h1 className="text-2xl font-black">Homework Paddy</h1>
        <p className="text-lg font-bold text-muted-foreground">{t("tagline")}</p>
        <p className="max-w-md text-base">
          Homework Paddy helps learners across Nigeria solve homework step by step, try new hairstyles with AI,
          and practice spelling — in English, Pidgin, Yorùbá, Igbo and Hausa. Find barbers near you and buy
          hair and school items from local vendors.
        </p>
      </div>
    </Screen>
  );
}
