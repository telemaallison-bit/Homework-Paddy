import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Header } from "@/components/Header";
import { LangButtons } from "@/components/LangButtons";
import { TwoFASection } from "@/components/TwoFA";
import { Screen } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/app-store";
import { detectLocation } from "@/lib/geo";
import { supabase } from "@/integrations/supabase/client";
import type { Age } from "@/lib/i18n";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [
    { title: "Settings | Homework Paddy" },
    { name: "description", content: "Change your language, level and location settings." },
    { property: "og:title", content: "Settings | Homework Paddy" },
    { property: "og:description", content: "Change your language, level and location settings." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Settings,
});

const AGES: Age[] = ["nursery", "primary", "jss", "sss", "adult"];

function Settings() {
  const { age, setAge, gender, setGender, loc, setLoc, t, speak, rewardGender, setRewardGender } = useApp();
  const [locBusy, setLocBusy] = useState(false);
  const navigate = useNavigate();

  const findMe = async () => {
    if (locBusy) return;
    setLocBusy(true);
    try {
      const l = await detectLocation();
      setLoc(l);
      speak(t("youAreIn", { place: l.label }));
    } catch {
      speak(t("locDenied"));
    } finally {
      setLocBusy(false);
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  };

  return (
    <Screen>
      <Header title={t("settings")} />
      <div className="flex flex-col gap-6 p-4">
        <TwoFASection />
        <section className="flex flex-col gap-2"><h2 className="text-lg font-black">Superstar dancer</h2><div className="grid grid-cols-2 gap-3"><Button variant={rewardGender === 'girl' ? 'secondary' : 'outline'} className="min-h-20" onClick={() => setRewardGender('girl')}>Girl 👧</Button><Button variant={rewardGender === 'boy' ? 'secondary' : 'outline'} className="min-h-20" onClick={() => setRewardGender('boy')}>Boy 👦</Button></div></section>
        <section className="flex flex-col gap-2">
          <h2 className="text-lg font-black">🌍 {t("changeLang")}</h2>
          <LangButtons />
        </section>
        <section className="flex flex-col gap-2">
          <h2 className="text-lg font-black">🎒 {t("changeAge")}</h2>
          <div className="grid grid-cols-2 gap-2">
            {AGES.map((a) => (
              <Button key={a} variant={age === a ? "secondary" : "outline"} className="min-h-12 h-auto whitespace-normal" onClick={() => setAge(a)}>{t(a)}</Button>
            ))}
          </div>
        </section>
        <section className="flex flex-col gap-2">
          <h2 className="text-lg font-black">👤 {t("pickGender")}</h2>
          <div className="grid grid-cols-2 gap-2">
            <Button variant={gender === "female" ? "secondary" : "outline"} className="min-h-12" onClick={() => setGender("female")}>👩🏾 {t("female")}</Button>
            <Button variant={gender === "male" ? "secondary" : "outline"} className="min-h-12" onClick={() => setGender("male")}>👨🏾 {t("male")}</Button>
          </div>
        </section>
        <section className="flex flex-col gap-2">
          <h2 className="text-lg font-black">📍 {t("locAsk")}</h2>
          {loc && <p className="rounded-xl bg-muted p-3 text-sm font-bold">{t("youAreIn", { place: loc.label })}</p>}
          <Button variant="outline" className="min-h-12" disabled={locBusy} onClick={findMe}>{locBusy ? "…" : `📍 ${t("locAsk")}`}</Button>
        </section>
        <Button variant="destructive" className="min-h-12 text-base font-bold" onClick={logout}>🚪 {t("logout")}</Button>
      </div>
    </Screen>
  );
}
