import { createFileRoute, Link } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Suspense, useState } from 'react';
import { BookOpenCheck, CalendarDays, ChevronLeft, ChevronRight, RefreshCw, TrendingUp } from 'lucide-react';
import { Gate } from '@/components/Gate';
import { Header } from '@/components/Header';
import { Bird, Screen } from '@/components/ui-kit';
import { Button } from '@/components/ui/button';
import { MathsSourceNote } from '@/components/MathsSourceNote';
import { MathsDrawing } from '@/components/MathsDrawing';
import { useApp } from '@/lib/app-store';
import { LANGS } from '@/lib/i18n';
import { DASHBOARD_COPY } from '@/lib/parent-dashboard';
import { getParentDashboard } from '@/lib/parent-dashboard.functions';

export const Route=createFileRoute('/parent-dashboard')({
 validateSearch:(search:Record<string,unknown>)=>({page:Math.max(1,Math.min(10000,Math.floor(Number(search['page'])||1)))}),
 head:()=>({meta:[{title:'Parent Dashboard | Homework Paddy'},{name:'description',content:'Follow your child’s saved homework solutions, daily learning activity and progress in five languages.'},{property:'og:title',content:'Parent Dashboard | Homework Paddy'},{property:'og:description',content:'Private solved-question history and daily learning progress for parents.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]}),
 component:ParentPage,
 errorComponent:DashboardError,
});
function DashboardError(){
 const {lang}=useApp();const c=DASHBOARD_COPY[lang??'en'];
 return <Screen className="home-screen"><Header title={c.title}/><main className="flex flex-col gap-4 p-6"><p role="alert">{c.error}</p><Button onClick={()=>window.location.reload()}>{c.retry}</Button></main></Screen>;
}
function ParentPage(){
 const {lang,setLang}=useApp();const c=DASHBOARD_COPY[lang??'en'];
 return <Gate><Screen className="home-screen"><Header title={c.title}/><main className="flex flex-col gap-6 p-4 sm:p-6"><div className="flex items-center gap-3"><Bird className="h-16 w-16 shrink-0"/><h1 className="min-w-0 text-3xl font-black">{c.title}</h1></div><div className="flex flex-wrap gap-2" aria-label="Language">{LANGS.map(l=><Button key={l.id} variant={lang===l.id?'secondary':'outline'} aria-pressed={lang===l.id} className="min-h-12" onClick={()=>setLang(l.id)}>{l.label}</Button>)}</div><Suspense fallback={<p role="status">{c.loading}</p>}><Dashboard/></Suspense></main></Screen></Gate>;
}
function Dashboard(){
 const {lang,session}=useApp();const c=DASHBOARD_COPY[lang??'en'];const {page}=Route.useSearch();const getDashboard=useServerFn(getParentDashboard);
 const {data,refetch,isFetching}=useSuspenseQuery({queryKey:['parent-dashboard',session?.user.id,page],queryFn:()=>getDashboard({data:{page}}),staleTime:0});
 const [expanded,setExpanded]=useState<string|null>(null);
 const stats=data.stats;const max=Math.max(1,...stats.days.map(d=>d.solved));
 const locale=lang==='yo'?'yo-NG':lang==='ig'?'ig-NG':lang==='ha'?'ha-NG':'en-NG';
 const date=(iso:string,weekday=false)=>new Intl.DateTimeFormat(locale,{timeZone:'Africa/Lagos',...(weekday?{weekday:'short'}:{day:'numeric',month:'short',year:'numeric'})}).format(new Date(iso.length===10?iso+'T12:00:00Z':iso));
 const levelName=(level:string)=>level==='Primary'||level==='JSS'||level==='SSS'||level==='University'?c[level]:level;
 return <>
  <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-semibold text-muted-foreground">{date(stats.today)}</p><Button variant="outline" disabled={isFetching} className="min-h-12 gap-2" onClick={()=>void refetch()}><RefreshCw className="h-4 w-4"/>{c.refresh}</Button></div>
  <section className="collection-grid gap-4" aria-label={c.progress}>{[{label:c.today,value:stats.todaySolved,Icon:BookOpenCheck},{label:c.week,value:stats.weekSolved,Icon:CalendarDays},{label:c.total,value:stats.total,Icon:TrendingUp}].map(s=><div key={s.label} className="flex items-start gap-3 rounded-lg border border-border bg-card p-5"><s.Icon className="h-7 w-7 shrink-0 text-primary"/><div className="min-w-0"><p className="text-sm font-bold text-muted-foreground">{s.label}</p><p className="mt-2 text-3xl font-black tabular-nums">{s.value}</p></div></div>)}</section>
  <section className="border-y border-border py-6"><h2 className="mb-5 text-2xl font-black">{c.daily}</h2><div className="grid grid-cols-7 gap-1 sm:gap-3">{stats.days.map(d=><div key={d.day} className="flex min-w-0 flex-col items-center gap-2"><span className="text-sm font-bold tabular-nums">{d.solved}</span><div className="flex h-32 w-full items-end justify-center bg-secondary"><div className="w-3/5 bg-primary" style={{height:`${d.solved/max*100}%`}}/></div><span className="w-full break-words text-center text-xs font-bold">{date(d.day,true)}</span><span className="text-xs text-muted-foreground">{Number(d.day.slice(-2))}</span></div>)}</div></section>
  <section className="flex flex-col gap-4"><h2 className="text-2xl font-black">{c.progress}</h2><div className="flex flex-wrap gap-x-8 gap-y-3"><p><strong>{stats.activeDays}/7</strong> · {c.active}</p><p><strong>{stats.topics}</strong> · {c.topics}</p></div>{stats.levels.map(l=><div key={l.level} className="flex flex-col gap-2"><div className="flex flex-wrap justify-between gap-2"><span className="font-bold">{levelName(l.level)}</span><span>{l.solved} · {c.total}</span></div><progress value={l.solved} max={Math.max(stats.total,1)} aria-label={levelName(l.level)} className="h-3 w-full accent-primary"/></div>)}</section>
  <section className="flex flex-col gap-4" aria-label={c.history}><h2 className="text-2xl font-black">{c.history}</h2>{stats.total===0?<div className="flex flex-col items-start gap-4 border-y border-border py-8"><BookOpenCheck className="h-12 w-12 text-primary"/><p className="text-lg font-bold">{c.empty}</p><Button asChild className="min-h-14"><Link to="/solve">{c.start}</Link></Button></div>:data.history.length===0?<p>{c.noHistory}</p>:data.history.map(row=><article key={row.id} className="flex flex-col gap-4 rounded-lg border border-border bg-card p-4 sm:p-5"><div className="flex flex-wrap justify-between gap-2 text-sm font-bold text-muted-foreground"><span>{row.feature==='maths'?c.maths:c.homework} · {levelName(row.level)}</span><time dateTime={row.created_at}>{date(row.created_at)}</time></div><h3 className="whitespace-pre-wrap text-lg font-black">{row.question}</h3><p className="whitespace-pre-wrap"><strong>{c.answer}: </strong>{row.answer}</p><p className="text-sm text-muted-foreground">{c.original}: {LANGS.find(l=>l.id===row.lang)?.label}</p><Button variant="outline" className="min-h-12 self-start whitespace-normal" aria-expanded={expanded===row.id} onClick={()=>setExpanded(expanded===row.id?null:row.id)}>{expanded===row.id?c.hide:c.explanation}</Button>{expanded===row.id&&<div className="flex flex-col gap-5 border-t border-border pt-4"><ol className="flex flex-col gap-5">{row.solution.steps.map((step,i)=><li key={i} className="flex flex-col gap-2"><h4 className="font-black">{c.step} {i+1} · {step.title}</h4><p>{step.explanation}</p>{step.equation&&<p className="font-bold">{step.equation}</p>}<MathsDrawing drawing={step.drawing}/></li>)}</ol><p><strong>{c.check}: </strong>{row.solution.check}</p><MathsSourceNote method={row.method} topic={row.solution.topic}/></div>}</article>)}</section>
  {data.count>20&&<nav className="flex flex-wrap items-center justify-between gap-3" aria-label={c.page}><Button asChild variant="outline" disabled={page<=1}><Link to="/parent-dashboard" search={{page:Math.max(1,page-1)}} aria-disabled={page<=1} onClick={e=>{if(page<=1)e.preventDefault();}}><ChevronLeft/>{c.previous}</Link></Button><span>{c.page} {page} / {Math.ceil(data.count/20)}</span><Button asChild variant="outline" disabled={page*20>=data.count}><Link to="/parent-dashboard" search={{page:page+1}} aria-disabled={page*20>=data.count} onClick={e=>{if(page*20>=data.count)e.preventDefault();}}>{c.next}<ChevronRight/></Link></Button></nav>}
  <p className="border-t border-border pt-4 text-sm text-muted-foreground">{c.note}</p>
 </>;
}