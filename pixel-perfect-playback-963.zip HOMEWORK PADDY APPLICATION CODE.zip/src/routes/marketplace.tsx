import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Screen } from "@/components/ui-kit";
import { useApp } from "@/lib/app-store";

export const Route = createFileRoute("/marketplace")({
  head: () => ({ meta: [
    { title: "Marketplace | Homework Paddy" },
    { name: "description", content: "Buy hair products, clippers, books and school items from WhatsApp vendors." },
    { property: "og:title", content: "Marketplace | Homework Paddy" },
    { property: "og:description", content: "Hair products, clippers, books and school items from WhatsApp vendors." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Marketplace,
});

const CATS = [
  { key: "womenHair", emoji: "💇🏾‍♀️", items: [
    { name: "Xpression Braiding Hair", price: "₦3,500" },
    { name: "Bone Straight Wig", price: "₦45,000" },
    { name: "Edge Control Gel", price: "₦2,000" },
    { name: "Attachment Bundle (3x)", price: "₦6,500" },
  ] },
  { key: "mensHair", emoji: "💈", items: [
    { name: "Hair Clippers", price: "₦18,000" },
    { name: "Beard Oil", price: "₦4,500" },
    { name: "Durag", price: "₦1,500" },
    { name: "Wave Sponge Brush", price: "₦1,200" },
  ] },
  { key: "books", emoji: "📚", items: [
    { name: "WAEC Past Questions Pack", price: "₦5,000" },
    { name: "JAMB English Textbook", price: "₦3,800" },
    { name: "Things Fall Apart (Novel)", price: "₦2,500" },
  ] },
  { key: "academic", emoji: "🎓", items: [
    { name: "1-hour Online Lesson", price: "₦3,000" },
    { name: "Exam Prep Bundle", price: "₦7,500" },
    { name: "Scientific Calculator", price: "₦9,000" },
  ] },
] as const;

const VENDOR = "2348000000000";

function Marketplace() {
  const { t } = useApp();
  return (
    <Screen>
      <Header title={t("market")} />
      <div className="flex flex-col gap-6 p-4">
        <p role="note" className="rounded-2xl border-2 border-yellow-400 bg-yellow-50 p-4 text-sm font-bold text-yellow-900 dark:bg-yellow-950 dark:text-yellow-100">{t("marketWarn")}</p>
        {CATS.map((c) => (
          <section key={c.key} className="flex flex-col gap-2">
            <h2 className="text-xl font-black">{c.emoji} {t(c.key)}</h2>
            <ul className="collection-grid gap-3">
              {c.items.map((i) => (
                <li key={i.name} className="flex flex-col gap-2 rounded-2xl border border-border bg-card p-3">
                  <p className="text-base font-bold">{i.name}</p>
                  <p className="text-sm font-extrabold text-muted-foreground">{i.price}</p>
                  <a
                    href={`https://wa.me/${VENDOR}?text=${encodeURIComponent(`I want to buy: ${i.name} (${i.price})`)}`}
                    target="_blank" rel="noreferrer"
                    className="rounded-xl bg-primary px-2 py-2 text-center text-sm font-bold text-primary-foreground"
                  >
                    {t("whatsapp")}
                  </a>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </Screen>
  );
}
