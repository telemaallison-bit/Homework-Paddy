import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Camera, Download, ImagePlus, Scissors, ShieldCheck, Star, Volume2 } from "lucide-react";
import { Gate, BannerAd } from "@/components/Gate";
import { Header } from "@/components/Header";
import { Bird, Screen } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/app-store";
import { FASHION_SEARCH, HAIR_COPY, HAIR_STYLES, hairStylesFor, priceRange, styleName, type HairStyle, type StyleCat, type StyleEntry } from "@/lib/hair";
import { InspirationGallery, googleImagesUrl, googleQueryFor } from "@/components/InspirationGallery";
import { ModModal, ReportButton } from "@/components/ModModal";
import { blocksLeft, checkImage, cooldownRemaining, recordBlock } from "@/lib/moderation";
import { supabase } from "@/integrations/supabase/client";
import { streamImage } from "@/lib/stream-image";

export const Route = createFileRoute("/try-on")({
  head: () => ({ meta: [
    { title: "AI Hair Try-On | Homework Paddy" },
    { name: "description", content: "Upload a photo and preview braids, cornrows, an afro and more in your chosen language." },
    { property: "og:title", content: "AI Hair Try-On | Homework Paddy" },
    { property: "og:description", content: "See your new hairstyle with a photo preview in English, Pidgin, Yoruba, Igbo or Hausa." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <Gate><HairTryOn /></Gate>,
});

function readFavs(): HairStyle[] {
  try {
    const raw = localStorage.getItem("ss_favs");
    const j = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(j) ? (j.filter((x) => typeof x === "string") as HairStyle[]) : [];
  } catch { return []; }
}

function HairTryOn() {
  const { lang, gender, session, refreshWallet, setPaywall, speak } = useApp();
  const copy = HAIR_COPY[lang ?? "en"];
  const styles = hairStylesFor(gender);
  const isMale = gender === "male";
  const upload = useRef<HTMLInputElement>(null);
  const camera = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [original, setOriginal] = useState("");
  const [tab, setTab] = useState<StyleCat>("hair");
  const [style, setStyle] = useState<HairStyle>(styles[0]?.id ?? "afro");
  const [favs, setFavs] = useState<HairStyle[]>(readFavs);
  const [result, setResult] = useState("");
  const [resultStyle, setResultStyle] = useState<HairStyle>("braids");
  const [final, setFinal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [view, setView] = useState<"before" | "after">("after");
  const [modOpen, setModOpen] = useState(false);
  const tabStyles = isMale ? styles.filter((s) => s.cat === tab) : styles;
  const favStyles = styles.filter((s) => favs.includes(s.id));
  const selected = styles.find((s) => s.id === style);
  const toggleFav = (id: HairStyle) => {
    const next = favs.includes(id) ? favs.filter((f) => f !== id) : [...favs, id];
    setFavs(next);
    localStorage.setItem("ss_favs", JSON.stringify(next));
    if (!favs.includes(id)) speak(copy.favSaved);
  };
  const pick = async (next?: File) => {
    if (!next) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(next.type) || next.size > 8 * 1024 * 1024 || !next.size) { setError(copy.invalid); return; }
    const coolMs = cooldownRemaining();
    if (coolMs > 0) { setError(copy.cooldown.replace("{n}", String(Math.ceil(coolMs / 60000)))); return; }
    const verdict = await checkImage(next);
    if (!verdict.ok) {
      if (session) await supabase.from("blocked_logs").insert({ user_id: session.user.id, reason: `image_${verdict.reason}` });
      const cooled = recordBlock();
      if (cooled || blocksLeft() === 0) setError(copy.cooldown.replace("{n}", "10"));
      else setModOpen(true);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => { if (typeof reader.result === "string") { setFile(next); setOriginal(reader.result); setResult(""); setError(""); setFinal(false); } };
    reader.readAsDataURL(next);
  };
  const go = async () => {
    if (!file || !session || busy) return;
    setBusy(true); setError(""); setResult(""); setFinal(false); setView("after"); setResultStyle(style);
    const form = new FormData();
    form.set("image", file); form.set("style", style); form.set("lang", lang ?? "en"); form.set("requestId", crypto.randomUUID());
    try {
      await streamImage("/api/hair-try-on", form, (src, complete) => { setResult(src); setFinal(complete); }, undefined, { Authorization: `Bearer ${session.access_token}` });
      speak(`${copy.done} ${selected ? styleName(copy, selected) : ""}`);
    } catch (e) {
      setResult(""); setFinal(false);
      if (e instanceof Error && e.message.includes('"noCredits":true')) setPaywall(true);
      else setError(e instanceof Error ? e.message : "Could not create this look.");
    } finally { await refreshWallet(); setBusy(false); }
  };
  const styleButton = (s: StyleEntry) => (
    <div key={s.id} className="relative">
      <Button variant={style === s.id ? "secondary" : "outline"} aria-pressed={style === s.id} className={`min-h-14 h-auto w-full whitespace-normal border-2 p-3 pr-9 text-base font-bold ${style === s.id ? "border-primary" : "border-border"}`} onClick={() => setStyle(s.id)}>
        {styleName(copy, s)}
      </Button>
      <button type="button" aria-label={copy.saveFav} onClick={() => toggleFav(s.id)} className="absolute right-1.5 top-1.5 rounded-full p-1.5">
        <Star className={`h-5 w-5 ${favs.includes(s.id) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`} />
      </button>
    </div>
  );
  return <Screen>
    <Header title={copy.title} />
    <div className="flex flex-col gap-4 p-4">
      <input ref={upload} type="file" accept="image/jpeg,image/png,image/webp" aria-label={copy.upload} className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
      <input ref={camera} type="file" accept="image/jpeg,image/png,image/webp" capture="user" aria-label="Take face photo" className="hidden" onChange={(e) => { void pick(e.target.files?.[0]); e.target.value = ''; }} />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2"><Button className="h-auto min-h-20 gap-2 whitespace-normal bg-tile-2 p-4 text-base" disabled={busy} onClick={() => camera.current?.click()}><Camera />Take Photo</Button><Button variant="outline" className="h-auto min-h-20 gap-2 whitespace-normal p-4 text-base" disabled={busy} onClick={() => upload.current?.click()}><ImagePlus />Attach from Phone</Button></div>
      {original ? <div className="flex flex-col gap-2">
        {result && <div className="grid grid-cols-2 gap-2" role="group" aria-label={copy.title}>
          <Button variant={view === "before" ? "default" : "outline"} onClick={() => setView("before")}>{copy.before}</Button>
          <Button variant={view === "after" ? "default" : "outline"} onClick={() => setView("after")}>{copy.after}</Button>
        </div>}
        <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
          <img src={view === "after" && result ? result : original} alt={view === "after" && result ? copy.after : copy.before} className={`h-full w-full object-contain transition-[filter] ${view === "after" && result && !final ? "blur-2xl" : "blur-0"}`} />
        </div>
      </div> : <div className="grid aspect-[4/3] place-items-center rounded-lg border-2 border-dashed border-border bg-muted"><Scissors className="h-16 w-16 text-tile-2" /></div>}
      {isMale && <div className="grid grid-cols-2 gap-2" role="tablist" aria-label={copy.choose}>
        <Button role="tab" aria-selected={tab === "hair"} variant={tab === "hair" ? "default" : "outline"} onClick={() => setTab("hair")}>✂️ {copy.tabHair}</Button>
        <Button role="tab" aria-selected={tab === "beard"} variant={tab === "beard" ? "default" : "outline"} onClick={() => setTab("beard")}>🧔🏾 {copy.tabBeard}</Button>
      </div>}
      {favStyles.length > 0 && <fieldset disabled={busy} className="flex flex-col gap-3">
        <legend className="mb-3 text-xl font-extrabold">⭐ {copy.myFavs}</legend>
        <div className="collection-grid gap-2">{favStyles.map(styleButton)}</div>
      </fieldset>}
      <fieldset disabled={busy} className="flex flex-col gap-3">
        <legend className="mb-3 text-xl font-extrabold">{copy.choose}</legend>
        <div className="collection-grid gap-2">{tabStyles.map(styleButton)}</div>
        <Button asChild variant="outline" className="min-h-12 h-auto whitespace-normal text-base font-bold">
          <a href={googleImagesUrl(googleQueryFor(tabStyles.map((s) => s.id)))} target="_blank" rel="noopener noreferrer">{copy.moreOnGoogle}</a>
        </Button>
      </fieldset>
      {!isMale && <Button asChild variant="outline" className="min-h-12 h-auto whitespace-normal border-2 border-tile-4 text-base font-bold">
        <a href={googleImagesUrl(FASHION_SEARCH)} target="_blank" rel="noopener noreferrer" aria-label={copy.fashion}>{copy.fashionLink}</a>
      </Button>}
      <InspirationGallery gender={gender} title={copy.inspo} hint={copy.inspoHint} tryLabel={copy.tryLook} nameOf={(id) => { const s = styles.find((x) => x.id === id) ?? HAIR_STYLES.find((x) => x.id === id); return s ? styleName(copy, s) : id; }} onTry={(id) => { const s = styles.find((x) => x.id === id); if (!s) return; setStyle(id); if (isMale) setTab(s.cat); window.scrollTo({ top: 0, behavior: "smooth" }); }} />
      {selected && <p className="rounded-lg bg-muted p-3 text-center text-sm font-bold">💈 {copy.priceArea.replace("{range}", priceRange(selected))}</p>}
      <Button className="cta h-auto whitespace-normal" disabled={busy || !file} onClick={go}><Scissors />{busy ? copy.busy : copy.try}</Button>
      {busy && <div role="status" className="flex items-center justify-center gap-3"><Bird className="h-16 w-16" /><span className="font-bold">{copy.busy}</span></div>}
      {error && <p role="alert" className="break-words text-base font-bold text-destructive">{error}</p>}
      {result && final && !busy && <div className="flex flex-col gap-3">
        <p role="status" className="text-center text-xl font-extrabold">{copy.done} {(() => { const s = styles.find((x) => x.id === resultStyle); return s ? styleName(copy, s) : ""; })()}</p>
        <div className="grid grid-cols-2 gap-2">
          <Button asChild variant="secondary" className="min-h-12 h-auto whitespace-normal"><a href={result} download={`homework-paddy-${resultStyle}.png`}><Download />{copy.save}</a></Button>
          <Button variant="secondary" className="min-h-12 h-auto whitespace-normal" onClick={() => { const s = styles.find((x) => x.id === resultStyle); speak(`${copy.done} ${s ? styleName(copy, s) : ""}`); }}><Volume2 />{copy.hear}</Button>
        </div>
        <Link to="/marketplace" className="rounded-2xl bg-tile-4 p-4 text-center text-base font-black">🛍️ {copy.buyLook}</Link>
        <ReportButton label={copy.report} thanks={copy.reportThanks} what={`tryon_result:${resultStyle}`} />
      </div>}
      <ModModal open={modOpen} title={copy.modTitle} message={copy.modMsg} button={copy.modBtn} onClose={() => setModOpen(false)} />
      <p className="flex items-start gap-2 text-sm text-muted-foreground"><ShieldCheck className="h-5 w-5 shrink-0" />{copy.privacy}</p>
    </div>
    <BannerAd />
  </Screen>;
}
