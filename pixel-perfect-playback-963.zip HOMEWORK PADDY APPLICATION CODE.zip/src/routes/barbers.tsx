import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { Suspense, lazy, useMemo, useState } from "react";
import { Header } from "@/components/Header";
import { Screen } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/app-store";
import { NG_STATES, barbersInState, filterBarbers } from "@/lib/barbers";

const MapView = lazy(() => import("@/components/MapView"));

export const Route = createFileRoute("/barbers")({
  head: () => ({ meta: [
    { title: "Barbers Near Me | Homework Paddy" },
    { name: "description", content: "Find verified barbers and salons near you anywhere in Nigeria, with prices, ratings and directions." },
    { property: "og:title", content: "Barbers Near Me | Homework Paddy" },
    { property: "og:description", content: "Find verified barbers and salons near you anywhere in Nigeria." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Barbers,
});

function Barbers() {
  const { loc, t } = useApp();
  const [state, setState] = useState<string>(
    loc?.state && (NG_STATES as readonly string[]).includes(loc.state) ? loc.state : "Lagos",
  );
  const [maxKm, setMaxKm] = useState<number | undefined>();
  const [maxPrice, setMaxPrice] = useState<number | undefined>();
  const [minRating, setMinRating] = useState<number | undefined>();
  const user = loc ? { lat: loc.lat, lng: loc.lng } : null;

  const inState = useMemo(() => barbersInState(state), [state]);
  const list = useMemo(
    () => filterBarbers(inState, user, { maxKm, maxPrice, minRating }),
    [inState, user, maxKm, maxPrice, minRating],
  );

  return (
    <Screen>
      <Header title={t("barbers")} />
      <div className="flex flex-col gap-3 p-4">
        <label className="flex flex-col gap-1 text-sm font-bold">
          {t("pickState")}
          <select value={state} onChange={(e) => setState(e.target.value)} className="rounded-xl border border-border bg-background p-3 text-base">
            {NG_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>

        {inState.length === 0 ? (
          <div className="flex flex-col items-center gap-4 rounded-2xl bg-muted p-6 text-center">
            <span className="text-5xl">🚀</span>
            <p className="text-lg font-bold">{t("expanding", { state })}</p>
            <Button asChild className="cta h-auto whitespace-normal">
              <a href="mailto:telema.allison@yahoo.com?subject=I%20want%20to%20be%20the%20first%20barber%20on%20Homework%20Paddy">{t("firstBarber")}</a>
            </Button>
          </div>
        ) : (
          <>
            {!user && <p className="rounded-xl bg-accent p-3 text-sm font-bold">{t("enableLoc")}</p>}
            <div className="collection-grid gap-3">
              <label className="flex flex-col gap-1 text-xs font-bold">
                {t("dist")}
                <select value={maxKm ?? ""} onChange={(e) => setMaxKm(e.target.value ? Number(e.target.value) : undefined)} className="rounded-lg border border-border bg-background p-2 text-sm">
                  <option value="">{t("anyOpt")}</option>
                  <option value="1">1 km</option>
                  <option value="3">3 km</option>
                  <option value="5">5 km</option>
                </select>
              </label>
              <label className="flex flex-col gap-1 text-xs font-bold">
                {t("priceF")}
                <select value={maxPrice ?? ""} onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : undefined)} className="rounded-lg border border-border bg-background p-2 text-sm">
                  <option value="">{t("anyOpt")}</option>
                  <option value="2000">≤ ₦2,000</option>
                  <option value="3000">≤ ₦3,000</option>
                  <option value="5000">≤ ₦5,000</option>
                </select>
              </label>
              <label className="flex flex-col gap-1 text-xs font-bold">
                {t("ratingF")}
                <select value={minRating ?? ""} onChange={(e) => setMinRating(e.target.value ? Number(e.target.value) : undefined)} className="rounded-lg border border-border bg-background p-2 text-sm">
                  <option value="">{t("anyOpt")}</option>
                  <option value="4">4.0+</option>
                  <option value="4.5">4.5+</option>
                </select>
              </label>
            </div>

            <ClientOnly fallback={<div className="grid h-72 w-full place-items-center rounded-lg border border-border bg-muted text-sm font-bold text-muted-foreground">🗺️</div>}>
              <Suspense fallback={<div className="grid h-72 w-full place-items-center rounded-lg border border-border bg-muted text-sm font-bold text-muted-foreground">🗺️</div>}>
                <MapView user={user} barbers={list} />
              </Suspense>
            </ClientOnly>

            <ul className="collection-grid gap-3">
              {list.map((b) => (
                <li key={b.id} className="flex min-w-0 flex-col gap-3 rounded-lg border border-border bg-card p-4">
                  <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2">
                    <div className="min-w-0">
                      <p className="text-lg font-black">{b.name}</p>
                      <p className="text-sm font-semibold text-muted-foreground">
                        {b.area}, {b.city}{b.km != null ? ` · ${t("kmAway", { n: b.km.toFixed(1) })}` : ""}
                      </p>
                    </div>
                    <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-extrabold ${b.open ? "bg-tile-3 text-foreground" : "bg-muted text-muted-foreground"}`}>
                      {b.open ? t("openNow") : t("closedNow")}
                    </span>
                  </div>
                  <p className="text-sm font-bold">⭐ {b.rating.toFixed(1)} · {t("fromPrice", { n: b.priceFrom.toLocaleString() })}</p>
                  <div className="mt-auto grid grid-cols-1 gap-2 min-[400px]:grid-cols-3">
                    <a href={`https://wa.me/${b.phone}`} target="_blank" rel="noreferrer" className="rounded-xl bg-primary px-2 py-2 text-center text-sm font-bold text-primary-foreground">{t("whatsapp")}</a>
                    <a href={`tel:+${b.phone}`} className="rounded-xl bg-muted px-2 py-2 text-center text-sm font-bold">{t("call")}</a>
                    <a href={`https://www.google.com/maps/dir/?api=1&destination=${b.lat},${b.lng}`} target="_blank" rel="noreferrer" className="rounded-xl bg-muted px-2 py-2 text-center text-sm font-bold">{t("directions")}</a>
                  </div>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </Screen>
  );
}
