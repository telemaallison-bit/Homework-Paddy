import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Camera, Check, Loader2, RotateCcw, Volume2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Gate } from "@/components/Gate";
import { Bird, Screen } from "@/components/ui-kit";
import { MathsSourceNote } from "@/components/MathsSourceNote";
import { MathsDrawing } from "@/components/MathsDrawing";
import { NigerianMathsPractice } from "@/components/NigerianMathsPractice";
import { LANGS } from "@/lib/i18n";
import { useApp } from "@/lib/app-store";
import { METHODS, LEVELS, initialMathsLevel, solutionSchema, type Solution, type MathsMethod, type MathsLevel } from "@/lib/maths/model";
import { streamSpeech } from "@/lib/maths/stream-speech";
import { chunkText } from "@/lib/maths/chunk-text";
import { checkPhoto } from "@/lib/photo-check";

export const Route = createFileRoute("/maths")({
  head: () => ({ meta: [
    { title: "Solve Maths · Four Teaching Methods | Homework Paddy" },
    { name: "description", content: "Practise Nigerian everyday maths with worked Pidgin explanations, or solve your own question using four teaching methods from Primary to University." },
    { property: "og:title", content: "Solve Maths | Homework Paddy" },
    { property: "og:description", content: "Nigerian maths problems, written Pidgin worked answers and illustrated, spoken help for your own questions." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }), component: () => <Gate><Maths /></Gate>,
});

function Maths() {
  const { session, age, lang, setLang, credits, setCredits, refreshWallet, setPaywall, t, speak, awardSuperPaddy } = useApp();
  const [level, setLevel] = useState<MathsLevel>(() => initialMathsLevel(age));
  const [method, setMethod] = useState<MathsMethod>("singapore");
  const [question, setQuestion] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [warning, setWarning] = useState("");
  const [photoBusy, setPhotoBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const [solution, setSolution] = useState<Solution | null>(null);
  const [solvedMethod, setSolvedMethod] = useState<MathsMethod>("singapore");
  const [solvedLevel, setSolvedLevel] = useState<MathsLevel>(level);
  const [error, setError] = useState("");
  const [playing, setPlaying] = useState<string | null>(null);
  const audioStop = useRef<AbortController | null>(null);
  useEffect(() => () => audioStop.current?.abort(), []);
  const hasInput = Boolean(question.trim() || image);

  async function photo(file: File) {
    setError(""); setWarning(""); setPhotoBusy(true);
    try {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size > 8 * 1024 * 1024) throw new Error("Choose a JPG, PNG or WebP under 8 MB.");
      const url = URL.createObjectURL(file);
      const data = await new Promise<string>((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
          const scale = Math.min(1, 1280 / Math.max(img.width, img.height));
          const canvas = document.createElement("canvas"); canvas.width = Math.round(img.width * scale); canvas.height = Math.round(img.height * scale);
          const ctx = canvas.getContext("2d");
          URL.revokeObjectURL(url);
          if (!ctx) { reject(new Error("Could not open this photo.")); return; }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height); resolve(canvas.toDataURL("image/jpeg", .85));
        };
        img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Could not read this photo.")); };
        img.src = url;
      });
      setImage(data);
      const issue = await checkPhoto(data);
      if (issue !== "ok") {
        const key = ({ dark: "photoDark", bright: "photoBright", blurry: "photoBlurry", small: "photoSmall" } as const)[issue];
        setWarning(t(key)); speak(t(key));
      }
    } catch (e) { setError(e instanceof Error ? e.message : "Could not open photo."); }
    finally { setPhotoBusy(false); }
  }

  async function solve() {
    if (busy || !hasInput || !session) return;

    audioStop.current?.abort(); setBusy(true); setError(""); setSolution(null);
    let completed = false;
    try {
      const response = await fetch("/api/maths", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` }, body: JSON.stringify({ question, image, method, level, lang: lang ?? "en", requestId: crypto.randomUUID() }) });
      if (!response.ok) {
        const failure = await response.json();

        throw new Error(failure.message ?? "Could not solve now.");
      }
      if (!response.body) throw new Error("The answer did not arrive.");
      const reader = response.body.pipeThrough(new TextDecoderStream()).getReader();
      let pending = "";
      while (true) {
        const chunk = await reader.read(); if (chunk.done) break;
        pending += chunk.value;
        const lines = pending.split("\n"); pending = lines.pop() ?? "";
        for (const line of lines.filter(Boolean)) {
          const event = JSON.parse(line);
          if (event.type === "started") setCredits(Math.max(0, event.credits));
          if (event.type === "error" || event.type === "denied") throw new Error(event.message);
          if (event.type === "result") { setSolution(solutionSchema.parse(event.solution)); setSolvedMethod(method); setSolvedLevel(level); awardSuperPaddy(); completed = true; }
        }
      }
      if (!completed) throw new Error("The answer was interrupted. Please check your connection.");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not solve now."); }
    finally { setBusy(false); await refreshWallet(); }
  }

  async function hear(text: string, id: string) {
    if (!session) return;
    if (playing) { audioStop.current?.abort(); return; }
    const stop = new AbortController(); audioStop.current = stop; setPlaying(id); setError("");
    try { for (const chunk of chunkText(text)) await streamSpeech("/api/maths-speech", chunk, session.access_token, stop.signal); }
    catch (e) { if (!stop.signal.aborted) setError(e instanceof Error ? e.message : "Voice could not play."); }
    finally { setPlaying(null); }
  }
  const chosen = METHODS.find(m => m.id === solvedMethod);
  return <Screen className="home-screen">
    <Header title="Solve Maths" />
    <main className="flex min-w-0 flex-col gap-6 p-4 sm:p-6">
      <div className="flex items-center gap-3"><Bird className="h-16 w-16 shrink-0 object-contain" /><div><h1 className="text-3xl font-black">Solve Maths</h1><p className="text-sm font-semibold text-muted-foreground">One question. A clearer way to understand.</p></div></div>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Explanation language">{LANGS.map(l => <Button key={l.id} variant={lang === l.id ? "secondary" : "outline"} aria-pressed={lang === l.id} disabled={busy} className="h-auto min-h-10 rounded-lg px-3 py-2 text-sm" onClick={() => { setLang(l.id); speak(l.label, l.id); }}>{l.label}</Button>)}</div>
      <div><label htmlFor="maths-level" className="mb-2 block font-bold">Your level</label><select id="maths-level" value={level} disabled={busy} onChange={e => { const l = LEVELS.find(l => l === e.target.value); if (l) setLevel(l); }} className="min-h-12 w-full rounded-lg border border-input bg-card px-3 text-base sm:max-w-xs">{LEVELS.map(l => <option key={l}>{l}</option>)}</select></div>
      <NigerianMathsPractice level={level} disabled={busy} onHear={text => speak(text, "pcm")} onUse={problem => {
        audioStop.current?.abort(); setSolution(null); setPlaying(null); setQuestion(problem.question); setLevel(problem.level); setMethod("waec"); setLang("pcm"); setImage(null); setWarning(""); setError("");
        document.getElementById("maths-question")?.focus();
      }} />
      <section className="flex flex-col gap-4" aria-label="Maths question">
        <div><label htmlFor="maths-question" className="mb-2 block font-bold">Your maths question</label><textarea id="maths-question" rows={3} maxLength={2000} value={question} disabled={busy} onChange={e => setQuestion(e.target.value)} placeholder="e.g. Amina has 24 oranges. She shares them equally among 6 friends. How many does each friend get?" className="w-full rounded-lg border border-input bg-card p-4 text-base leading-relaxed outline-none focus:ring-2 focus:ring-ring" /></div>
        <label className="flex min-h-14 cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-input bg-card p-3 font-bold"><Camera className="h-5 w-5 shrink-0" />{photoBusy ? "Opening photo…" : image ? "Change question photo" : "Upload question photo"}<input type="file" aria-label="Upload question photo" accept="image/jpeg,image/png,image/webp" disabled={busy || photoBusy} className="sr-only" onChange={e => { const file = e.target.files?.[0]; if (file) void photo(file); e.target.value = ""; }} /></label>
        {image && <div className="relative"><img src={image} alt="Your maths question" className="mx-auto max-h-60 w-auto max-w-full rounded-lg object-contain" /><Button variant="secondary" size="icon" aria-label="Remove question photo" className="absolute right-0 top-0" disabled={busy} onClick={() => { setImage(null); setWarning(""); }}><X className="h-4 w-4" /></Button></div>}
        {warning && <div className="flex flex-col gap-2 rounded-lg bg-accent p-3 text-accent-foreground"><p>{warning}</p><Button variant="outline" onClick={() => setWarning("")}>{t("useAnyway")}</Button></div>}
      </section>
      {hasInput && <section aria-label="Teaching methods"><h2 className="mb-3 text-xl font-black">Choose your method</h2><div className="collection-grid gap-3">{METHODS.map(m => <Button key={m.id} variant="outline" aria-pressed={method === m.id} disabled={busy} onClick={() => setMethod(m.id)} className={`h-auto min-h-28 items-start justify-start gap-3 rounded-lg p-4 text-left whitespace-normal ${method === m.id ? "border-primary bg-secondary" : "bg-card"}`}><span className="text-2xl">{m.flag}</span><span className="flex min-w-0 flex-1 flex-col gap-1"><span className="font-extrabold">{m.name}</span>{m.recommended && <span className="text-xs font-bold text-primary">Recommended</span>}<span className="text-sm font-normal text-muted-foreground">{m.detail}</span></span>{method === m.id && <Check className="h-5 w-5 shrink-0 text-primary" />}</Button>)}</div></section>}
      <Button onClick={() => void solve()} disabled={!hasInput || busy || photoBusy || Boolean(warning)} className="h-auto min-h-20 gap-2 rounded-lg px-4 py-3 text-base font-extrabold">{busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <ArrowRight className="h-5 w-5" />}{busy ? "Working through your question…" : "Solve Maths · Free"}</Button>
      {error && <p role="alert" className="font-semibold text-destructive">{error}</p>}
      {busy && <Bird className="mx-auto h-20 w-20" />}
      {solution && <section aria-label="Maths solution" className="flex flex-col gap-5">
        <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-sm font-bold text-primary">{chosen?.name} · {solvedLevel}</p><h2 className="text-2xl font-black">Let’s work it out</h2></div><Button variant="secondary" className="h-auto min-h-11 gap-2 whitespace-normal rounded-lg p-3" onClick={() => void hear([solution.question, ...solution.steps.map(s => `${s.title}. ${s.explanation}. ${s.equation}`), `Answer: ${solution.answer}. ${solution.check}`].join("\n"), "all")}><Volume2 className="h-5 w-5" />{playing ? "Stop voice" : "Hear explanation"}</Button></div>
        <p className="font-semibold">{solution.question}</p>
        {solution.methodNote && <p className="border-l-2 border-primary pl-3 text-sm text-muted-foreground">{solution.methodNote}</p>}
        <ol className="collection-grid items-start gap-4">{solution.steps.map((step, i) => <li key={i} className="flex min-w-0 flex-col gap-3 rounded-lg border border-border bg-card p-4"><div className="flex items-start gap-3"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary text-sm font-black text-primary-foreground">{i + 1}</span><h3 className="min-w-0 flex-1 font-extrabold">{step.title}</h3><Button variant="ghost" size="icon" className="shrink-0" title={`Hear step ${i + 1}`} aria-label={`Hear step ${i + 1}`} onClick={() => void hear(`${step.title}. ${step.explanation}. ${step.equation}`, String(i))}><Volume2 className="h-5 w-5" /></Button></div><p className="text-base leading-relaxed">{step.explanation}</p>{step.equation && <p className="break-words rounded-lg bg-secondary p-3 text-lg font-black text-secondary-foreground">{step.equation}</p>}<MathsDrawing drawing={step.drawing} /></li>)}</ol>
        <div className="flex items-center gap-3 border-y-2 border-primary py-5"><Bird clap className="h-16 w-16 shrink-0 object-contain" /><div className="min-w-0"><p className="text-sm font-bold text-muted-foreground">{t("answer")}</p><p className="break-words text-2xl font-black">{solution.answer}</p><p className="mt-2 text-base">{solution.check}</p></div></div>
        <MathsSourceNote method={solvedMethod} topic={solution.topic} />
        <Button variant="secondary" className="h-auto min-h-12 gap-2 rounded-lg p-3" onClick={() => { audioStop.current?.abort(); setSolution(null); setQuestion(""); setImage(null); setError(""); }}><RotateCcw className="h-5 w-5" />New question</Button>
      </section>}
    </main>
  </Screen>;
}