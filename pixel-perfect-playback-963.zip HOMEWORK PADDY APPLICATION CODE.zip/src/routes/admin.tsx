import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-store";
import { getAdminStats } from "@/lib/wallet.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [
    { title: "Admin | Homework Paddy" },
    { name: "description", content: "Owner dashboard for Homework Paddy." },
    { property: "og:title", content: "Admin | Homework Paddy" },
    { property: "og:description", content: "Owner dashboard for Homework Paddy." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Admin,
});

const NAMES: Record<string, string> = { solve: "Solve Homework", tryon: "Hair & Clothes", spell: "Spelling test" };

function Login() {
  const [email, setEmail] = useState(""); const [pw, setPw] = useState("");
  const [msg, setMsg] = useState(""); const [signup, setSignup] = useState(false);
  const go = async () => {
    setMsg("");
    const r = signup
      ? await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: `${window.location.origin}/admin` } })
      : await supabase.auth.signInWithPassword({ email, password: pw });
    if (r.error) setMsg(r.error.message);
    else if (signup && !r.data.session) setMsg("Check your email to confirm, then sign in.");
  };
  return (
    <div className="mx-auto flex max-w-sm flex-col gap-3 p-6">
      <h1 className="text-2xl font-black">Admin {signup ? "sign up" : "sign in"}</h1>
      <input className="rounded-2xl border-2 border-input p-3" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className="rounded-2xl border-2 border-input p-3" type="password" placeholder="Password" value={pw} onChange={(e) => setPw(e.target.value)} />
      <button className="cta" onClick={go}>{signup ? "Create account" : "Sign in"}</button>
      <button className="text-base font-bold underline" onClick={() => setSignup(!signup)}>{signup ? "I have an account" : "First time? Create account"}</button>
      {msg && <p className="font-bold">{msg}</p>}
    </div>
  );
}

function Stats() {
  const q = useQuery({ queryKey: ["admin-stats"], queryFn: () => getAdminStats() });
  if (q.isLoading) return <p className="p-6">Loading…</p>;
  if (q.error || !q.data) return <p className="p-6">Could not load stats.</p>;
  const s = q.data;
  const card = "rounded-3xl bg-secondary p-4";
  return (
    <div className="mx-auto grid max-w-2xl gap-3 p-4 sm:grid-cols-2">
      <h1 className="text-3xl font-black sm:col-span-2">Homework Paddy Admin</h1>
      <div className={card}><p className="text-base font-bold text-muted-foreground">Total users</p><p className="text-4xl font-black">{s.totalUsers}</p></div>
      <div className={card}><p className="text-base font-bold text-muted-foreground">Credits sold today</p><p className="text-4xl font-black">{s.soldToday}</p></div>
      <div className={`${card} sm:col-span-2`}><p className="text-base font-bold text-muted-foreground">Revenue: Paystack</p><p className="text-4xl font-black">₦{s.revenue.Paystack.toLocaleString()}</p></div>
      <div className={`${card} sm:col-span-2`}>
        <p className="text-base font-bold text-muted-foreground">Most popular feature</p>
        <p className="text-3xl font-black">{s.topFeature ? `${NAMES[s.topFeature.kind] ?? s.topFeature.kind} (${s.topFeature.uses} uses)` : "No uses yet"}</p>
      </div>
    </div>
  );
}

function Admin() {
  const { ready, session, isAdmin } = useApp();
  if (!ready) return null;
  if (!session) return <Login />;
  if (!isAdmin) return (
    <div className="p-6 text-center">
      <p className="text-xl font-bold">This page is for the owner only.</p>
      <button className="cta mt-4" onClick={() => supabase.auth.signOut()}>Sign out</button>
    </div>
  );
  return <Stats />;
}
