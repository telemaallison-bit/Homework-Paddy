import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Gate } from "@/components/Gate";
import { Header } from "@/components/Header";
import { Screen } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/app-store";
import { submitSuggestion } from "@/lib/twofa.functions";
import { containsBlockedText } from "@/lib/moderation";
import type { Lang } from "@/lib/i18n";

export const Route = createFileRoute("/feedback")({
  head: () => ({ meta: [
    { title: "Feedback & Suggestions | Homework Paddy" },
    { name: "description", content: "Share what you think about Homework Paddy - we are listening." },
    { property: "og:title", content: "Feedback & Suggestions | Homework Paddy" },
    { property: "og:description", content: "Share what you think about Homework Paddy - we are listening." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <Gate><Feedback /></Gate>,
});

const WARM: Record<Lang, string> = {
  en: "We appreciate your feedback, our dear user. Your voice makes Homework Paddy better for everyone. Please share what you think, we are listening with respect and love. 🙏",
  pcm: "We appreciate your feedback well-well, our correct customer. Your idea dey make Homework Paddy better for everybody. Abeg talk wetin dey your mind, we dey listen with full respect and love. 🙏",
  yo: "A mọ̀rírì èrò yín, olùfẹ́ wa. Ohùn yín ni ó ń mú Homework Paddy dara si fún gbogbo wa. Ẹ jọ̀wọ́ sọ ohun tí ẹ rò, a ń fetí sí yín pẹ̀lú ọ̀wọ̀ àti ìfẹ́. 🙏",
  ig: "Anyị ji nzaghachi gị kpọrọ ihe, ezigbo onye ahịa anyị. Olu gị na-eme ka Homework Paddy ka mma maka mmadụ niile. Biko kesaa ihe ị chere, anyị na-ege ntị n'ụzọ nkwanye ùgwù na ịhụnanya. 🙏",
  ha: "Muna godiya da ra'ayinku, abokin cinikinmu mai daraja. Muryarku ce ke sa Homework Paddy ya fi kyau ga kowa. Don Allah ku raba abin da kuke tunani, muna sauraron ku da girmamawa da soyayya. 🙏",
};

const FB_LANGS: { id: Lang; label: string }[] = [
  { id: "en", label: "EN" }, { id: "pcm", label: "PG" }, { id: "yo", label: "YO" }, { id: "ig", label: "IG" }, { id: "ha", label: "HA" },
];

const CATS = ["catBug", "catIdea", "catLove", "catOther"] as const;

function Feedback() {
  const { t, lang, speak } = useApp();
  const [fbLang, setFbLang] = useState<Lang>(lang ?? "en");
  const [text, setText] = useState("");
  const [cat, setCat] = useState<(typeof CATS)[number]>("catIdea");
  const [stars, setStars] = useState(5);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");

  const send = async () => {
    if (!text.trim() || busy) return;
    if (containsBlockedText(text)) { setErr(t("modTextWarn")); return; }
    setBusy(true); setErr("");
    try {
      await submitSuggestion({ data: { category: t(cat), rating: stars, message: text } });
      setSent(true);
      speak(t("thanks"));
    } catch {
      setErr(t("wrongCode"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Header title={`💬 ${t("feedback")}`} />
      <div className="flex flex-col gap-4 p-4">
        <div className="flex flex-col gap-2 rounded-2xl bg-muted p-4">
          <div className="flex gap-1">
            {FB_LANGS.map((l) => (
              <button
                key={l.id}
                onClick={() => setFbLang(l.id)}
                className={`rounded-full px-3 py-1 text-xs font-black ${fbLang === l.id ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground"}`}
              >
                {l.label}
              </button>
            ))}
          </div>
          <p className="text-base font-semibold leading-relaxed">{WARM[fbLang]}</p>
        </div>

        {sent ? (
          <p role="status" className="rounded-2xl bg-muted p-6 text-center text-lg font-bold">{t("thanks")} 🙏</p>
        ) : (
          <>
            <div className="flex flex-col gap-2">
              <p className="text-sm font-black">{t("fbCategory")}</p>
              <div className="grid grid-cols-2 gap-2">
                {CATS.map((c) => (
                  <Button key={c} variant={cat === c ? "secondary" : "outline"} className="min-h-12 h-auto whitespace-normal" onClick={() => setCat(c)}>{t(c)}</Button>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <p className="text-sm font-black">{t("fbRating")}</p>
              <div className="flex gap-1" role="radiogroup" aria-label={t("fbRating")}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} onClick={() => setStars(n)} aria-label={`${n} star`} className="text-3xl">
                    {n <= stars ? "⭐" : "☆"}
                  </button>
                ))}
              </div>
            </div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t("feedbackPh")}
              aria-label={t("feedback")}
              rows={5}
              className="rounded-2xl border border-border bg-background p-4 text-base"
            />
            <Button className="cta h-auto" disabled={busy || !text.trim()} onClick={send}>{busy ? "…" : t("send")}</Button>
            {err && <p className="text-sm font-bold text-destructive">{err}</p>}
          </>
        )}
      </div>
    </Screen>
  );
}
