import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Screen } from "@/components/ui-kit";
import { useApp } from "@/lib/app-store";

export const Route = createFileRoute("/support")({
  head: () => ({ meta: [
    { title: "Support | Homework Paddy" },
    { name: "description", content: "Get help with Homework Paddy - tries, payments and sign-in." },
    { property: "og:title", content: "Support | Homework Paddy" },
    { property: "og:description", content: "Get help with tries, payments and sign-in." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Support,
});

const FAQ = [
  { q: "How do free solves work?", a: "Everyone gets 3 homework or maths solves each day, resetting at midnight in Nigeria. Each question counts as one solve. Learning, spelling and hair try-on are free for now." },
  { q: "Can I get more solves?", a: "The short-ad placeholder gives 2 more free solves, up to 3 rewards daily. Real adverts are not connected yet. Unlimited premium is Coming Soon: 3 days for ₦200 or 1 week for ₦500. No payments are taken now." },
  { q: "I paid but my tries did not show", a: "Wait a few seconds and check again. If they still do not show, email us with your payment reference." },
  { q: "Is my photo safe?", a: "Yes. Your photo is only used to create your look and is not saved by us." },
];

function Support() {
  const { t } = useApp();
  return (
    <Screen>
      <Header title={t("support")} />
      <div className="flex flex-col gap-4 p-4">
        <a href="mailto:telema.allison@yahoo.com" className="rounded-2xl bg-primary p-4 text-center text-lg font-black text-primary-foreground">
          ✉️ {t("emailUs")}: telema.allison@yahoo.com
        </a>
        {FAQ.map((f) => (
          <details key={f.q} className="rounded-2xl border border-border bg-card p-4">
            <summary className="cursor-pointer text-base font-bold">{f.q}</summary>
            <p className="pt-2 text-sm text-muted-foreground">{f.a}</p>
          </details>
        ))}
      </div>
    </Screen>
  );
}
