import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { MONEY_COPY } from '@/lib/money-copy';
import { DASHBOARD_COPY } from '@/lib/parent-dashboard';
import { useApp } from "@/lib/app-store";
import { type Age } from "@/lib/i18n";
import { useEffect, useState } from "react";
import { LangButtons } from "@/components/LangButtons";
import { Header } from "@/components/Header";
import { LearnPlay } from "@/components/LearnPlay";
import { InviteParent } from "@/components/InviteParent";
import { Bird, SafeBadge, Screen, Speaker } from "@/components/ui-kit";
import { BannerAd } from "@/components/Gate";
import { googleSearchUrl, TIP_TOPICS, type SearchResult } from "@/lib/search";
import { searchWeb } from "@/lib/search.functions";
import { Button } from "@/components/ui/button";
import childrenArt from '@/assets/homework-paddy-children.jpg.asset.json';
import { AppLogo } from '@/components/AppLogo';
import { ParentHomeOverview } from '@/components/ParentHomeOverview';
import { PARENT_HOME_COPY } from '@/lib/parent-home';
import homeworkArt from '@/assets/engagement/homework-camera-3d.png';
import moneyArt from '@/assets/engagement/money-piggy-3d.png';
import mathsArt from '@/assets/engagement/maths-calculator-3d.png';
import hairArt from '@/assets/engagement/hair-scissors-3d.png';
import spellArt from '@/assets/engagement/spell-talk-3d.png';
import learningArt from '@/assets/engagement/my-learning-3d.png';
import progressArt from '@/assets/engagement/parent-progress-3d.png';

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Homework Paddy - Children's Learning & Homework Assistant" },
      { name: "title", content: "Homework Paddy - Children's Learning & Homework Assistant" },
      { name: "description", content: "Your parent home for saved homework answers, daily learning progress and children's activities in five languages." },
      { property: "og:title", content: "Homework Paddy - Children's Learning & Homework Assistant" },
      { name: "twitter:title", content: "Homework Paddy - Children's Learning & Homework Assistant" },
      { property: "og:description", content: "Follow family learning, revisit saved answers and start homework, maths and Money Paddy activities." },
      { property: "og:image", content: childrenArt.url },
      { name: "twitter:image", content: childrenArt.url },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

const AGES: { id: Age; emoji: string }[] = [
  { id: "nursery", emoji: "👶🏾" }, { id: "primary", emoji: "🧒🏾" }, { id: "jss", emoji: "👦🏾" },
  { id: "sss", emoji: "🎓" }, { id: "adult", emoji: "👩🏾‍🦱" },
];

function Index() {
  const { ready, lang, age, setAge, gender, setGender, t } = useApp();
  const [pickLang, setPickLang] = useState(false);
  if (!ready) return <Screen><div /></Screen>;

  if (!lang)
    return (
      <Screen className="home-screen">
        <div className="flex flex-col items-center gap-2 p-6 pb-2 text-center">
          <Bird className="h-32 w-32" />
           <h1><AppLogo /></h1>
          <p className="text-lg font-semibold text-muted-foreground">Snap, Try, Learn - No Teacher Needed</p>
        </div>
        <div className="p-4"><LangButtons /></div>
      </Screen>
    );

  if (!gender)
    return (
      <Screen className="home-screen">
        <div className="flex items-center gap-3 p-4">
          <Bird className="h-20 w-20" />
          <h1 className="text-2xl font-black">{t("pickGender")}</h1>
        </div>
        <div className="flex flex-col gap-3 p-4">
          <button className="big-btn" onClick={() => setGender("female")}>
            <span className="text-4xl">👩🏾</span>
            <span className="pr-10">{t("female")}</span>
            <Speaker text={t("female")} />
          </button>
          <button className="big-btn" onClick={() => setGender("male")}>
            <span className="text-4xl">👨🏾</span>
            <span className="pr-10">{t("male")}</span>
            <Speaker text={t("male")} />
          </button>
        </div>
      </Screen>
    );

  if (!age)
    return (
      <Screen className="home-screen">
        <div className="flex items-center gap-3 p-4">
          <Bird className="h-20 w-20" />
          <h1 className="text-2xl font-black">{t("pickAge")}</h1>
        </div>
        <div className="flex flex-col gap-3 p-4">
          {AGES.map((a) => (
            <button key={a.id} className="big-btn" onClick={() => setAge(a.id)}>
              <span className="text-4xl">{a.emoji}</span>
              <span className="pr-10">{t(a.id)}</span>
              <Speaker text={t(a.id)} />
            </button>
          ))}
        </div>
      </Screen>
    );

  const tiles = [
    { to: "/solve", key: "solve", image: homeworkArt, card: 'card-homework' },
    { to: "/money", key: "money", image: moneyArt, card: 'card-money' },
    { to: "/maths", key: "Solve Maths", image: mathsArt, card: 'card-maths' },
    { to: "/try-on", key: "tryon", image: hairArt, card: 'card-hair' },
    { to: "/spell", key: "spell", image: spellArt, card: 'card-spell' },
    { to: "/learning", key: "learning", image: learningArt, card: 'card-learning' },
    { to: "/parent-dashboard", key: "parentDashboard", image: progressArt, card: 'card-progress' },
  ] as const;

  return (
    <Screen className="home-screen">
      <Header title="Homework Paddy" back={false} />
      <div className="home-pattern" aria-hidden="true"><span>⭐</span><span>📚</span><span>✏️</span><span>🐷</span><span>⭐</span></div>
      <div className="home-main">
      <div className="flex flex-col gap-5 p-4">
        <div className="flex flex-col items-center gap-3 text-center">
          <img src={childrenArt.url} className="h-32 w-full max-w-sm object-contain sm:h-44" alt="Two smiling children with schoolbooks — Homework Paddy" />
          <h1 className="text-2xl font-bold sm:text-3xl">{PARENT_HOME_COPY[lang].title}</h1>
        </div>
        <ParentHomeOverview />
        <h2 className="text-xl font-bold">{PARENT_HOME_COPY[lang].activities}</h2>
      </div>
      <div className="collection-grid gap-4 p-4">
        {tiles.map(({ to, key, image, card }) => (
          <Link key={key} to={to} className={`tile home-tile ${card}`}>
            <img src={image} alt="" aria-hidden="true" loading="lazy" width={512} height={512} className="home-card-art" />
            <span className="home-card-title">{key==='money'?'Money Paddy 💰':key==='parentDashboard'?DASHBOARD_COPY[lang].title:t(key)}</span>
            {key==='money' && <span className="home-card-subtitle">{MONEY_COPY[lang].subtitle}</span>}
            <Speaker text={key==='money'?`Money Paddy. ${MONEY_COPY[lang].subtitle}`:key==='parentDashboard'?DASHBOARD_COPY[lang].title:t(key)} />
          </Link>
        ))}
      </div>
      <LearnPlay />
      <InviteParent />
      <div className="grid grid-cols-1 gap-2 px-4 sm:grid-cols-2">
        <Button variant="secondary" className="h-auto min-h-12 whitespace-normal rounded-lg p-3 text-base font-bold" onClick={() => setPickLang((v) => !v)}>🌍 {t("changeLang")}</Button>
        <Button variant="secondary" className="h-auto min-h-12 whitespace-normal rounded-lg p-3 text-base font-bold" onClick={() => setAge(null)}>🎒 {t("changeAge")}</Button>
      </div>
      {pickLang && <div className="p-4"><LangButtons onPicked={() => setPickLang(false)} /></div>}
      <SearchBar />
      <HairTips />
      <div className="p-4"><SafeBadge /></div>
      <BannerAd />
      </div>
    </Screen>
  );
}

function SearchBar() {
  const { t } = useApp();
  const navigate = useNavigate();
  return (
    <div className="px-4 pb-2">
      <Button variant="outline"
        className="h-auto min-h-12 w-full justify-start gap-2 rounded-lg border border-border bg-card p-3 text-left text-sm font-semibold text-muted-foreground"
        onClick={() => void navigate({ to: "/search", search: { q: "" } })}
        aria-label={t("searchGo")}
      >
        <Search className="h-5 w-5 shrink-0" />
        <span className="min-w-0 whitespace-normal">{t("searchPh")}</span>
      </Button>
    </div>
  );
}

function HairTips() {
  const { t } = useApp();
  const [tips, setTips] = useState<{ emoji: string; query: string; result: SearchResult | null }[]>([]);
  useEffect(() => {
    let alive = true;
    void Promise.all(TIP_TOPICS.map(async topic => {
      const results = await searchWeb({ data: { q: topic.query } }).catch(() => [] as SearchResult[]);
      return { emoji: topic.emoji, query: topic.query, result: results[0] ?? null };
    })).then(rows => { if (alive) setTips(rows); });
    return () => { alive = false; };
  }, []);
  return <div className="px-4 pb-2"><p className="mb-2 text-base font-black">{t('tipsTitle')}</p><div className="collection-grid gap-3">{tips.map(tip => <a key={tip.query} href={tip.result?.url ?? googleSearchUrl(tip.query)} target="_blank" rel="noreferrer" className="rounded-lg border border-border bg-card p-4"><p className="font-bold">{tip.emoji} {tip.result?.title ?? tip.query}</p>{tip.result && <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{tip.result.snippet}</p>}<p className="mt-1 text-xs font-semibold text-primary">{t('tipsFrom')}</p></a>)}</div></div>;
}
