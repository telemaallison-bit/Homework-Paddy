import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Mic, Volume2 } from "lucide-react";
import { useApp } from "@/lib/app-store";
import { Bird, Screen } from "@/components/ui-kit";
import { Header } from "@/components/Header";
import { Gate } from "@/components/Gate";
import { Button } from '@/components/ui/button';
import { pronunciationScore, correctTyping } from '@/lib/spelling-score';

export const Route = createFileRoute("/spell")({
  head: () => ({ meta: [
    { title: "Spell & Talk | Homework Paddy" },
    { name: "description", content: "Big colourful letters, slow pronunciation and a speaking test for primary pupils." },
    { property: "og:title", content: "Spell & Talk | Homework Paddy" },
    { property: "og:description", content: "Learn to spell and say English words." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <Gate><Spell /></Gate>,
});

const PICS: Record<string, string> = { ball: "⚽", banana: "🍌", orange: "🍊", bread: "🍞", bus: "🚌", water: "💧", school: "🏫", mango: "🥭", book: "📖" };
const COLORS = ["bg-tile-1", "bg-tile-2", "bg-tile-3", "bg-tile-4"];

function Spell() {
  const { t, speak, spend, awardCorrectAnswer } = useApp();
  const [input, setInput] = useState("banana");
  const [word, setWord] = useState("");
  const [result, setResult] = useState<number | null>(null);
  const [listening, setListening] = useState(false);
  const [typed, setTyped] = useState('');
  const [typingFeedback, setTypingFeedback] = useState('');
  const typedAwarded = useRef(false);

  const show = () => {
    const w = input.trim().toLowerCase().replace(/[^a-z]/g, "");
    if (!w) return;
    setWord(w); setResult(null);
    setTyped(''); setTypingFeedback(''); typedAwarded.current = false;
    speak(`${w}. ${w.split("").join(", ")}. ${w}`);
  };

  const test = async () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { alert("Voice test needs Chrome on Android."); return; }
    if (!(await spend("spell"))) return;
    const r = new SR(); r.lang = "en-NG"; setListening(true); let answered = false;
    r.onresult = (e: any) => {
      if (answered) return; answered = true;
      const s = pronunciationScore(word, e.results[0][0].transcript); setResult(s);
      if (s >= 7) awardCorrectAnswer();
      speak(s >= 7 ? `${t("great")} ${s} over 10` : `${t("tryAgain")} ${word}`);
    };
    r.onend = () => setListening(false);
    r.start();
  };

  return (
    <Screen>
      <Header title={t("spell")} />
      <div className="flex flex-col gap-4 p-4">
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={t("typeWord")}
          className="min-h-[64px] rounded-3xl border-2 border-input px-5 text-2xl font-bold outline-none focus:border-primary" />
        <Button className="cta" onClick={show}>✨ {t("show")}</Button>
        {word && (
          <>
            <div className="text-center text-8xl">{PICS[word] ?? "🐦"}</div>
            <div className="flex flex-wrap justify-center gap-2">
              {word.split("").map((c, i) => (
                <span key={i} style={{ animationDelay: `${i * 0.12}s` }}
                  className={`animate-pop grid h-14 w-12 place-items-center rounded-2xl text-3xl font-black uppercase text-primary-foreground ${COLORS[i % 4]}`}>{c}</span>
              ))}
            </div>
            <p className="break-words text-center text-2xl font-black">{word.toUpperCase().split("").join("-")}</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Button className="cta bg-tile-3" onClick={() => speak(word)}><Volume2 /> {t("say")}</Button>
              <Button className="cta bg-tile-2" onClick={test} disabled={listening}><Mic /> {t("test")}</Button>
            </div>
            <label className="font-bold">Type the word<input aria-label="Type the word" value={typed} onChange={e => { setTyped(e.target.value); setTypingFeedback(''); }} className="mt-2 min-h-16 w-full rounded-xl border border-input bg-card p-4 text-xl" autoComplete="off" /></label>
            <Button className="min-h-20" disabled={!typed.trim() || typedAwarded.current} onClick={() => { if (correctTyping(word, typed)) { typedAwarded.current = true; setTypingFeedback(t('great')); awardCorrectAnswer(); } else { setTypingFeedback(t('tryAgain')); } }}>Check spelling</Button>
            {typingFeedback && <p role="status" className="text-center font-bold">{typingFeedback}</p>}
            {result !== null && (
              <div className="flex flex-col items-center gap-2 rounded-3xl bg-secondary p-4 text-center">
                <Bird clap={result >= 7} className="h-28 w-28" />
                <p className="text-3xl font-black">{t("score")}: {result}/10</p>
                <p className="text-xl font-bold">{result >= 7 ? t("great") : `${t("tryAgain")} ${word.toUpperCase()}`}</p>
              </div>
            )}
          </>
        )}
      </div>
    </Screen>
  );
}
