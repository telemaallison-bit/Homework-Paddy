import { useApp } from "@/lib/app-store";
import { Bird, SafeBadge, Screen } from "./ui-kit";
import { Header } from "./Header";

export function ComingSoon({ titleKey, safe }: { titleKey: string; safe?: boolean }) {
  const { t, speak } = useApp();
  return (
    <Screen>
      <Header title={t(titleKey)} />
      <div className="flex flex-1 flex-col items-center justify-center gap-6 p-6 text-center">
        <Bird className="h-40 w-40" />
        <p className="text-2xl font-extrabold">{t("soon")}</p>
        <button className="cta" onClick={() => speak(t("soon"))}>🔊 {t("say")}</button>
        {safe && <SafeBadge />}
      </div>
    </Screen>
  );
}
