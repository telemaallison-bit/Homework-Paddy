import { useEffect, useRef } from 'react';
import { Check, Plus, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { reviewedQuestions, type AssignmentQuestion } from '@/lib/assignment';

export function AssignmentReview({ questions, warning, onChange, onConfirm }: {
  questions: AssignmentQuestion[];
  warning: string;
  onChange: (questions: AssignmentQuestion[]) => void;
  onConfirm: (questions: AssignmentQuestion[]) => void;
}) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { heading.current?.focus(); }, []);
  const valid = reviewedQuestions(questions);
  function change(index: number, field: keyof AssignmentQuestion, value: string) {
    onChange(questions.map((q, i) => i === index ? { ...q, [field]: value } : q));
  }
  return <section className="flex flex-col gap-5" aria-label="Review assignment questions">
    <h2 tabIndex={-1} ref={heading} className="text-2xl font-black">Review Questions</h2>
    <p className="font-semibold text-muted-foreground">{questions.length} questions</p>
    {warning && <p role="status" className="rounded-lg bg-accent p-4">{warning}</p>}
    <form className="flex flex-col gap-5" onSubmit={e => { e.preventDefault(); if (valid) onConfirm(valid); }}>
      <ol className="flex flex-col gap-4">
        {questions.map((q, i) => <li key={i} className="rounded-lg border border-border bg-card p-4">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h3 className="font-black">Question {i + 1}</h3>
            <Button type="button" variant="ghost" size="icon" title={`Remove question ${i + 1}`} aria-label={`Remove question ${i + 1}`} onClick={() => onChange(questions.filter((_, j) => j !== i))}><Trash2 className="h-5 w-5" /></Button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="min-w-0 font-bold">Number<Input required aria-label={`Question ${i + 1} number`} value={q.number} onChange={e => change(i, 'number', e.target.value)} className="mt-2 min-h-12 bg-background" /></label>
            <label className="min-w-0 font-bold">Subject<Input required aria-label={`Question ${i + 1} subject`} value={q.subject} onChange={e => change(i, 'subject', e.target.value)} className="mt-2 min-h-12 bg-background" /></label>
          </div>
          <label className="mt-4 block font-bold">Question<Textarea required aria-label={`Question ${i + 1} text`} value={q.question} onChange={e => change(i, 'question', e.target.value)} rows={4} className="mt-2 bg-background font-normal" /></label>
        </li>)}
      </ol>
      <Button type="button" variant="outline" className="min-h-14 gap-2 self-start" onClick={() => onChange([...questions, { number: `Q${questions.length + 1}`, subject: 'Homework', question: '' }])}><Plus />Add Question</Button>
      {!valid && <p role="status" className="text-sm text-muted-foreground">Each question needs a number, subject and question text.</p>}
      <Button type="submit" disabled={!valid} className="h-auto min-h-20 gap-3 whitespace-normal p-4 text-lg"><Check />Confirm Questions & Continue</Button>
    </form>
  </section>;
}