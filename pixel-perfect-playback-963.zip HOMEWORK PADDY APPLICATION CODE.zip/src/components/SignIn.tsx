import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useApp } from "@/lib/app-store";
import { Bird, Screen } from "./ui-kit";

export function SignIn() {
  const { t } = useApp();
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [signup, setSignup] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setBusy(true); setErr(""); setMsg("");
    const r = signup
      ? await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: window.location.origin } })
      : await supabase.auth.signInWithPassword({ email, password: pw });
    setBusy(false);
    if (r.error) setErr(r.error.message);
    else if (signup && !r.data.session) setMsg(t("checkEmail"));
  };

  const google = async () => {
    setErr("");
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) setErr(r.error.message);
  };

  return (
    <Screen>
      <div className="flex flex-col items-center gap-4 p-6 text-center">
        <Bird className="h-28 w-28" />
        <h1 className="text-2xl font-black">{t("signIn")}</h1>
        <input type="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("email")}
          className="min-h-[64px] w-full rounded-3xl border-2 border-input px-5 text-xl font-bold outline-none focus:border-primary" />
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder={t("password")}
          className="min-h-[64px] w-full rounded-3xl border-2 border-input px-5 text-xl font-bold outline-none focus:border-primary" />
        <button className="cta w-full" disabled={busy} onClick={go}>
          {signup ? t("createAccount") : t("verify")}
        </button>
        <button className="text-base font-bold underline" onClick={() => { setSignup(!signup); setErr(""); setMsg(""); }}>
          {signup ? t("haveAccount") : t("noAccount")}
        </button>
        <div className="flex w-full items-center gap-3 text-muted-foreground">
          <div className="h-0.5 flex-1 bg-border" />OR<div className="h-0.5 flex-1 bg-border" />
        </div>
        <button className="big-btn w-full justify-center" disabled={busy} onClick={google}>
          <span className="text-2xl">🇬</span> {t("google")}
        </button>
        {err && <p className="text-base font-bold text-destructive">{err}</p>}
        {msg && <p className="text-base font-bold">{msg}</p>}
      </div>
    </Screen>
  );
}
