import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import type { Barber } from "@/lib/barbers";

// Leaflet map — only ever loaded client-side via React.lazy + ClientOnly.
export default function MapView({ user, barbers, onPick }: {
  user: { lat: number; lng: number } | null;
  barbers: Barber[];
  onPick?: (id: string) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);

  useEffect(() => {
    let dead = false;
    void (async () => {
      const L = await import("leaflet");
      if (dead || !ref.current) return;
      const center: [number, number] = user ? [user.lat, user.lng] : [9.082, 8.6753];
      const map = L.map(ref.current).setView(center, user ? 12 : 6);
      mapRef.current = map;
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap contributors",
        maxZoom: 19,
      }).addTo(map);
      if (user) {
        L.marker([user.lat, user.lng], {
          icon: L.divIcon({
            className: "",
            html: '<div style="width:18px;height:18px;border-radius:50%;background:#2563eb;border:3px solid #fff;box-shadow:0 0 6px rgba(0,0,0,.4)"></div>',
            iconSize: [18, 18],
            iconAnchor: [9, 9],
          }),
        }).addTo(map).bindPopup("You");
      }
      const pins: [number, number][] = [];
      for (const b of barbers) {
        pins.push([b.lat, b.lng]);
        const m = L.marker([b.lat, b.lng], {
          icon: L.divIcon({
            className: "",
            html: '<div style="width:16px;height:16px;border-radius:50%;background:#dc2626;border:3px solid #fff;box-shadow:0 0 6px rgba(0,0,0,.4)"></div>',
            iconSize: [16, 16],
            iconAnchor: [8, 8],
          }),
        }).addTo(map).bindPopup(`<b>${b.name}</b><br/>${b.area}, ${b.city}`);
        m.on("click", () => onPick?.(b.id));
      }
      if (!user && pins.length) {
        map.fitBounds(pins, { padding: [30, 30] });
      }
    })();
    return () => {
      dead = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, [user, barbers, onPick]);

  return <div ref={ref} className="h-72 w-full rounded-lg border border-border" />;
}
