import { useEffect, useRef } from 'react';
import type { RewardGender } from '@/lib/rewards';

// Original full-body Lottie dancers built from jointed body parts (hips, torso, head, arms, legs).
type V = number[];
const FR = 30, OP = 120; // 4 seconds
const ease = { i: { x: [0.5], y: [1] }, o: { x: [0.5], y: [0] } };
function anim(values: V[], period = 15) {
  const k: object[] = [];
  for (let t = 0, i = 0; t < OP; t += period, i++) k.push({ t, s: values[i % values.length], e: values[(i + 1) % values.length], ...ease });
  k.push({ t: OP, s: values[Math.floor(OP / period) % values.length] });
  return { a: 1, k };
}
const still = (v: V | number) => ({ a: 0, k: v });
const rot = (deg: number[], period?: number) => anim(deg.map(d => [d]), period);
const fill = (c: V) => ({ ty: 'fl', c: still([...c, 1]), o: still(100), r: 1, bm: 0 });
const tr = { ty: 'tr', p: still([0, 0]), a: still([0, 0]), s: still([100, 100]), r: still(0), o: still(100), sk: still(0), sa: still(0) };
const rect = (x: number, y: number, w: number, h: number, c: V, r = 14) => ({ ty: 'gr', it: [{ ty: 'rc', p: still([x, y]), s: still([w, h]), r: still(r) }, fill(c), tr] });
const ell = (x: number, y: number, w: number, h: number, c: V) => ({ ty: 'gr', it: [{ ty: 'el', p: still([x, y]), s: still([w, h]) }, fill(c), tr] });

let ind = 0;
function layer(nm: string, joint: V, shapes: object[], r: object, parent?: number, p?: object, s?: object) {
  ind += 1;
  return { ddd: 0, ind, ty: 4, nm, sr: 1, ...(parent ? { parent } : {}), ip: 0, op: OP, st: 0, bm: 0,
    ks: { o: still(100), a: still([...joint, 0]), p: p ?? still([...joint, 0]), s: s ?? still([100, 100, 100]), r }, shapes };
}

function dancer(gender: RewardGender) {
  ind = 0;
  const girl = gender === 'girl';
  const skin = [0.45, 0.27, 0.16], dark = [0.12, 0.08, 0.06];
  const top = girl ? [0.95, 0.35, 0.6] : [0.2, 0.5, 0.95];
  const bottom = girl ? [0.98, 0.6, 0.15] : [0.15, 0.2, 0.35];
  const shoe = girl ? [0.95, 0.85, 0.2] : [0.95, 0.95, 0.95];
  // Root hips: sway side to side + bob; girl twirls (flip) mid-dance.
  const hipsP = anim([[200, 230, 0], [214, 222, 0], [200, 232, 0], [186, 222, 0]], 8);
  const twirl = girl ? anim([[100, 100, 100], [100, 100, 100], [-100, 100, 100], [100, 100, 100]], 30) : anim([[100, 100, 100], [104, 96, 100]], 8);
  const layers: object[] = [];
  const hips = layer('hips', [200, 230], [rect(200, 236, 66, 34, bottom, 12)], rot([-7, 7], 8), undefined, hipsP, twirl);
  const H = ind;
  const torso = layer('torso', [200, 225], [rect(200, 180, 62, 96, top, 22), ...(girl ? [rect(200, 240, 96, 40, top, 20)] : [])], rot([5, -5], 8), H);
  const T = ind;
  const head = layer('head', [200, 132], [ell(200, 100, 58, 64, skin),
    ...(girl ? [ell(200, 78, 92, 66, dark), ell(178, 70, 30, 30, top)] : [rect(200, 72, 66, 22, [0.95, 0.3, 0.2], 10), rect(222, 82, 40, 10, [0.95, 0.3, 0.2], 5)]),
    ell(189, 104, 7, 9, dark), ell(211, 104, 7, 9, dark), rect(200, 120, 18, 5, [0.8, 0.2, 0.25], 3)], rot([-12, 12], 8), T);
  const Hd = ind;
  // Arms: girl swings wide; boy throws punches (lower arm snaps straight).
  const armUp = (side: number) => girl ? rot(side > 0 ? [-40, -150, -60, -160] : [40, 150, 60, 160], 15) : rot(side > 0 ? [-30, -95, -20, -100] : [30, 95, 20, 100], 8);
  const armLo = (side: number) => girl ? rot(side > 0 ? [-20, -50] : [20, 50], 15) : rot(side > 0 ? [-110, 0] : [110, 0], 8);
  const arms: object[] = [];
  for (const side of [-1, 1]) {
    const sx = 200 + side * 36;
    arms.push(layer(`upper arm ${side}`, [sx, 146], [rect(sx, 172, 20, 54, top, 10)], armUp(side), T));
    const U = ind;
    arms.push(layer(`lower arm ${side}`, [sx, 196], [rect(sx, 220, 17, 50, skin, 9), ell(sx, 248, 22, 22, skin)], armLo(side), U));
  }
  // Legs: girl steps and kicks; boy Zanku legwork (alternate high knee + kick out).
  const legUp = (side: number) => girl ? rot(side > 0 ? [0, -35, 10, -20] : [-10, 0, 35, 20], 15) : rot(side > 0 ? [-60, 5, -10, 5] : [-5, 10, 60, -5], 8);
  const legLo = (side: number) => girl ? rot(side > 0 ? [0, 30] : [30, 0], 15) : rot(side > 0 ? [70, 0, 10, 0] : [0, -10, 70, 0], 8);
  const legs: object[] = [];
  for (const side of [-1, 1]) {
    const lx = 200 + side * 18;
    legs.push(layer(`thigh ${side}`, [lx, 246], [rect(lx, 272, 24, 56, girl ? skin : bottom, 11)], legUp(side), H));
    const L = ind;
    legs.push(layer(`shin ${side}`, [lx, 296], [rect(lx, 322, 20, 54, skin, 10), rect(lx + side * 8, 352, 38, 16, shoe, 8)], legLo(side), L));
  }
  // Ground shadow (no parent) follows the sway softly.
  const shadow = layer('shadow', [200, 372], [ell(200, 372, 120, 18, [0, 0, 0])], still(0), undefined, anim([[200, 372, 0], [210, 372, 0], [200, 372, 0], [190, 372, 0]], 8));
  (shadow as { ks: { o: object } }).ks.o = still(18);
  void Hd;
  // Lottie draws the first layer on top: hands/head over torso, legs under.
  layers.push(...arms.reverse(), head, torso, hips, ...legs.reverse(), shadow);
  return { v: '5.7.4', fr: FR, ip: 0, op: OP, w: 400, h: 400, nm: `${gender} dance`, ddd: 0, assets: [], layers };
}

export default function DancingAvatarPlayer({ gender }: { gender: RewardGender; levelUp?: boolean }) {
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let alive = true; let anim: { destroy(): void; stop(): void; goToAndStop(f: number, isFrame: boolean): void } | null = null;
    const timer = setTimeout(() => anim?.stop(), 4000);
    // Deep copy: shared helper objects must not be mutated by lottie while loading.
    void import('lottie-web/build/player/lottie_svg').then((mod) => {
      const lottie = (mod as unknown as { default?: typeof mod.default }).default ?? (mod as unknown as typeof mod.default);
      if (!alive || !box.current) return;
      anim = lottie.loadAnimation({ container: box.current, renderer: 'svg', loop: true, autoplay: true, animationData: JSON.parse(JSON.stringify(dancer(gender))) });
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) anim.goToAndStop(0, true);
    }).catch(err => console.error('dancer failed', err));
    return () => { alive = false; clearTimeout(timer); anim?.destroy(); };
  }, [gender]);
  return <div ref={box} className="dancing-avatar dancing-avatar-live" aria-label={`Dancing superstar ${gender}`} />;
}
