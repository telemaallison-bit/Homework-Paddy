import { useEffect, useRef, useState } from 'react';
import { Volume2 } from 'lucide-react';
import { Button } from './ui/button';
import { MathsSourceNote } from './MathsSourceNote';
import { MathsDrawing } from './MathsDrawing';
import { useApp } from '@/lib/app-store';
import { type Solution } from '@/lib/maths/model';
import { streamSpeech } from '@/lib/maths/stream-speech';
import { chunkText } from '@/lib/maths/chunk-text';
export function AssignmentSolution({solution,number,method}:{solution:Solution;number:string;method:string}){
 const {session}=useApp();const [playing,setPlaying]=useState(false);const stop=useRef<AbortController|null>(null);
 useEffect(()=>()=>stop.current?.abort(),[]);
 async function hear(text:string){if(playing){stop.current?.abort();return;}if(!session)return;const abort=new AbortController();stop.current=abort;setPlaying(true);setError('');try{for(const part of chunkText(text))await streamSpeech('/api/maths-speech',part,session.access_token,abort.signal);}catch(e){if(!abort.signal.aborted)setError(e instanceof Error?e.message:'Voice could not play.');}finally{setPlaying(false);}}
 const [error,setError]=useState('');
 return <section className="flex flex-col gap-4 border-t-2 border-primary py-6" aria-label={`Solution ${number}`}><div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-2xl font-black">{number} · {solution.topic}</h2><Button variant="secondary" className="h-auto min-h-14 gap-2 p-3" onClick={()=>void hear([solution.question,...solution.steps.map(s=>`${s.title}. ${s.explanation}. ${s.equation}`),solution.answer,solution.check].join('\n'))}><Volume2/>{playing?'Stop voice':'Hear explanation'}</Button></div><p className="font-bold">{solution.question}</p>{solution.methodNote&&<p className="text-sm text-muted-foreground">{solution.methodNote}</p>}<ol className="collection-grid gap-4">{solution.steps.map((step,i)=><li key={i} className="flex flex-col gap-3 rounded-lg border border-border bg-card p-4"><div className="flex items-start gap-2"><span className="font-black text-primary">{i+1}.</span><h3 className="min-w-0 flex-1 font-black">{step.title}</h3><Button variant="ghost" size="icon" aria-label={`Hear ${number} step ${i+1}`} title="Hear step" onClick={()=>void hear(`${step.title}. ${step.explanation}. ${step.equation}`)}><Volume2 className="h-5 w-5"/></Button></div><p>{step.explanation}</p>{step.equation&&<p className="rounded-lg bg-secondary p-3 font-black">{step.equation}</p>}<MathsDrawing drawing={step.drawing}/></li>)}</ol><div className="border-y border-border py-4"><p className="text-sm font-bold text-primary">Answer</p><p className="text-2xl font-black">{solution.answer}</p><p className="mt-2">{solution.check}</p></div><MathsSourceNote method={method} topic={solution.topic}/>{error&&<p role="alert" className="text-destructive">{error}</p>}</section>;
}