import { useEffect, useState } from 'react';
import { Check, Palette } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { BACKGROUND_THEMES, resolveTheme, THEME_STORAGE_KEY, type BackgroundTheme } from '@/lib/theme';

export function ThemeChooser() {
  const [selected, setSelected] = useState<BackgroundTheme>('cream');
  const [open, setOpen] = useState(false);
  useEffect(() => {
    let choice: BackgroundTheme = 'cream';
    try { choice = resolveTheme(localStorage.getItem(THEME_STORAGE_KEY)); } catch { /* Storage may be unavailable. */ }
    setSelected(choice);
    document.documentElement.dataset['appTheme'] = choice;
  }, []);
  function choose(choice: BackgroundTheme) {
    setSelected(choice);
    document.documentElement.dataset['appTheme'] = choice;
    try { localStorage.setItem(THEME_STORAGE_KEY, choice); } catch { /* Keep the immediate selection. */ }
    setOpen(false);
  }
  return <div className="theme-toolbar"><div className="mx-auto flex max-w-7xl justify-end px-4 py-2">
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild><Button variant="outline" className="theme-trigger h-10 gap-2 rounded-xl px-4 text-base font-bold"><Palette aria-hidden="true" />🎨 Theme</Button></PopoverTrigger>
      <PopoverContent align="end" className="w-64 rounded-xl p-2" aria-label="Background colours">
        <div className="flex flex-col gap-1" role="group" aria-label="Background colour">
          {BACKGROUND_THEMES.map(theme => <Button key={theme.id} variant="ghost" aria-pressed={selected === theme.id} className="h-12 justify-start gap-3 rounded-lg text-base" onClick={() => choose(theme.id)}><span className={`theme-swatch swatch-${theme.id}`} aria-hidden="true" /><span className="flex-1 text-left">{theme.name}</span>{selected === theme.id && <Check aria-hidden="true" />}</Button>)}
        </div>
      </PopoverContent>
    </Popover>
  </div></div>;
}