import { useEffect, useRef, useState } from 'react';
import { Play, X } from 'lucide-react';
import { useApp } from '@/lib/app-store';
import { claimAdReward } from '@/lib/wallet.functions';
import { PREMIUM_OPTIONS } from '@/lib/free-learning';
import { Button } from './ui/button';
import { Bird } from './ui-kit';
export function Paywall() {
  const { paywall, setPaywall, session, setCredits, speak } = useApp();
  const [left, setLeft] = useState<number | null>(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const claimed = useRef(false);
  useEffect(() => { if (paywall) { setMessage(''); setLeft(null); claimed.current = false; } }, [paywall]);
  useEffect((): void | (() => void) => {
    if (!paywall || left === null) return;
    if (left > 0) { const timer = setTimeout(() => setLeft(left - 1), 1000); return () => clearTimeout(timer); }
    if (claimed.current) return;
    claimed.current = true; setBusy(true);
    claimAdReward().then(r => {
      if (r.ok) { setCredits(r.credits); setMessage('2 more free solves added!'); speak('2 more free solves added!'); }
      else setMessage('Today’s three ad rewards are finished. Free solves return at midnight in Nigeria.');
    }).catch(e => setMessage(e instanceof Error ? e.message : 'Could not add free solves.')).finally(() => { setLeft(null); setBusy(false); });
  }, [left, paywall]);
  if (!paywall || !session) return null;
  return <div className="fixed inset-0 z-50 overflow-y-auto bg-background" role="dialog" aria-modal="true" aria-label="Free solves and premium"><div className="mx-auto flex max-w-xl flex-col gap-5 p-4 sm:p-8">
    <Button variant="ghost" size="icon" aria-label="Close" className="ml-auto" disabled={busy || left !== null} onClick={() => setPaywall(false)}><X /></Button>
    <Bird className="mx-auto h-24 w-24" /><h1 className="text-center text-3xl font-black">Homework Paddy is 100% Free 🎉</h1>
    <p className="text-center text-lg font-semibold">Solve as many homework and maths questions as you like during our growth phase.</p>
    {message && <p role="status" className="rounded-lg bg-secondary p-4 font-bold">{message}</p>}
    {left !== null ? <div className="grid min-h-40 place-items-center rounded-lg bg-muted"><p className="text-center font-bold">Short-ad placeholder<br /><span className="text-4xl">{left}</span></p></div> : <Button disabled={busy} className="h-auto min-h-20 gap-3 whitespace-normal p-4 text-lg" onClick={() => { claimed.current = false; setMessage(''); setLeft(15); }}><Play className="shrink-0" />Watch Short Ad to Get 2 More Free Solves</Button>}
    <p className="text-center text-sm text-muted-foreground">Ad placeholder — no real advert or ad revenue yet. Up to 3 rewards daily.</p>
    <section className="border-t border-border pt-5"><h2 className="mb-4 text-center text-xl font-black">Want Unlimited? · Coming Soon</h2><div className="grid grid-cols-1 gap-3 sm:grid-cols-2">{PREMIUM_OPTIONS.map(p => <div key={p.days} className="rounded-lg border border-border bg-muted p-4 text-center"><p className="font-bold">{p.days === 7 ? '1 Week' : '3 Days'} — ₦{p.naira}</p></div>)}</div><Button disabled variant="secondary" className="mt-4 h-auto min-h-20 w-full whitespace-normal p-4 text-base">Premium Coming Soon - Enjoy Free For Now 🎉</Button>
    {/* Paystack payment button disabled during growth phase; PAYSTACK keys stay in env. */}</section>
  </div></div>;
}