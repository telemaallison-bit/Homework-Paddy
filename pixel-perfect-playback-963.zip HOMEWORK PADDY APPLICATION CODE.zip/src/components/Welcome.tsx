import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import useEmblaCarousel from "embla-carousel-react";
import { ArrowLeft, ArrowRight, Volume2 } from "lucide-react";
import { Button } from "./ui/button";
import { Bird, Screen } from "./ui-kit";
import { useApp } from "@/lib/app-store";
import { needsWelcome, welcomeKey } from "@/lib/welcome";
import homework from "@/assets/welcome-homework.jpg";
import learning from "@/assets/welcome-learning.jpg";
import hair from "@/assets/welcome-hair.jpg";

const SLIDES = [
  { title: "Welcome to Homework Paddy", text: "Snap any homework with your phone. We solve it step-by-step with pictures & voice.", image: homework, alt: "A happy Nigerian child photographing homework with a parent beside them" },
  { title: "Learn with Pictures & Your Language", text: "From nursery rhymes for 2-5 years to WAEC & University maths. Hear it in English, Pidgin, Yoruba, Igbo, Hausa.", image: learning, alt: "Colourful animals with ABC blocks, an apple, numbers and five mangoes" },
  { title: "Try Hair Styles on Your Real Face", text: "Attach your photo or take picture. See how you look before you cut.", image: hair, alt: "A Nigerian family with braids, a fade, curly hair, glasses and a tidy beard" },
];

/** Device-local welcome, only mounted after sign-in and any second factor. */
export function WelcomeOnce({ children }: { children: ReactNode }) {
  const { session } = useApp();
  const userId = session?.user.id ?? "";
  const [state, setState] = useState<{ userId: string; show: boolean } | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    let completed: string | null = null;
    try { completed = localStorage.getItem(welcomeKey(userId)); } catch { /* Private browsing: welcome still works. */ }
    setState({ userId, show: needsWelcome(userId, completed) });
  }, [userId]);

  if (!state || state.userId !== userId) return <Screen className="home-screen"><div /></Screen>;
  if (!state.show) return <>{children}</>;

  return <Welcome onFinish={() => {
    try { localStorage.setItem(welcomeKey(userId), "1"); } catch { /* Storage unavailable: completion lasts for this session. */ }
    setState({ userId, show: false });
    void navigate({ to: "/" });
  }} />;
}

function Welcome({ onFinish }: { onFinish: () => void }) {
  const { speak } = useApp();
  const [viewportRef, carousel] = useEmblaCarousel({ loop: false, watchDrag: true });
  const [index, setIndex] = useState(0);
  const heading = useRef<HTMLHeadingElement | null>(null);
  const current = SLIDES[index] ?? SLIDES[0];
  const read = useCallback((n: number) => {
    const slide = SLIDES[n];
    if (slide) speak(`${slide.title}. ${slide.text}`, "en");
  }, [speak]);
  const readRef = useRef(read);
  useEffect(() => { readRef.current = read; }, [read]);

  useEffect(() => {
    if (!carousel) return;
    const select = () => {
      const n = carousel.selectedScrollSnap();
      setIndex(n);
      readRef.current(n);
      heading.current?.focus({ preventScroll: true });
    };
    carousel.on("select", select);
    readRef.current(0);
    return () => { carousel.off("select", select); };
  }, [carousel]);
  useEffect(() => () => { window.speechSynthesis?.cancel(); }, []);

  const finish = () => { window.speechSynthesis?.cancel(); onFinish(); };
  return (
    <Screen className="home-screen welcome-screen">
      <header className="flex items-center justify-between gap-3 px-4 py-3 sm:px-8">
        <div className="flex min-w-0 items-center gap-2"><Bird className="h-9 w-9 shrink-0" /><span className="text-base font-black sm:text-lg">Homework Paddy</span></div>
        <Button variant="ghost" onClick={finish} className="h-12 shrink-0 px-4 text-base font-bold">Skip</Button>
      </header>
      <main className="welcome-content mx-auto flex w-full max-w-2xl flex-1 flex-col px-4 pb-6 sm:px-8" aria-label="Welcome" aria-roledescription="carousel">
        <div ref={viewportRef} className="overflow-hidden" onKeyDown={(event) => {
          if (event.key === "ArrowRight") carousel?.scrollNext();
          if (event.key === "ArrowLeft") carousel?.scrollPrev();
        }}>
          <div className="flex touch-pan-y">
            {SLIDES.map((slide, n) => (
              <section key={slide.title} className="min-w-0 flex-[0_0_100%]" aria-label={`Welcome screen ${n + 1} of 3`} aria-hidden={index !== n}>
                <img src={slide.image} alt={slide.alt} width={1200} height={800} loading={n === 0 ? "eager" : "lazy"} className="welcome-image w-full object-cover" />
              </section>
            ))}
          </div>
        </div>
        <div className="flex flex-1 flex-col items-center pt-5 text-center" aria-live="polite">
          <h1 ref={heading} tabIndex={-1} className="max-w-xl text-2xl font-black leading-snug outline-none sm:text-3xl">{current?.title}</h1>
          <p className="mt-3 max-w-xl text-base font-semibold leading-relaxed text-muted-foreground sm:text-lg">{current?.text}</p>
          <Button variant="ghost" size="icon" aria-label="Hear welcome text" title="Hear welcome text" className="mt-2 h-12 w-12 shrink-0 rounded-full bg-accent text-accent-foreground" onClick={() => read(index)}><Volume2 className="h-6 w-6" /></Button>
          <div className="my-4 flex h-8 items-center justify-center gap-2" aria-label="Welcome progress">
            {SLIDES.map((slide, n) => <Button key={slide.title} variant="ghost" size="icon" className="h-8 w-8 rounded-full" aria-label={`Go to welcome screen ${n + 1}`} aria-current={index === n ? "step" : undefined} onClick={() => carousel?.scrollTo(n)}><span className={`h-2.5 w-2.5 rounded-full ${index === n ? "bg-primary" : "bg-border"}`} /></Button>)}
          </div>
          <div className="mt-auto flex w-full items-center gap-3">
            {index > 0 && <Button variant="outline" size="icon" aria-label="Previous welcome screen" title="Previous welcome screen" className="h-20 w-14 shrink-0 rounded-lg" onClick={() => carousel?.scrollPrev()}><ArrowLeft className="h-6 w-6" /></Button>}
            <Button className="h-auto min-h-20 w-full gap-2 whitespace-normal rounded-lg px-4 py-4 text-lg font-black leading-snug sm:text-xl" onClick={() => index === 2 ? finish() : carousel?.scrollNext()}>{index === 2 ? "Start Learning Now - It's Free" : "Next"}<ArrowRight className="h-6 w-6 shrink-0" /></Button>
          </div>
        </div>
      </main>
    </Screen>
  );
}