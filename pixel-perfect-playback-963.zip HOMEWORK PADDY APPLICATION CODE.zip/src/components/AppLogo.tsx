export function AppLogo() {
  return <span className="app-logo" aria-label="Homework Paddy"><span aria-hidden="true" className="logo-icons">📚💰</span><span><span className="text-brand-homework">Homework</span>{' '}<span className="text-brand-paddy">Paddy</span></span></span>;
}