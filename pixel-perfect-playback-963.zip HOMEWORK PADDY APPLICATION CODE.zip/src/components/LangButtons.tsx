import { LANGS, type Lang } from "@/lib/i18n";
import { useApp } from "@/lib/app-store";
import { Volume2 } from "lucide-react";

const HELLO: Record<Lang, string> = {
  en: "Hello! Let us learn in English.",
  pcm: "How far! Make we learn for Pidgin.",
  yo: "Ẹ n lẹ! Ẹ jẹ́ ká kẹ́kọ̀ọ́ ní Yorùbá.",
  ig: "Ndewo! Ka anyị mụta n'Igbo.",
  ha: "Sannu! Mu koyi da Hausa.",
};

/** Five big language buttons; each speaks a greeting in its own language when chosen. */
export function LangButtons({ onPicked }: { onPicked?: () => void }) {
  const { lang, setLang, speak } = useApp();
  return (
    <div className="flex flex-col gap-3">
      {LANGS.map((l) => (
        <button key={l.id} data-active={lang === l.id} className="big-btn"
          onClick={() => { setLang(l.id); speak(HELLO[l.id], l.id); onPicked?.(); }}>
          <span className="text-4xl">{l.flag}</span> <span className="flex-1">{l.label}</span>
          <span role="button" aria-label={`Hear ${l.label}`} className="speaker"
            onClick={(e) => { e.stopPropagation(); speak(HELLO[l.id], l.id); }}>
            <Volume2 className="h-5 w-5" />
          </span>
        </button>
      ))}
    </div>
  );
}
