import { useEffect, useRef } from "react";
import type { Drawing } from "@/lib/maths/model";

export function MathsDrawing({ drawing }: { drawing: Drawing }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const el = canvas.current;
    const ctx = el?.getContext("2d");
    if (!el || !ctx) return;
    const colors = getComputedStyle(el);
    const palette = { primary: colors.getPropertyValue("--primary"), secondary: colors.getPropertyValue("--tile-3"), accent: colors.getPropertyValue("--tile-4"), ink: colors.getPropertyValue("--foreground") };
    ctx.clearRect(0, 0, 720, 360); ctx.save(); ctx.scale(2, 2);
    ctx.font = "14px Nunito, sans-serif"; ctx.lineWidth = 2;
    for (const shape of drawing.shapes.slice(0, 30)) {
      const x = Math.max(12, Math.min(340, shape.x)); const y = Math.max(12, Math.min(165, shape.y));
      const width = Math.max(0, Math.min(340 - x, shape.width)); const height = Math.max(0, Math.min(170 - y, shape.height));
      ctx.fillStyle = palette[shape.tone].trim(); ctx.strokeStyle = palette[shape.tone].trim();
      if (shape.kind === "rect") { ctx.globalAlpha = .16; ctx.fillRect(x, y, width, height); ctx.globalAlpha = 1; ctx.strokeRect(x, y, width, height); }
      else if (shape.kind === "circle") { ctx.beginPath(); ctx.arc(x, y, Math.min(width, 18, x - 4, y - 4), 0, Math.PI * 2); ctx.fill(); }
      else if (shape.kind === "line") { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(Math.max(8, Math.min(352, x + shape.width)), Math.max(8, Math.min(172, y + shape.height))); ctx.stroke(); }
      if (shape.label) { ctx.fillStyle = palette.ink.trim(); ctx.fillText(shape.label, x + (shape.kind === "rect" ? 5 : 0), y + (shape.kind === "rect" ? 20 : 0), Math.max(1, 352 - x)); }
    }
    ctx.restore();
  }, [drawing]);
  return <figure className="min-w-0"><canvas ref={canvas} width={720} height={360} role="img" aria-label={drawing.caption} className="aspect-[2/1] w-full max-w-full rounded-lg bg-muted" /><figcaption className="mt-2 text-sm text-muted-foreground">{drawing.caption}</figcaption></figure>;
}