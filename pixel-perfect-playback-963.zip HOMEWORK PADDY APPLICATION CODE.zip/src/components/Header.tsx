import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Menu, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-store";
import { detectLocation } from "@/lib/geo";
import { Button } from "./ui/button";
import { DASHBOARD_COPY } from '@/lib/parent-dashboard';
import { AppLogo } from './AppLogo';
import { rewardLevel } from '@/lib/rewards';

export function Header({ title, back = true }: { title: string; back?: boolean }) {
  const { credits, session, loc, setLoc, name, setPaywall, t, speak, lang, rewardState } = useApp();
  const [open, setOpen] = useState(false);
  const [locBusy, setLocBusy] = useState(false);
  const navigate = useNavigate();
  const email = session?.user?.email ?? "";
  const initial = (name || email || "?").slice(0, 1).toUpperCase();

  const findMe = async () => {
    if (locBusy) return;
    setLocBusy(true);
    try {
      const l = await detectLocation();
      setLoc(l);
      speak(t("youAreIn", { place: l.label }));
    } catch {
      speak(t("locDenied"));
    } finally {
      setLocBusy(false);
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setOpen(false);
    navigate({ to: "/" });
  };

  const items = [
    { to: "/", label: t("home"), emoji: "🏠" },
    { to: "/maths", label: "Solve Maths", emoji: "🧮" },
    { to: "/parent-dashboard", label: DASHBOARD_COPY[lang??'en'].title, emoji: "📊" },
    { to: "/profile", label: t("profile"), emoji: "👤" },
    { to: "/barbers", label: t("barbers"), emoji: "💈" },
    { to: "/marketplace", label: t("market"), emoji: "🛍️" },
    { to: "/feedback", label: t("feedback"), emoji: "💬" },
    { to: "/settings", label: t("settings"), emoji: "⚙️" },
    { to: "/support", label: t("support"), emoji: "🆘" },
    { to: "/about", label: t("about"), emoji: "ℹ️" },
  ] as const;

  return (
    <header className="app-header sticky top-14 z-40 border-b border-border bg-background">
      <div className="grid grid-cols-[40px_minmax(0,1fr)_40px] items-center gap-2 p-4 sm:flex sm:gap-3">
        {back ? (
          <Link to="/" aria-label={t("back")} className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-muted">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        ) : (
          <Button variant="ghost" size="icon" aria-label={t("menu")} onClick={() => setOpen(true)} className="h-10 w-10 shrink-0 rounded-full bg-muted">
            <Menu className="h-5 w-5" />
          </Button>
        )}
        <Link to="/" className="flex min-w-0 items-center justify-center gap-2 sm:justify-start">
          <span className="flex min-w-0 flex-col items-center sm:items-start"><AppLogo />{title !== 'Homework Paddy' && <span className="mt-1 text-center text-sm font-semibold text-muted-foreground sm:text-left">{title}</span>}</span>
        </Link>
        <div className="col-span-3 flex min-w-0 flex-wrap items-center justify-center gap-2 border-t border-border pt-2 sm:ml-auto sm:border-0 sm:pt-0">
          <span className="rounded-full bg-accent px-2.5 py-1 text-sm font-extrabold">⭐ {credits} {DASHBOARD_COPY[lang??'en'].remaining}</span>
          <span className="rounded-full bg-accent px-2.5 py-1 text-sm font-extrabold">⭐ {rewardState.stars} stars · Level {rewardLevel(rewardState.stars)}</span>
          <span className="rounded-full bg-secondary px-2.5 py-1 text-sm font-extrabold text-secondary-foreground" title="Come tomorrow for bonus stars" aria-label={`${rewardState.streak} days streak! Come tomorrow for bonus stars`}>🔥 {rewardState.streak} days streak!</span>
          <Button variant="ghost" size="icon" aria-label={t("locAsk")} title={loc ? t("youAreIn", { place: loc.label }) : t("locAsk")} onClick={findMe} disabled={locBusy} className="h-10 w-10 shrink-0 rounded-full bg-muted text-lg">
            {locBusy ? "…" : "📍"}
          </Button>
          <Link to="/profile" aria-label={t("profile")} className="grid h-10 w-10 place-items-center rounded-full bg-primary text-base font-black text-primary-foreground">
            {initial}
          </Link>
        </div>
      </div>
      {loc && <p className="border-t border-border px-4 py-1 text-xs font-semibold text-muted-foreground">📍 {t("youAreIn", { place: loc.label })}</p>}

      {open && (
        <div className="fixed inset-0 z-50" role="dialog" aria-label={t("menu")}>
          <Button variant="ghost" aria-label={t("close")} className="absolute inset-0 h-full w-full rounded-none bg-overlay hover:bg-overlay" onClick={() => setOpen(false)} />
          <nav className="absolute left-0 top-0 flex h-full w-72 max-w-[85vw] flex-col gap-1 overflow-y-auto bg-background p-4 shadow-xl">
            <div className="mb-2 flex items-center justify-between">
              <AppLogo />
              <Button variant="ghost" size="icon" aria-label={t("close")} onClick={() => setOpen(false)} className="shrink-0 rounded-full bg-muted"><X className="h-5 w-5" /></Button>
            </div>
            {items.map((i) => (
              <Link key={i.to} to={i.to} onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 text-base font-bold hover:bg-muted">
                <span className="text-xl">{i.emoji}</span>{i.label}
              </Link>
            ))}
            <Button variant="ghost" onClick={() => { setOpen(false); setPaywall(true); }} className="h-auto justify-start gap-3 rounded-xl px-3 py-3 text-left text-base font-bold hover:bg-muted">
              <span className="text-xl">⭐</span>Free Solves & Premium
            </Button>
            <Button variant="ghost" onClick={logout} className="mt-2 h-auto justify-start gap-3 rounded-xl px-3 py-3 text-left text-base font-bold text-destructive hover:bg-muted">
              <span className="text-xl">🚪</span>{t("logout")}
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}
