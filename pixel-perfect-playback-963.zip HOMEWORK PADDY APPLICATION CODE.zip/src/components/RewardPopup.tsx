import { useEffect, useState } from 'react';
import { Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useApp } from '@/lib/app-store';
import { supabase } from '@/integrations/supabase/client';
import starArt from '@/assets/engagement/super-paddy-star-3d.png';
import { DancingAvatar } from './DancingAvatar';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from './ui/dialog';
import { rewardLevel } from '@/lib/rewards';

const WAITLIST_KEY = 'ss_waitlist_done';

export function RewardPopup() {
  const { rewardOpen, rewardState, closeReward, t, freeSolvesToday, session, rewardGender, rewardId, levelUp, speak } = useApp();
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [encouragement, setEncouragement] = useState('Superstar!');
  const [soundBlocked, setSoundBlocked] = useState(false);
  const [waitlistDone, setWaitlistDone] = useState(false);
  useEffect(() => { try { setWaitlistDone(Boolean(localStorage.getItem(WAITLIST_KEY))); } catch { /* optional capture */ } }, []);
  useEffect(() => {
    if (!rewardOpen) return;
    const words = ['You are so smart!', 'Superstar!', 'Genius! 🧠'];
    const chosen = words[Math.floor(Math.random() * words.length)] ?? 'Superstar!';
    setEncouragement(chosen);
    const audio = new Audio('/sounds/ta-da.wav');
    setSoundBlocked(false);
    void audio.play().catch(() => setSoundBlocked(true));
    const voiceTimer = setTimeout(() => speak(chosen), 800);
    const timers: ReturnType<typeof setTimeout>[] = [];
    let active = true;
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      void import('canvas-confetti').then(({ default: confetti }) => {
        if (!active) return;
        const burst = (x: number) => confetti({ particleCount: levelUp ? 100 : 65, spread: 100, origin: { x, y: 0.5 }, zIndex: 120, disableForReducedMotion: true });
        void burst(0.5);
        if (levelUp) for (const delay of [400, 800, 1200]) timers.push(setTimeout(() => { void burst(0.15); void burst(0.85); }, delay));
      }).catch(() => { /* animation never blocks learning */ });
    }
    return () => { active = false; audio.pause(); clearTimeout(voiceTimer); timers.forEach(clearTimeout); };
  }, [rewardOpen, rewardId]);
  if (!rewardOpen) return null;
  const askEmail = freeSolvesToday === 2 && Boolean(session) && !waitlistDone;

  async function join() {
    if (!session) return;
    const clean = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean) || clean.length > 254) { setStatus('Please enter a valid email.'); return; }
    setBusy(true); setStatus('');
    const { error } = await supabase.from('waitlist').insert({ email: clean, user_id: session.user.id });
    setBusy(false);
    if (error && error.code !== '23505') { setStatus('Could not save now. Please try again.'); return; }
    localStorage.setItem(WAITLIST_KEY, '1');
    setStatus('Thank you! Tips are coming to your inbox 💌');
  }

  return (
    <Dialog open={rewardOpen} onOpenChange={open => { if (!open) closeReward(); }}>
      <DialogContent className={`celebration-modal ${levelUp ? 'celebration-level-up' : ''}`}>
        <DialogTitle className="text-center text-3xl font-black">{levelUp ? `LEVEL UP! You're now Level ${rewardLevel(rewardState.stars)} 🚀` : 'AMAZING! 🌟🌟🌟🌟🌟'}</DialogTitle>
        {levelUp && <p className="text-xl font-black">AMAZING! 🌟🌟🌟🌟🌟</p>}
        <div className="celebration-stars" aria-hidden="true">{[0,1,2,3,4].map(i => <img key={`${rewardId}-${i}`} src={starArt} alt="" width={512} height={512} className={`celebration-star celebration-star-${i}`} />)}</div>
        <DancingAvatar key={rewardId} gender={rewardGender ?? 'boy'} levelUp={levelUp} />
        <p className="text-xl font-black">{encouragement}</p>
        <DialogDescription className="text-center text-base font-bold">+10 ⭐ Super Paddy! · {rewardState.stars} stars · Level {rewardLevel(rewardState.stars)}</DialogDescription>
        <p className="text-sm font-semibold">🔥 {rewardState.streak} days streak! Come tomorrow for bonus stars</p>
        {soundBlocked && <Button variant="outline" onClick={() => { const audio = new Audio('/sounds/ta-da.wav'); void audio.play().then(() => setSoundBlocked(false)).catch(() => {}); speak(encouragement); }}><Volume2 className="h-4 w-4" />Hear celebration</Button>}
        {freeSolvesToday >= 3 && (
          <p className="mt-3 rounded-xl bg-accent p-3 font-black">You've solved {freeSolvesToday} homeworks today 🔥 You're on fire!</p>
        )}
        {askEmail && (
          <div className="mt-4 rounded-xl border border-border bg-muted p-4 text-left">
            <p className="font-black">Get free homework tips for parents</p>
            <input type="email" aria-label="Parent email" value={email} maxLength={254} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="mt-2 min-h-12 w-full rounded-lg border border-input bg-card p-3 text-base" />
            <Button disabled={busy} className="mt-2 min-h-12 w-full" onClick={() => void join()}>Send Me Tips</Button>
            {status && <p role="status" className="mt-2 text-sm font-bold">{status}</p>}
          </div>
        )}
        <Button className="mt-5 min-h-14 w-full rounded-xl text-lg font-black" onClick={closeReward}>{t('great')}</Button>
      </DialogContent>
    </Dialog>
  );
}
