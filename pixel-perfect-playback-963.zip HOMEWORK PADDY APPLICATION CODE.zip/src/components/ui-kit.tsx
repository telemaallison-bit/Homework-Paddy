import { Link } from "@tanstack/react-router";
import { ArrowLeft, Coins, ShieldCheck, Volume2 } from "lucide-react";
import type { ReactNode } from "react";
import { useApp } from "@/lib/app-store";
import bird from "@/assets/bird.png";

export function Speaker({ text }: { text: string }) {
  const { speak } = useApp();
  return (
    <span
      role="button"
      aria-label="Hear this"
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); speak(text); }}
      className="speaker"
    >
      <Volume2 className="h-5 w-5" />
    </span>
  );
}

export function Bird({ clap = false, className = "" }: { clap?: boolean; className?: string }) {
  return <img src={bird} alt="Homework Paddy Bird" className={`${clap ? "animate-clap" : "animate-bob"} ${className}`} />;
}

export function TopBar({ title, back = true }: { title: string; back?: boolean }) {
  const { credits, t, session, setPaywall } = useApp();
  return (
    <header className="flex items-center gap-3 px-4 py-3">
      {back && (
        <Link to="/" aria-label={t("back")} className="grid h-12 w-12 place-items-center rounded-full bg-secondary text-secondary-foreground">
          <ArrowLeft className="h-6 w-6" />
        </Link>
      )}
      <h1 className="flex-1 text-xl font-extrabold">{title}</h1>
      {session && (
        <button onClick={() => setPaywall(true)} className="flex items-center gap-1 rounded-full bg-accent px-3 py-2 text-sm font-bold text-accent-foreground">
          <Coins className="h-5 w-5 shrink-0" /> {t("triesLeft", { n: credits })}
        </button>
      )}
    </header>
  );
}

export function SafeBadge() {
  const { t } = useApp();
  return (
    <div className="flex items-center gap-2 rounded-2xl bg-secondary p-3 text-base font-semibold text-secondary-foreground">
      <ShieldCheck className="h-6 w-6 shrink-0 text-primary" /> {t("safe")}
    </div>
  );
}

export function Screen({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`app-screen mx-auto flex min-h-screen max-w-7xl flex-col bg-background text-base sm:text-lg ${className}`}>{children}</div>;
}
