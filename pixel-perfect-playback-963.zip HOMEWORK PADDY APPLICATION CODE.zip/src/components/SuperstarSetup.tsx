import { useApp } from '@/lib/app-store';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogTitle } from './ui/dialog';
import girl from '@/assets/celebration/girl.png';
import boy from '@/assets/celebration/boy.png';

export function SuperstarSetup() {
  const { ready, rewardGender, setRewardGender } = useApp();
  return <Dialog open={ready && !rewardGender}>
    <DialogContent className="superstar-setup text-center" aria-describedby={undefined} onEscapeKeyDown={e => e.preventDefault()} onPointerDownOutside={e => e.preventDefault()}>
      <DialogTitle className="text-center text-2xl font-black">Are you a superstar girl or boy?</DialogTitle>
      <div className="grid grid-cols-2 gap-3">
        {(['girl', 'boy'] as const).map(gender => <Button key={gender} variant="outline" className="h-auto min-h-20 flex-col gap-3 p-3 text-xl" onClick={() => setRewardGender(gender)}>
          <img src={gender === 'girl' ? girl : boy} width={816} height={816} alt="" className="h-44 w-full object-contain" />
          {gender === 'girl' ? 'Girl 👧' : 'Boy 👦'}
        </Button>)}
      </div>
    </DialogContent>
  </Dialog>;
}