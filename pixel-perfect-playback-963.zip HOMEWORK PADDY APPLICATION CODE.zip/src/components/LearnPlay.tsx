import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { useApp } from '@/lib/app-store';
import { LEARN_PLAY_COPY, LEARN_PLAY_ITEMS, type LearnPlayId } from '@/lib/learn-play';

export function LearnPlay() {
  const { lang, speak } = useApp();
  const copy = LEARN_PLAY_COPY[lang ?? 'en'];
  const [open, setOpen] = useState<LearnPlayId | null>(null);

  useEffect(() => () => window.speechSynthesis?.cancel(), []);

  function toggle(id: LearnPlayId) {
    if (open === id) {
      setOpen(null);
      window.speechSynthesis?.cancel();
      return;
    }
    setOpen(id);
    speak(copy.items[id].lyrics);
  }

  return (
    <section className="px-4" aria-labelledby="learn-play-title">
      <h2 id="learn-play-title" className="mb-3 text-xl font-black">{copy.heading}</h2>
      <div className="learn-play-grid">
        {LEARN_PLAY_ITEMS.map(item => {
          const itemCopy = copy.items[item.id];
          const isOpen = open === item.id;
          return (
            <article key={item.id} className={`learn-play-card ${item.card}`}>
              <img src={item.image} alt="" aria-hidden="true" loading="lazy" width={512} height={512} className="learn-play-art" />
              <h3 className="text-base font-black">{itemCopy.title}</h3>
              <Button
                variant="secondary"
                className="h-auto min-h-11 w-full whitespace-normal rounded-xl p-2 text-sm font-black"
                aria-expanded={isOpen}
                aria-label={`${copy.play} ${itemCopy.title}`}
                onClick={() => toggle(item.id)}
              >
                {isOpen ? copy.stop : copy.play}
              </Button>
              {isOpen && <p className="learn-play-lyrics" aria-label={copy.lyricsLabel}>{itemCopy.lyrics}</p>}
            </article>
          );
        })}
      </div>
    </section>
  );
}
