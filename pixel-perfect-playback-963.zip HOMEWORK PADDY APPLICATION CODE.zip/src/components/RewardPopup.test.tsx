import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { AppProvider, useApp } from '@/lib/app-store';
import { RewardPopup } from './RewardPopup';
vi.mock('./DancingAvatar', () => ({ DancingAvatar: () => null }));
vi.mock('canvas-confetti', () => ({ default: vi.fn() }));

function AwardButton() {
  const { awardSuperPaddy, awardCorrectAnswer } = useApp();
  return <><button onClick={awardSuperPaddy}>Award solve</button><button onClick={awardCorrectAnswer}>Award correct answer</button></>;
}
describe('Shared correct-answer rewards', () => {
  beforeEach(() => { localStorage.clear(); vi.spyOn(HTMLMediaElement.prototype, 'play').mockResolvedValue(); vi.spyOn(HTMLMediaElement.prototype, 'pause').mockImplementation(() => {}); });
  it('adds ten stars and counts a completed homework solve', async () => {
    render(<AppProvider><AwardButton /><RewardPopup /></AppProvider>);
    await waitFor(() => expect(localStorage.getItem('total_stars')).toBeNull());
    fireEvent.click(screen.getByRole('button', { name: 'Award solve' }));
    await screen.findByRole('dialog');
    expect(localStorage.getItem('total_stars')).toBe('10');
    expect(localStorage.getItem('ss_super_paddy_streak')).toBe('1');
    expect(JSON.parse(localStorage.getItem('ss_free_solves') ?? '{}').count).toBe(1);
  });
  it('practice earns ten stars without advancing the homework email threshold', async () => {
    render(<AppProvider><AwardButton /><RewardPopup /></AppProvider>);
    fireEvent.click(screen.getByRole('button', { name: 'Award correct answer' }));
    await screen.findByRole('dialog');
    expect(localStorage.getItem('total_stars')).toBe('10');
    expect(localStorage.getItem('ss_free_solves')).toBeNull();
  });
});