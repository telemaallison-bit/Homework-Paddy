import { Share2 } from 'lucide-react';
import { useApp } from '@/lib/app-store';
import { lagosDay } from '@/lib/free-learning';

const KEY = 'ss_invite_star_day';

/** WhatsApp invite; gives one bonus star per Lagos day. */
export function InviteParent() {
  const { addBonusStar } = useApp();
  const share = () => {
    const url = window.location.origin;
    const text = `Homework Paddy helps my child with homework step by step, with pictures and voice — free! Try it: ${url}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    const today = lagosDay(new Date());
    if (localStorage.getItem(KEY) !== today) { localStorage.setItem(KEY, today); addBonusStar(); }
  };
  return (
    <button onClick={share} className="flex min-h-20 w-full items-center justify-center gap-3 rounded-[20px] bg-primary p-4 text-lg font-black text-primary-foreground shadow-lg">
      <Share2 className="shrink-0" /> Invite a Parent - Get 1 extra star ⭐
    </button>
  );
}
