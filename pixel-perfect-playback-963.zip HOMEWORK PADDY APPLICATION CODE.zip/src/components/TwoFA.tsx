import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-store";
import { generateBackupCodes, hashCode, twofaMarker } from "@/lib/twofa";
import { disableTwoFA, enableTwoFA, getTwoFAStatus, useBackupCode } from "@/lib/twofa.functions";
import { Button } from "@/components/ui/button";
import { Bird, Screen } from "./ui-kit";

type Step = "off" | "confirm" | "setup" | "on" | "viewCodes" | "disableWarn";

/** Settings section: turn 2FA on/off, see backup codes. */
export function TwoFASection() {
  const { t, speak } = useApp();
  const [step, setStep] = useState<Step>("off");
  const [busy, setBusy] = useState(false);
  const [codes, setCodes] = useState<string[]>([]);
  const [codesLeft, setCodesLeft] = useState(0);
  const [qr, setQr] = useState<string>("");
  const [err, setErr] = useState("");

  useEffect(() => {
    getTwoFAStatus().then((s) => {
      setStep(s.enabled ? "on" : "off");
      setCodesLeft(s.codesLeft);
    }).catch(() => {});
  }, []);

  const startSetup = async () => {
    setBusy(true); setErr("");
    try {
      const fresh = generateBackupCodes();
      const hashes = await Promise.all(fresh.map(hashCode));
      await enableTwoFA({ data: { codes: hashes } });
      setCodes(fresh);
      setCodesLeft(fresh.length);
      // Bonus: authenticator app QR (best-effort; email code is the main factor).
      try {
        const r = await supabase.auth.mfa.enroll({ factorType: "totp", friendlyName: "Homework Paddy" });
        if (r.data?.totp?.qr_code) setQr(r.data.totp.qr_code);
      } catch { /* authenticator is optional */ }
      setStep("setup");
      speak(t("twofaEnabled"));
    } catch {
      setErr(t("wrongCode"));
    } finally {
      setBusy(false);
    }
  };

  const regenCodes = async () => {
    setBusy(true);
    try {
      const fresh = generateBackupCodes();
      const hashes = await Promise.all(fresh.map(hashCode));
      await enableTwoFA({ data: { codes: hashes } });
      setCodes(fresh);
      setCodesLeft(fresh.length);
    } finally {
      setBusy(false);
    }
  };

  const turnOff = async () => {
    setBusy(true);
    try {
      await disableTwoFA();
      try {
        const factors = await supabase.auth.mfa.listFactors();
        for (const f of factors.data?.all ?? []) await supabase.auth.mfa.unenroll({ factorId: f.id });
      } catch { /* best effort */ }
      setStep("off");
    } finally {
      setBusy(false);
    }
  };

  const codeList = codes.length > 0 && (
    <div className="flex flex-col gap-2 rounded-2xl bg-muted p-4">
      <p className="text-sm font-bold">{t("backupSave")}</p>
      <div className="grid grid-cols-1 gap-1 text-center">
        {codes.map((c) => <code key={c} className="rounded-lg bg-background py-2 text-lg font-black tracking-widest">{c}</code>)}
      </div>
    </div>
  );

  return (
    <section className="flex flex-col gap-2">
      <h2 className="text-lg font-black">{t("secureAccount")}</h2>

      {step === "off" && (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-border p-4">
          <div className="flex items-center justify-between gap-2">
            <p className="text-base font-black">{t("enable2fa")}</p>
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-black text-secondary-foreground">{t("recommended")}</span>
          </div>
          <p className="text-sm font-semibold text-muted-foreground">{t("twofaDesc")}</p>
          <Button className="min-h-12" onClick={() => setStep("confirm")}>🔐 {t("enable2fa")}</Button>
        </div>
      )}

      {step === "confirm" && (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-primary p-4">
          <p className="text-base font-bold">{t("twofaConfirm")}</p>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" className="min-h-12" onClick={() => setStep("off")}>{t("cancel")}</Button>
            <Button className="min-h-12" disabled={busy} onClick={startSetup}>{busy ? "…" : t("verify")}</Button>
          </div>
          {err && <p className="text-sm font-bold text-destructive">{err}</p>}
        </div>
      )}

      {step === "setup" && (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-primary p-4">
          <p className="text-center text-xl font-black">{t("twofaEnabled")}</p>
          {qr && (
            <div className="flex flex-col items-center gap-2">
              <p className="text-sm font-bold">{t("qrBonus")}</p>
              <div className="rounded-2xl bg-background p-3" dangerouslySetInnerHTML={{ __html: qr }} />
            </div>
          )}
          <p className="text-base font-black">{t("backupTitle")}</p>
          {codeList}
          <Button className="min-h-12" onClick={() => setStep("on")}>{t("verify")}</Button>
        </div>
      )}

      {step === "on" && (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-border p-4">
          <p className="text-base font-black">{t("twofaOn")}</p>
          <Button variant="outline" className="min-h-12" onClick={() => setStep("viewCodes")}>🔑 {t("viewBackup")}</Button>
          <Button variant="outline" className="min-h-12" onClick={() => setStep("disableWarn")}>{t("disable2fa")}</Button>
        </div>
      )}

      {step === "viewCodes" && (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-border p-4">
          <p className="text-base font-black">{t("backupTitle")}</p>
          {codeList ?? null}
          {codes.length === 0 && (
            <>
              <p className="text-sm font-semibold text-muted-foreground">{t("codesHidden", { n: codesLeft })}</p>
              <Button variant="outline" className="min-h-12" disabled={busy} onClick={regenCodes}>{busy ? "…" : t("makeNewCodes")}</Button>
            </>
          )}
          <Button className="min-h-12" onClick={() => setStep("on")}>{t("close")}</Button>
        </div>
      )}

      {step === "disableWarn" && (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-destructive p-4">
          <p className="text-base font-bold">⚠️ {t("disableWarn")}</p>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" className="min-h-12" onClick={() => setStep("on")}>{t("cancel")}</Button>
            <Button variant="destructive" className="min-h-12" disabled={busy} onClick={turnOff}>{busy ? "…" : t("disable2fa")}</Button>
          </div>
        </div>
      )}
    </section>
  );
}

/** Login second step: 6-digit email code, authenticator code, or a backup code. */
export function TwoFACheck({ email, userId, onPass }: { email: string; userId: string; onPass: () => void }) {
  const { t } = useApp();
  const [mode, setMode] = useState<"email" | "totp" | "backup">("email");
  const [hasTotp, setHasTotp] = useState(false);
  const [code, setCode] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: false } })
      .then((r) => { if (!r.error) setSent(true); });
    supabase.auth.mfa.listFactors().then((r) => {
      if ((r.data?.totp ?? []).some((f) => f.status === "verified")) setHasTotp(true);
    }).catch(() => {});
  }, [email]);

  const pass = () => {
    sessionStorage.setItem(twofaMarker(userId), "1");
    onPass();
  };

  const check = async () => {
    setBusy(true); setErr("");
    try {
      if (mode === "email") {
        const r = await supabase.auth.verifyOtp({ email, token: code.trim(), type: "email" });
        if (r.error) throw r.error;
        pass();
      } else if (mode === "totp") {
        const factors = await supabase.auth.mfa.listFactors();
        const factor = (factors.data?.totp ?? []).find((f) => f.status === "verified");
        if (!factor) throw new Error("no totp");
        const ch = await supabase.auth.mfa.challenge({ factorId: factor.id });
        if (ch.error) throw ch.error;
        const v = await supabase.auth.mfa.verify({ factorId: factor.id, challengeId: ch.data.id, code: code.trim() });
        if (v.error) throw v.error;
        pass();
      } else {
        const hashed = await hashCode(code);
        const r = await useBackupCode({ data: { code: hashed } });
        if (!r.ok) throw new Error("bad code");
        pass();
      }
    } catch {
      setErr(t("wrongCode"));
    } finally {
      setBusy(false);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <Screen>
      <div className="flex flex-col items-center gap-4 p-6 text-center">
        <Bird className="h-24 w-24" />
        <h1 className="text-2xl font-black">🔐 {t("enterCode")}</h1>
        {mode === "email" && sent && <p className="text-sm font-bold text-muted-foreground">{t("codeSent")}</p>}
        <input
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder={mode === "backup" ? t("backupPh") : "123456"}
          aria-label={t("enterCode")}
          inputMode={mode === "backup" ? "text" : "numeric"}
          autoComplete="one-time-code"
          className="min-h-[64px] w-full rounded-3xl border-2 border-input px-5 text-center text-2xl font-black tracking-widest outline-none focus:border-primary"
        />
        <button className="cta w-full" disabled={busy || !code.trim()} onClick={check}>
          {busy ? "…" : t("verify")}
        </button>
        <div className="flex flex-col gap-2">
          {mode !== "email" && (
            <button className="text-sm font-bold underline" onClick={() => { setMode("email"); setErr(""); setCode(""); }}>{t("useEmailCode")}</button>
          )}
          {mode !== "backup" && (
            <button className="text-sm font-bold underline" onClick={() => { setMode("backup"); setErr(""); setCode(""); }}>{t("useBackup")}</button>
          )}
          {mode !== "totp" && hasTotp && (
            <button className="text-sm font-bold underline" onClick={() => { setMode("totp"); setErr(""); setCode(""); }}>{t("useAuthenticator")}</button>
          )}
        </div>
        {err && <p className="text-base font-bold text-destructive">{err}</p>}
        <button className="text-sm font-bold text-muted-foreground underline" onClick={signOut}>{t("logout")}</button>
      </div>
    </Screen>
  );
}
