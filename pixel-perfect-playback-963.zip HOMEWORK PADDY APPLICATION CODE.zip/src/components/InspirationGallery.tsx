import { Button } from "@/components/ui/button";
import { HAIR_STYLES, type Gender, type HairStyle } from "@/lib/hair";
import inspoBoxBraids from "@/assets/inspo-box-braids.jpg";
import inspoAfro from "@/assets/inspo-afro.jpg";
import inspoSkinFade from "@/assets/inspo-skin-fade.jpg";
import inspoFullBeard from "@/assets/inspo-full-beard.jpg";

type Inspo = { img: string; style: HairStyle; g: Gender | "both" };
const INSPO: Inspo[] = [
  { img: inspoBoxBraids, style: "braids", g: "female" },
  { img: inspoAfro, style: "afro", g: "both" },
  { img: inspoSkinFade, style: "lowcut_skin_fade", g: "male" },
  { img: inspoFullBeard, style: "beard_full_short", g: "male" },
];

export function InspirationGallery({ gender, title, hint, tryLabel, nameOf, onTry }: {
  gender: Gender | null;
  title: string;
  hint: string;
  tryLabel: string;
  nameOf: (id: HairStyle) => string;
  onTry: (id: HairStyle) => void;
}) {
  const g = gender ?? "female";
  const items = INSPO.filter((i) => i.g === "both" || i.g === g);
  return <section className="flex flex-col gap-3" aria-label={title}>
    <h2 className="text-xl font-extrabold">✨ {title}</h2>
    <p className="text-sm text-muted-foreground">{hint}</p>
    <div className="collection-grid gap-3">
      {items.map((i) => <figure key={i.style} className="flex flex-col gap-2 rounded-lg border-2 border-border p-2">
        <img src={i.img} alt={nameOf(i.style)} loading="lazy" width={736} height={912} className="aspect-[4/5] h-auto w-full max-w-full rounded-md object-cover" />
        <figcaption className="text-center text-sm font-bold">{nameOf(i.style)}</figcaption>
        <Button variant="secondary" className="min-h-11 h-auto whitespace-normal text-sm" onClick={() => onTry(i.style)}>{tryLabel}</Button>
      </figure>)}
    </div>
  </section>;
}

export function googleImagesUrl(query: string) {
  return `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(query)}`;
}

export function googleQueryFor(ids: HairStyle[]): string {
  const first = HAIR_STYLES.find((s) => s.id === ids[0]);
  return first?.gsearch ?? "nigerian hairstyles 2026";
}
