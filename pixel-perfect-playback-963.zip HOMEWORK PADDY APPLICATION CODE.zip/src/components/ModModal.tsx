import { useState } from "react";
import { Flag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

/** Respectful decline modal shown when content is blocked. */
export function ModModal({ open, title, message, button, onClose }: {
  open: boolean; title: string; message: string; button: string; onClose: () => void;
}) {
  if (!open) return null;
  return <div role="alertdialog" aria-modal="true" aria-label={title} className="fixed inset-0 z-50 grid place-items-center bg-foreground/60 p-4">
    <div className="flex w-full max-w-sm flex-col gap-4 rounded-2xl bg-card p-6 text-center shadow-xl">
      <h2 className="text-xl font-black">{title}</h2>
      <p className="text-base leading-relaxed">{message}</p>
      <Button className="cta h-auto whitespace-normal" onClick={onClose}>{button}</Button>
    </div>
  </div>;
}

/** Small report button; logs a user report (reason + time only, never the image). */
export function ReportButton({ label, thanks, what }: { label: string; thanks: string; what: string }) {
  const [done, setDone] = useState(false);
  const report = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) await supabase.from("blocked_logs").insert({ user_id: user.id, reason: `user_report:${what}` });
    setDone(true);
  };
  if (done) return <p role="status" className="text-center text-sm font-bold text-muted-foreground">{thanks}</p>;
  return <button type="button" onClick={report} className="mx-auto flex items-center gap-1 text-sm font-bold text-muted-foreground underline">
    <Flag className="h-4 w-4" />{label}
  </button>;
}
