import { useEffect, useState, type ReactNode } from "react";
import { useApp } from "@/lib/app-store";
import { getTwoFAStatus } from "@/lib/twofa.functions";
import { twofaMarker } from "@/lib/twofa";
import { SignIn } from "./SignIn";
import { TwoFACheck } from "./TwoFA";
import { Screen } from "./ui-kit";
import { WelcomeOnce } from "./Welcome";

/** Requires a signed-in user before showing paid features. */
export function Gate({ children }: { children: ReactNode }) {
  const { ready, session } = useApp();
  const userId = session?.user?.id ?? "";
  const email = session?.user?.email ?? "";
  const [twofa, setTwofa] = useState<"unknown" | "off" | "on" | "passed">("unknown");

  useEffect(() => {
    if (!userId) { setTwofa("unknown"); return; }
    if (sessionStorage.getItem(twofaMarker(userId))) { setTwofa("passed"); return; }
    let live = true;
    getTwoFAStatus()
      .then((s) => { if (live) setTwofa(s.enabled ? "on" : "off"); })
      .catch(() => { if (live) setTwofa("off"); });
    return () => { live = false; };
  }, [userId]);

  if (!ready) return <Screen><div /></Screen>;
  if (!session) return <SignIn />;
  if (twofa === "unknown") return <Screen><div /></Screen>;
  if (twofa === "on") return <TwoFACheck email={email} userId={userId} onPass={() => setTwofa("passed")} />;
  return <WelcomeOnce>{children}</WelcomeOnce>;
}

export function BannerAd() {
  const { isPaid, t } = useApp();
  if (isPaid) return null;
  return <div className="mt-auto border-t-2 border-dashed border-border bg-muted p-4 text-center text-base text-muted-foreground">{t("ad")}</div>;
}
