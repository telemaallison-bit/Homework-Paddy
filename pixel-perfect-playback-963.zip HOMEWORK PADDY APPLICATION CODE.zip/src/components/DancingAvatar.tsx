import { lazy, Suspense } from 'react';
import { ClientOnly } from '@tanstack/react-router';
import girl from '@/assets/celebration/girl.png';
import boy from '@/assets/celebration/boy.png';
import type { RewardGender } from '@/lib/rewards';
const Player = lazy(() => import('./DancingAvatarPlayer'));
export function DancingAvatar({ gender, levelUp = false }: { gender: RewardGender; levelUp?: boolean }) {
  const fallback = <img src={gender === 'girl' ? girl : boy} width={816} height={816} alt={`Superstar ${gender}`} className="dancing-avatar object-contain" />;
  return <ClientOnly fallback={fallback}><Suspense fallback={fallback}><Player gender={gender} levelUp={levelUp} /></Suspense></ClientOnly>;
}