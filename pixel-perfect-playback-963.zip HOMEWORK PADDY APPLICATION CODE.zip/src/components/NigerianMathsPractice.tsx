import { ArrowRight, ChevronDown, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { problemsForLevel, type NigerianProblem } from "@/lib/maths/nigerian-practice";
import type { MathsLevel } from "@/lib/maths/model";

export function NigerianMathsPractice({ level, disabled, onUse, onHear }: {
  level: MathsLevel;
  disabled: boolean;
  onUse: (problem: NigerianProblem) => void;
  onHear: (text: string) => void;
}) {
  return <section aria-label="Nigerian maths practice" className="flex min-w-0 flex-col gap-4">
    <div className="flex flex-wrap items-end justify-between gap-2">
      <div><p className="text-sm font-bold text-primary">{level} · Pidgin</p><h2 className="text-2xl font-black">Naija maths, step by step</h2></div>
      <p className="text-xs text-muted-foreground">Original practice · Sample amounts</p>
    </div>
    <div className="collection-grid items-start gap-4">{problemsForLevel(level).map((problem, index) => <article key={problem.id} className="flex min-w-0 flex-col gap-3 rounded-lg border border-border bg-card p-4">
      <p className="text-xs font-bold text-primary">{problem.topic}</p>
      <h3 className="text-lg font-extrabold">{problem.title}</h3>
      <p className="text-base leading-relaxed">{problem.question}</p>
      <details key={`${level}-${problem.id}`} open={index === 0} className="group border-t border-border pt-3">
        <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between gap-2 font-bold">Pidgin worked answer<ChevronDown className="h-4 w-4 shrink-0 transition-transform group-open:rotate-180" /></summary>
        <div className="mt-3 flex flex-col gap-4">
          <ol className="flex flex-col gap-4">{problem.steps.map((step, i) => <li key={i} className="flex flex-col gap-2"><p className="text-base leading-relaxed"><span className="font-extrabold">{i + 1}. </span>{step.explanation}</p><p className="break-words rounded-lg bg-secondary p-3 font-extrabold text-secondary-foreground">{step.equation}</p></li>)}</ol>
          <p className="border-l-2 border-primary pl-3 font-extrabold">{problem.answer}</p>
          <p className="text-sm leading-relaxed text-muted-foreground">{problem.check}</p>
          <Button variant="ghost" disabled={disabled} className="h-auto min-h-11 justify-start gap-2 whitespace-normal px-0 text-left" onClick={() => onHear([problem.question, ...problem.steps.map(step => `${step.explanation} ${step.equation}`), problem.answer, problem.check].join("\n"))}><Volume2 className="h-5 w-5 shrink-0" />Hear Pidgin explanation</Button>
        </div>
      </details>
      <Button variant="outline" disabled={disabled} className="mt-auto h-auto min-h-12 gap-2 whitespace-normal" onClick={() => onUse(problem)}>Use this question<ArrowRight className="h-4 w-4 shrink-0" /></Button>
    </article>)}</div>
  </section>;
}