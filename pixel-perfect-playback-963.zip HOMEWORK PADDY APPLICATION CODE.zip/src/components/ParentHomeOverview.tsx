import { Component, Suspense, type ReactNode } from 'react';
import { Link } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { useSuspenseQuery } from '@tanstack/react-query';
import { ArrowRight, BookOpenCheck, CalendarDays, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useApp } from '@/lib/app-store';
import { DASHBOARD_COPY } from '@/lib/parent-dashboard';
import { PARENT_HOME_COPY } from '@/lib/parent-home';
import { getParentDashboard } from '@/lib/parent-dashboard.functions';

class ProgressBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  override render() { return this.state.failed ? this.props.fallback : this.props.children; }
}

export function ParentHomeOverview() {
  const { lang, session } = useApp();
  const c = DASHBOARD_COPY[lang ?? 'en'];
  const h = PARENT_HOME_COPY[lang ?? 'en'];
  if (!session) return <section className="border-y border-border py-6"><Button asChild variant="outline" className="h-auto min-h-20 w-full whitespace-normal gap-2"><Link to="/parent-dashboard" search={{ page: 1 }}><BookOpenCheck className="h-6 w-6 shrink-0"/>{h.signIn}</Link></Button></section>;
  return <ProgressBoundary key={session.user.id} fallback={<section className="border-y border-border py-6"><p role="alert" className="mb-3 text-muted-foreground">{c.error}</p><Button variant="outline" onClick={() => window.location.reload()}>{c.retry}</Button></section>}>
    <Suspense fallback={<p role="status" className="py-6 text-muted-foreground">{c.loading}</p>}><SavedProgress /></Suspense>
  </ProgressBoundary>;
}

function SavedProgress() {
  const { lang, session } = useApp();
  const c = DASHBOARD_COPY[lang ?? 'en'];
  const h = PARENT_HOME_COPY[lang ?? 'en'];
  const getDashboard = useServerFn(getParentDashboard);
  const { data } = useSuspenseQuery({
    queryKey: ['parent-dashboard', session?.user.id, 1],
    queryFn: () => getDashboard({ data: { page: 1 } }),
    staleTime: 0,
  });
  const stats = data.stats;
  return <>
    <section className="collection-grid gap-4" aria-label={c.progress}>
      {[{ label: c.today, value: stats.todaySolved, Icon: BookOpenCheck, tone: 'text-tile-4' }, { label: c.week, value: stats.weekSolved, Icon: CalendarDays, tone: 'text-tile-3' }, { label: c.active, value: stats.activeDays, Icon: TrendingUp, tone: 'text-tile-1' }].map(item =>
        <div key={item.label} className="flex items-center gap-4 rounded-lg border border-border bg-card p-5"><item.Icon className={`h-8 w-8 shrink-0 ${item.tone}`}/><div><p className="text-3xl font-bold tabular-nums">{item.value}</p><p className="text-sm font-semibold text-muted-foreground">{item.label}</p></div></div>)}
    </section>
    <section className="flex flex-col gap-4 border-y border-border py-6" aria-label={h.recent}>
      <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-bold">{h.recent}</h2><Button asChild variant="link" className="h-auto whitespace-normal p-0"><Link to="/parent-dashboard" search={{ page: 1 }}>{h.all}<ArrowRight className="h-4 w-4 shrink-0"/></Link></Button></div>
      {data.history.length ? data.history.slice(0, 3).map(row => <Link key={row.id} to="/parent-dashboard" search={{ page: 1 }} className="flex items-start justify-between gap-3 rounded-lg border border-border bg-card p-4 transition-colors hover:bg-secondary"><div className="min-w-0"><p className="mb-1 text-xs font-semibold text-muted-foreground">{row.feature === 'maths' ? c.maths : c.homework} · {row.level}</p><h3 className="line-clamp-2 font-semibold">{row.question}</h3><p className="mt-2 line-clamp-2 text-sm text-muted-foreground"><strong>{c.answer}: </strong>{row.answer}</p></div><ArrowRight className="mt-1 h-5 w-5 shrink-0 text-primary"/></Link>) : <p className="text-muted-foreground">{c.empty}</p>}
      <p className="text-xs text-muted-foreground">{h.account}</p>
    </section>
  </>;
}