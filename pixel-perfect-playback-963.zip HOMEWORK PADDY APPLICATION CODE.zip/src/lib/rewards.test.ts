import { beforeEach, describe, expect, it } from 'vitest';
import { EMPTY_REWARD_STATE, awardSolveReward, readRewardState, writeRewardState, rewardLevel, readRewardGender, currentStreak } from './rewards';

describe('Super Paddy rewards', () => {
  beforeEach(() => localStorage.clear());

  it('awards exactly ten stars for each completed solve', () => {
    const first = awardSolveReward(EMPTY_REWARD_STATE, new Date('2026-10-23T08:00:00Z'));
    const second = awardSolveReward(first, new Date('2026-10-23T09:00:00Z'));
    expect(first.stars).toBe(10);
    expect(second.stars).toBe(20);
  });

  it('keeps one streak for several solves on the same Lagos day', () => {
    const first = awardSolveReward(EMPTY_REWARD_STATE, new Date('2026-10-23T08:00:00Z'));
    const second = awardSolveReward(first, new Date('2026-10-23T21:00:00Z'));
    expect(second.streak).toBe(1);
    expect(second.lastLagosDay).toBe('2026-10-23');
  });

  it('adds one streak on the next Lagos day', () => {
    const first = awardSolveReward(EMPTY_REWARD_STATE, new Date('2026-10-23T08:00:00Z'));
    const second = awardSolveReward(first, new Date('2026-10-24T08:00:00Z'));
    expect(second.streak).toBe(2);
  });

  it('restarts the streak after a missed Lagos day', () => {
    const first = awardSolveReward(EMPTY_REWARD_STATE, new Date('2026-10-23T08:00:00Z'));
    const later = awardSolveReward(first, new Date('2026-10-26T08:00:00Z'));
    expect(later.streak).toBe(1);
  });

  it('saves and reads stars and streak locally', () => {
    const state = { stars: 4, streak: 2, lastLagosDay: new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' }) };
    writeRewardState(state);
    expect(readRewardState()).toEqual(state);
    expect(localStorage.getItem('total_stars')).toBe('4');
  });
  it('advances one level for every fifty stars starting at level one', () => {
    expect(rewardLevel(0)).toBe(1); expect(rewardLevel(49)).toBe(1);
    expect(rewardLevel(50)).toBe(2); expect(rewardLevel(120)).toBe(3); expect(rewardLevel(150)).toBe(4);
  });
  it('keeps historical stars without multiplying them', () => {
    localStorage.setItem('ss_super_paddy_stars', '12'); expect(readRewardState().stars).toBe(12);
    localStorage.setItem('total_stars', '22'); expect(readRewardState().stars).toBe(22);
  });
  it('reads the chosen girl or boy independently of hairstyle preferences', () => {
    localStorage.setItem('ss_gender', 'female'); expect(readRewardGender()).toBeNull();
    localStorage.setItem('user_gender', 'girl'); expect(readRewardGender()).toBe('girl');
    localStorage.setItem('user_gender', 'boy'); expect(readRewardGender()).toBe('boy');
  });
  it('does not show an expired streak', () => {
    expect(currentStreak(3, '2026-10-20', new Date('2026-10-23T08:00:00Z'))).toBe(0);
    expect(currentStreak(3, '2026-10-22', new Date('2026-10-23T08:00:00Z'))).toBe(3);
  });
});
