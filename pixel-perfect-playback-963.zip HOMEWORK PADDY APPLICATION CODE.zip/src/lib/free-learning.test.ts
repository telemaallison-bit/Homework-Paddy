import { describe, expect, it } from 'vitest';
import { DAILY_FREE_SOLVES, AD_EXTRA_SOLVES, PREMIUM_OPTIONS, PAYMENTS_ENABLED, remainingSolves, lagosDay } from './free-learning';
describe('Free-for-now learning rules', () => {
  it('grants exactly three daily solves and blocks the fourth', () => { expect(DAILY_FREE_SOLVES).toBe(3); expect([0,1,2,3,4].map(n => remainingSolves(n))).toEqual([3,2,1,0,0]); });
  it('one ad adds exactly two solves', () => { expect(AD_EXTRA_SOLVES).toBe(2); expect(remainingSolves(3, AD_EXTRA_SOLVES)).toBe(2); });
  it('does not permit paid purchases', () => { expect(PAYMENTS_ENABLED).toBe(false); });
  it('keeps coming-soon prices at three days N200 and one week N500', () => { expect(PREMIUM_OPTIONS).toEqual([{ days:3, naira:200 }, { days:7, naira:500 }]); });
  it('resets on the Nigerian calendar day', () => { expect(lagosDay(new Date('2026-10-22T22:59:59Z'))).toBe('2026-10-22'); expect(lagosDay(new Date('2026-10-22T23:00:00Z'))).toBe('2026-10-23'); });
});