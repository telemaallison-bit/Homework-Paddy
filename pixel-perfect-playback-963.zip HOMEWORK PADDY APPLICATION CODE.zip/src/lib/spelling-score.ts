export function pronunciationScore(target: string, heard: string) {
  const a = target.toLowerCase(), b = heard.toLowerCase().replace(/[^a-z]/g, '');
  if (!b) return 0;
  if (b === a) return 10;
  let m = 0; for (let i = 0; i < a.length; i++) if (b[i] === a[i]) m++;
  return Math.max(1, Math.round((m / Math.max(a.length, b.length)) * 9));
}
export function correctPronunciation(target: string, heard: string) { return pronunciationScore(target, heard) >= 7; }
export function correctTyping(target: string, typed: string) { return Boolean(target.trim()) && target.trim().toLowerCase() === typed.trim().toLowerCase(); }