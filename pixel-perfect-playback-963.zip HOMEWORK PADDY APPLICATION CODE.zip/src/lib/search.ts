// Smart Search helpers: suggestions, tip topics, and DuckDuckGo instant-answer parsing.
// DuckDuckGo's instant-answer API is free and keyless; Google/YouTube results open in a new tab
// (Google blocks in-app iframes).

export type SearchResult = { title: string; snippet: string; url: string };

export const SUGGESTIONS: string[] = [
  "low cut fade",
  "how to keep afro",
  "best beard oil Nigeria",
  "braids price Lagos",
  "how to maintain box braids",
  "360 waves tutorial",
  "cornrows styles for men",
  "ankara styles 2026",
];

// Fixed topics for the "Today's Hair Tips" section on Home.
export const TIP_TOPICS: { query: string; emoji: string }[] = [
  { query: "box braids care", emoji: "💇🏾‍♀️" },
  { query: "360 waves", emoji: "🌊" },
  { query: "beard care", emoji: "🧔🏾" },
];

export function googleSearchUrl(query: string): string {
  return `https://www.google.com/search?q=${encodeURIComponent(query + " hair care nigeria")}`;
}

export function youtubeSearchUrl(query: string): string {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
}

type DdgTopic = { Text?: string; FirstURL?: string; Topics?: DdgTopic[] };
type DdgResponse = {
  AbstractText?: string;
  AbstractURL?: string;
  Heading?: string;
  RelatedTopics?: DdgTopic[];
};

function flatten(topics: DdgTopic[] | undefined, out: DdgTopic[]): void {
  for (const t of topics ?? []) {
    if (t.Topics) flatten(t.Topics, out);
    else if (t.Text && t.FirstURL) out.push(t);
  }
}

// Parse a DuckDuckGo instant-answer response into up to `limit` result cards.
export function parseDdg(j: DdgResponse, limit = 5): SearchResult[] {
  const out: SearchResult[] = [];
  if (j.AbstractText && j.AbstractURL) {
    out.push({ title: j.Heading || j.AbstractURL, snippet: j.AbstractText, url: j.AbstractURL });
  }
  const flat: DdgTopic[] = [];
  flatten(j.RelatedTopics, flat);
  for (const t of flat) {
    if (out.length >= limit) break;
    const text = t.Text!;
    const dash = text.indexOf(" - ");
    const title = dash > 0 ? text.slice(0, dash) : text.slice(0, 60);
    const snippet = dash > 0 ? text.slice(dash + 3) : text;
    out.push({ title, snippet, url: t.FirstURL! });
  }
  return out.slice(0, limit);
}
