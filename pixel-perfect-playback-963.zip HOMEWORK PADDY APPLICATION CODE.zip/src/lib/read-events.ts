export async function readEvents(response: Response, onEvent:(event:Record<string,unknown>)=>void) {
  if(!response.ok){const failure=await response.json();throw new Error(failure.message??'Could not continue.');}
  if(!response.body)throw new Error('No response arrived.');
  const reader=response.body.pipeThrough(new TextDecoderStream()).getReader();let pending='';
  const consume=(line:string)=>{if(!line.trim())return;const e=JSON.parse(line);if(e.type==='error'||e.type==='denied')throw new Error(e.message);onEvent(e);};
  try{while(true){const chunk=await reader.read();if(chunk.done)break;pending+=chunk.value;const lines=pending.split('\n');pending=lines.pop()??'';for(const line of lines)consume(line);}consume(pending);}finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}