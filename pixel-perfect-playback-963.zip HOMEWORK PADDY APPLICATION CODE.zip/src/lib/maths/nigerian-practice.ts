import type { MathsLevel } from "./model";

export type NigerianProblem = {
  id: string;
  level: MathsLevel;
  title: string;
  topic: string;
  question: string;
  steps: { explanation: string; equation: string }[];
  answer: string;
  values: number[];
  check: string;
};

// Original practice questions, not official exam questions or current market prices.
export const NIGERIAN_PROBLEMS: NigerianProblem[] = [
  {
    id: "market-change", level: "Primary", title: "Change for market", topic: "Money · subtraction",
    question: "Ngozi buys tomatoes for ₦650 and pepper for ₦250 at the market. She pays with ₦1,000. How much change should she receive?",
    steps: [
      { explanation: "First, join the money for tomatoes and pepper. Na the total money wey Ngozi spend be this.", equation: "₦650 + ₦250 = ₦900" },
      { explanation: "Remove wetin she spend from the ₦1,000 wey she give seller. The money wey remain na her change.", equation: "₦1,000 − ₦900 = ₦100" },
    ], answer: "Ngozi go collect ₦100 change.", values: [100], check: "Check am: ₦900 for goods + ₦100 change = ₦1,000. E balance!",
  },
  {
    id: "share-oranges", level: "Primary", title: "Share oranges", topic: "Equal sharing · division",
    question: "Amina shares 24 oranges equally among 6 classmates in Kano. How many oranges does each classmate receive?",
    steps: [
      { explanation: "We get 24 oranges and 6 people. Since everybody must get the same number, we go divide, no be add.", equation: "24 ÷ 6 = 4" },
      { explanation: "Give each person 4 oranges. Count all six groups to make sure say no orange remain.", equation: "4 + 4 + 4 + 4 + 4 + 4 = 24" },
    ], answer: "Each classmate go get 4 oranges.", values: [4], check: "Check am: 6 people × 4 oranges = 24 oranges.",
  },
  {
    id: "school-books", level: "Primary", title: "Books for class", topic: "Counting · addition",
    question: "A class in Ibadan has 18 storybooks. The teacher brings 12 more. How many storybooks does the class have now?",
    steps: [
      { explanation: "The teacher bring more books, so the number go increase. Start with the 18 books wey dey before.", equation: "18 + 12" },
      { explanation: "Break 12 into 10 and 2. Add 10 first, then add the remaining 2.", equation: "18 + 10 = 28; 28 + 2 = 30" },
    ], answer: "The class get 30 storybooks now.", values: [30], check: "Check am: remove the 12 new books from 30. You go get the original 18.",
  },
  {
    id: "rice-fractions", level: "JSS", title: "Rice for supper", topic: "Fractions · subtraction",
    question: "Chidi has 3/4 kg of rice in Enugu. He cooks 1/4 kg for supper. How much rice remains?",
    steps: [
      { explanation: "Both fractions get 4 for bottom. This mean say the pieces na the same size, so leave the bottom number as 4.", equation: "3/4 − 1/4 = (3 − 1)/4 = 2/4" },
      { explanation: "Divide the top and bottom by 2 to make the fraction simpler. Two quarters na the same thing as one half.", equation: "2/4 = 1/2" },
    ], answer: "Na 1/2 kg of rice remain.", values: [0.5], check: "Check am: 1/2 kg remaining + 1/4 kg cooked = 3/4 kg.",
  },
  {
    id: "bag-discount", level: "JSS", title: "School-bag discount", topic: "Percentages · discount",
    question: "A shop in Lagos offers 15% off a school bag priced at ₦20,000. How much is the discount, and what is the new price?",
    steps: [
      { explanation: "15% mean 15 out of every 100. Multiply the original price by 15, then divide by 100 to find the discount.", equation: "15/100 × ₦20,000 = ₦3,000" },
      { explanation: "Discount na money wey seller remove, no be extra charge. Subtract ₦3,000 from the original price.", equation: "₦20,000 − ₦3,000 = ₦17,000" },
    ], answer: "Discount na ₦3,000; new price na ₦17,000.", values: [3000, 17000], check: "Check am: ₦17,000 + ₦3,000 = ₦20,000.",
  },
  {
    id: "share-ratio", level: "JSS", title: "Share pocket money", topic: "Ratio · sharing",
    question: "Bisi and Tunde share ₦2,500 in the ratio 2:3. How much does each person receive?",
    steps: [
      { explanation: "Bisi get 2 parts and Tunde get 3 parts. First, count all the parts together.", equation: "2 + 3 = 5 parts; ₦2,500 ÷ 5 = ₦500 per part" },
      { explanation: "Multiply each person's parts by ₦500. No share am half-half, because their ratio no be equal.", equation: "Bisi: 2 × ₦500 = ₦1,000; Tunde: 3 × ₦500 = ₦1,500" },
    ], answer: "Bisi get ₦1,000; Tunde get ₦1,500.", values: [1000, 1500], check: "Check am: ₦1,000 + ₦1,500 = ₦2,500, and 1,000:1,500 reduces to 2:3.",
  },
  {
    id: "school-garden", level: "SSS", title: "School garden", topic: "Quadratic equations · area",
    question: "A rectangular school garden in Abuja has width x metres and length (x + 3) metres. Its area is 40 m². Find its width and length.",
    steps: [
      { explanation: "Area of rectangle na length times width. Put the measurements inside the formula, then move 40 to the left side.", equation: "x(x + 3) = 40; x² + 3x − 40 = 0" },
      { explanation: "Find two numbers wey multiply to −40 and add to 3: na 8 and −5. Use them factorise the quadratic.", equation: "(x + 8)(x − 5) = 0; x = −8 or x = 5" },
      { explanation: "Garden width no fit be negative, so reject −8. Use x = 5, then add 3 to find the length.", equation: "Width = 5 m; length = 5 + 3 = 8 m" },
    ], answer: "Width na 5 m; length na 8 m.", values: [5, 8], check: "Check am: 5 × 8 = 40 m². The length also pass the width by 3 m.",
  },
  {
    id: "simple-interest", level: "SSS", title: "Cooperative savings", topic: "Simple interest",
    question: "A cooperative in Benin City pays simple interest of 8% per year. If a member saves ₦50,000 for 3 years, find the interest and total amount.",
    steps: [
      { explanation: "For simple interest, na only the original money earn interest. P na ₦50,000, R na 8, and T na 3 years.", equation: "I = PRT/100 = 50,000 × 8 × 3 / 100" },
      { explanation: "Calculate the interest, then add am to the original savings. No multiply by compound-interest formula here.", equation: "I = ₦12,000; total = ₦50,000 + ₦12,000 = ₦62,000" },
    ], answer: "Interest na ₦12,000; total amount na ₦62,000.", values: [12000, 62000], check: "Check am: one year's interest na ₦4,000. Three years give ₦12,000.",
  },
  {
    id: "bus-tickets", level: "SSS", title: "Bus tickets", topic: "Simultaneous equations",
    question: "For a school trip in Port Harcourt, 2 adult tickets and 3 child tickets cost ₦1,900. One adult ticket and one child ticket cost ₦800. Find each ticket price.",
    steps: [
      { explanation: "Call adult price a and child price c. Write one equation for each thing wey the question tell us.", equation: "2a + 3c = 1,900; a + c = 800" },
      { explanation: "Multiply the second equation by 2. Subtract am from the first one so the adult prices cancel.", equation: "2a + 2c = 1,600; c = 1,900 − 1,600 = 300" },
      { explanation: "Put c = 300 inside a + c = 800 to find the adult price.", equation: "a = 800 − 300 = 500" },
    ], answer: "Adult ticket na ₦500; child ticket na ₦300.", values: [500, 300], check: "Check am: 2(500) + 3(300) = ₦1,900, and 500 + 300 = ₦800.",
  },
  {
    id: "dispatch-rate", level: "University", title: "Delivery-bike motion", topic: "Calculus · differentiation",
    question: "In a simplified motion model, a delivery bike's displacement is s(t) = 3t² + 2t metres, where t is in seconds. Find its instantaneous velocity at t = 4 seconds.",
    steps: [
      { explanation: "Velocity na how fast displacement dey change with time. Differentiate s(t), no divide the total distance by time.", equation: "v(t) = ds/dt = 6t + 2" },
      { explanation: "The power rule turn 3t² into 6t, and 2t into 2. Now put t = 4 inside the velocity formula.", equation: "v(4) = 6(4) + 2 = 26 m/s" },
    ], answer: "Instantaneous velocity na 26 m/s.", values: [26], check: "Unit check: displacement dey in metres and time dey in seconds, so velocity na metres per second.",
  },
  {
    id: "compound-savings", level: "University", title: "Compound savings", topic: "Compound interest",
    question: "In a practice savings model, ₦100,000 earns 10% interest per year, compounded annually. With no deposits or withdrawals, what is the balance after 2 years?",
    steps: [
      { explanation: "Compound interest mean say next year's interest go include the interest wey you don earn. Use r = 0.10 and n = 2.", equation: "A = P(1 + r)ⁿ = 100,000(1.10)²" },
      { explanation: "After year one, balance na ₦110,000. For year two, calculate 10% of this new balance, no be the original ₦100,000.", equation: "Year 2 interest = ₦11,000; A = ₦110,000 + ₦11,000 = ₦121,000" },
    ], answer: "Balance after 2 years na ₦121,000.", values: [121000], check: "Check am: ₦100,000 × 1.1 × 1.1 = ₦121,000. This example no include fees or tax.",
  },
  {
    id: "quiz-probability", level: "University", title: "Quiz probability", topic: "Binomial probability",
    question: "A student guesses independently on 3 true-or-false quiz questions. Each guess has a 1/2 chance of being correct. What is the probability of exactly 2 correct answers?",
    steps: [
      { explanation: "Exactly 2 correct no mean at least 2. The wrong answer fit dey first, second or third, so we get 3 possible arrangements.", equation: "Number of arrangements = C(3, 2) = 3" },
      { explanation: "Each arrangement get two correct guesses and one wrong guess. Since the guesses independent, multiply their probabilities, then multiply by 3.", equation: "P(X = 2) = 3 × (1/2)² × (1/2) = 3/8 = 0.375" },
    ], answer: "Probability na 3/8, or 37.5%.", values: [0.375], check: "Check am: all 8 equally likely outcomes include exactly 3 with two correct answers.",
  },
];

export function problemsForLevel(level: MathsLevel) {
  return NIGERIAN_PROBLEMS.filter(problem => problem.level === level);
}