import type { ModelMessage } from "ai";
import { mathsInputSchema } from "./model";
import { createResponsesCall } from "./responses.server";
import { mathsPrompt } from "./prompt.server";
import { mathsUser, accessState, rememberDenial, safeError } from "./access.server";
import { createLovableAiGatewayRunIdFetch } from "./run-id.server.ts";

export async function handleMaths(request: Request) {
  let identity;
  try { identity = await mathsUser(request); } catch (e) { return Response.json({ message: e instanceof Error ? e.message : "Please sign in." }, { status: 401 }); }
  const parsed = mathsInputSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ message: "Add a valid maths question/photo, level and method." }, { status: 400 });
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return Response.json({ message: "Maths AI is not configured." }, { status: 503 });
  const model = "openai/gpt-6-astra";
  const blocked = await accessState(model);
  if (blocked) return Response.json({ message: blocked }, { status: 403 });
  const { data, error } = await identity.client.rpc("begin_maths_attempt", { _request_id: parsed.data.requestId });
  if (error) return Response.json({ message: "This question already started or could not start. Please start a new question." }, { status: 409 });
  // Growth phase: app is 100% free — solves past the daily allowance are never blocked.
  const content: Extract<ModelMessage, { role: "user" }>["content"] = [{ type: "text", text: parsed.data.question || "Solve the maths question in this photo." }];
  if (parsed.data.image) content.push({ type: "image", image: new URL(parsed.data.image) });
  const gateway = createLovableAiGatewayRunIdFetch();
  let failure = "Could not solve this question now. Your try has been returned.";
  let status = 500;
  const instructions = parsed.data.homework ? mathsPrompt(parsed.data.method, parsed.data.level, parsed.data.lang).replace('Solve only the actual maths question.', 'Solve only the selected homework question from any school subject, not the other questions in the photo. For English or science use relevant labelled picture/relationship diagrams and leave equation empty where inappropriate. Country maths methods apply only to maths; for other subjects use age-appropriate classroom explanation.') : mathsPrompt(parsed.data.method, parsed.data.level, parsed.data.lang);
  const run = createResponsesCall(request, { baseURL: "https://ai.gateway.lovable.dev/v1", apiKey, model }, [{ role: "user", content }], instructions, async (input, init) => {
    const response = await gateway.fetch(input, init);
    if (!response.ok) {
      status = response.status;
      failure = safeError(await response.clone().json().catch(() => null), failure);
      if (status === 403) await rememberDenial(model, failure);
    }
    return response;
  });
  const encoder = new TextEncoder();
  const body = new ReadableStream({ async start(controller) {
    const send = (value: unknown) => controller.enqueue(encoder.encode(`${JSON.stringify(value)}\n`));
    send({ type: "started", credits: data });
    const heartbeat = setInterval(() => send({ type: "progress" }), 8000);
    try {
      const output = await run.result.output;
      if (!output || !output.steps.length) throw new Error("Empty answer");
      const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
      const saved = await supabaseAdmin.from('learning_history').upsert({
        id: parsed.data.requestId, user_id: identity.user.id,
        question: parsed.data.question.trim() || output.question,
        topic: output.topic, answer: output.answer, solution: output,
        level: parsed.data.level, method: parsed.data.method, lang: parsed.data.lang,
        feature: parsed.data.homework ? 'homework' : 'maths',
      }, { onConflict: 'id', ignoreDuplicates: true });
      if (saved.error) throw new Error('Could not save solution');
      send({ type: "result", solution: output, credits: data });
    } catch {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.rpc("refund_maths_attempt", { _request_id: parsed.data.requestId });
      send({ type: status === 403 ? "denied" : "error", message: failure, status });
    } finally { clearInterval(heartbeat); controller.close(); }
  } });
  return new Response(body, { headers: { "Content-Type": "application/x-ndjson", "Cache-Control": "no-store" } });
}