import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export async function mathsUser(request: Request) {
  const authorization = request.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) throw new Error("Please sign in.");
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Sign-in is not configured.");
  const client = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: authorization }, fetch: (input, init) => {
      const headers = new Headers(init?.headers); headers.set("apikey", key);
      if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
      return fetch(input, { ...init, headers });
    } },
  });
  const { data, error } = await client.auth.getUser(authorization.slice(7));
  if (error || !data.user) throw new Error("Please sign in again.");
  return { client, user: data.user };
}

export async function accessState(model: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.from("ai_access_state").select("blocked,reason").eq("model", model).maybeSingle();
  if (error) throw new Error("Could not check AI availability.");
  return data?.blocked ? data.reason : null;
}
export async function rememberDenial(model: string, reason: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin.from("ai_access_state").upsert({ model, blocked: true, reason, updated_at: new Date().toISOString() });
}
export function safeError(body: unknown, fallback: string): string {
  if (body && typeof body === "object") {
    const j = body as { message?: unknown; error?: { message?: unknown } };
    const text = j.message ?? j.error?.message;
    if (typeof text === "string") return text;
  }
  return fallback;
}