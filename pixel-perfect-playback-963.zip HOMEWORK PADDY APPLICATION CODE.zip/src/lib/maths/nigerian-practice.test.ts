import { describe, expect, it } from "vitest";
import { NIGERIAN_PROBLEMS, problemsForLevel } from "./nigerian-practice";

describe("Nigerian worked maths examples", () => {
  it.each([
    ["market-change", [100]], ["share-oranges", [4]], ["school-books", [30]],
    ["rice-fractions", [0.5]], ["bag-discount", [3000, 17000]], ["share-ratio", [1000, 1500]],
    ["school-garden", [5, 8]], ["simple-interest", [12000, 62000]], ["bus-tickets", [500, 300]],
    ["dispatch-rate", [26]], ["compound-savings", [121000]], ["quiz-probability", [0.375]],
  ])("%s has the correct numerical answer", (id, expected) => {
    expect(NIGERIAN_PROBLEMS.find(problem => problem.id === id)?.values).toEqual(expected);
  });
  it.each(["Primary", "JSS", "SSS", "University"] as const)("only returns %s questions for that level", level => {
    const problems = problemsForLevel(level);
    expect(problems).toHaveLength(3);
    expect(problems.every(problem => problem.level === level)).toBe(true);
  });
});