import { z } from "zod";

export const MATHS_COST = 1;
export const METHODS = [
  { id: "singapore", name: "Singapore Method", detail: "CPA · concrete objects & bar models", flag: "🇸🇬", recommended: true },
  { id: "chinese", name: "Chinese Method", detail: "Visual reasoning · diagrams & careful steps", flag: "🇨🇳", recommended: false },
  { id: "vedic", name: "Vedic Maths", detail: "India · shortcuts with a worked check", flag: "🇮🇳", recommended: false },
  { id: "waec", name: "WAEC/Nigerian Method", detail: "Standard classroom working", flag: "🇳🇬", recommended: false },
] as const;
export const LEVELS = ["Primary", "JSS", "SSS", "University"] as const;
export type MathsMethod = typeof METHODS[number]["id"];
export type MathsLevel = typeof LEVELS[number];
export const mathsInputSchema = z.object({
  question: z.string().max(2000), image: z.string().nullable(),
  method: z.enum(["singapore", "chinese", "vedic", "waec"]), level: z.enum(LEVELS),
  lang: z.enum(["en", "pcm", "yo", "ig", "ha"]), requestId: z.string().uuid(),
  homework: z.boolean().optional(),
}).refine(d => d.question.trim() || d.image, "Type a question or add a photo")
  .refine(d => !d.image || (d.image.length < 6_000_000 && /^data:image\/(jpeg|png|webp);base64,/.test(d.image)), "Choose a valid question photo");

// Declarative shapes only: no executable SVG, HTML or model-generated code.
export const shapeSchema = z.object({
  kind: z.enum(["rect", "circle", "line", "text"]),
  x: z.number(), y: z.number(), width: z.number(), height: z.number(),
  label: z.string(), tone: z.enum(["primary", "secondary", "accent", "ink"]),
}).strict();
export const solutionSchema = z.object({
  question: z.string(), answer: z.string(), topic: z.string(), methodNote: z.string(),
  steps: z.array(z.object({ title: z.string(), explanation: z.string(), equation: z.string(),
    drawing: z.object({ caption: z.string(), shapes: z.array(shapeSchema) }).strict(),
  }).strict()), check: z.string(),
}).strict();
export type Solution = z.infer<typeof solutionSchema>;
export type Drawing = Solution["steps"][number]["drawing"];
export function initialMathsLevel(age: string | null): MathsLevel {
  return age === "jss" ? "JSS" : age === "sss" ? "SSS" : age === "adult" ? "University" : "Primary";
}
export function referenceLinks(topic: string) {
  return { khan: `https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(topic)}`,
    youtube: `https://www.youtube.com/results?search_query=${encodeURIComponent(`${topic} maths step by step`)}` };
}