import { describe, expect, it } from "vitest";
import { METHODS, LEVELS, MATHS_COST, initialMathsLevel, mathsInputSchema, referenceLinks } from "./model";
import { mathsPrompt } from "./prompt.server";
describe("Maths teaching rules", () => {
  it("offers exactly the four requested country methods", () => {
    expect(METHODS.map(m => m.id)).toEqual(["singapore", "chinese", "vedic", "waec"]);
    expect(METHODS.filter(m => m.recommended).map(m => m.id)).toEqual(["singapore"]);
  });
  it("offers Primary, JSS, SSS and University", () => {
    expect([...LEVELS]).toEqual(["Primary", "JSS", "SSS", "University"]);
    expect(initialMathsLevel("adult")).toBe("University");
  });
  it("uses one homework try for a maths solve", () => { expect(MATHS_COST).toBe(1); });
  it("rejects empty questions and unsafe image types", () => {
    const base = { question: "", image: null, method: "singapore", level: "Primary", lang: "en", requestId: "c1aef100-9761-4a00-9027-f5c680c91e88" };
    expect(mathsInputSchema.safeParse(base).success).toBe(false);
    expect(mathsInputSchema.safeParse({ ...base, image: "data:image/svg+xml;base64,abc" }).success).toBe(false);
    expect(mathsInputSchema.safeParse({ ...base, question: "24 / 6" }).success).toBe(true);
    expect(mathsInputSchema.safeParse({ ...base, image: "data:image/jpeg;base64,abc" }).success).toBe(true);
  });
  it("gives topic-specific Khan Academy and YouTube links", () => {
    const links = referenceLinks("fractions & ratios");
    expect(new URL(links.khan).searchParams.get("page_search_query")).toBe("fractions & ratios");
    expect(new URL(links.youtube).searchParams.get("search_query")).toBe("fractions & ratios maths step by step");
  });
  it("uses CPA for Singapore and does not invent Vedic university shortcuts", () => {
    expect(mathsPrompt("singapore", "Primary", "en")).toContain("Concrete-Pictorial-Abstract");
    expect(mathsPrompt("vedic", "University", "en")).toContain("Never fabricate a Vedic calculus/proof method");
  });
});