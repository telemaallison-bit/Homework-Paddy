// @vitest-environment node
import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ user: vi.fn(), state: vi.fn(), rpc: vi.fn(), refund: vi.fn(), call: vi.fn(), save: vi.fn(), from: vi.fn() }));
vi.mock("./access.server", () => ({ mathsUser: mocks.user, accessState: mocks.state, rememberDenial: vi.fn(), safeError: () => "denied" }));
vi.mock("./responses.server", () => ({ createResponsesCall: mocks.call }));
vi.mock("@/integrations/supabase/client.server", () => ({ supabaseAdmin: { rpc: mocks.refund, from:mocks.from } }));
import { handleMaths } from "./handler.server";
function request() { return new Request("https://app.test/api/maths", { method: "POST", body: JSON.stringify({ question: "24 / 6", image: null, method: "singapore", level: "Primary", lang: "en", requestId: "c1aef100-9761-4a00-9027-f5c680c91e88" }) }); }
beforeEach(() => {
  vi.resetAllMocks(); vi.stubEnv("LOVABLE_API_KEY", "test");
  mocks.user.mockResolvedValue({ client: { rpc: mocks.rpc }, user: { id: "u1" } });
  mocks.state.mockResolvedValue(null); mocks.rpc.mockResolvedValue({ data: 4, error: null });
  mocks.from.mockReturnValue({upsert:mocks.save}); mocks.save.mockResolvedValue({error:null});
  mocks.call.mockReturnValue({ result: { output: Promise.resolve({ steps: [{ title: "Share" }], answer: "4" }) } });
});
describe("Maths wallet rules", () => {
  it('saves successful solutions for only the authenticated account without photos',async()=>{
    await (await handleMaths(request())).text();
    expect(mocks.from).toHaveBeenCalledWith('learning_history');
    expect(mocks.save).toHaveBeenCalledWith(expect.objectContaining({user_id:'u1',id:'c1aef100-9761-4a00-9027-f5c680c91e88',question:'24 / 6',feature:'maths',lang:'en'}),{onConflict:'id',ignoreDuplicates:true});
    expect(mocks.save.mock.calls[0]?.[0]).not.toHaveProperty('image');
  });
  it('does not count failed generations as solved questions',async()=>{
    mocks.call.mockReturnValue({result:{get output(){return Promise.reject(new Error('failed'));}}});
    await (await handleMaths(request())).text(); expect(mocks.save).not.toHaveBeenCalled();
  });
  it('returns the allowance if successful output cannot be saved',async()=>{
    mocks.save.mockResolvedValue({error:{message:'unavailable'}});
    expect(await (await handleMaths(request())).text()).toContain('"type":"error"');
    expect(mocks.refund).toHaveBeenCalledTimes(1);
  });
  it("charges one unique attempt before generating", async () => {
    const response = await handleMaths(request()); const result = await response.text();
    expect(mocks.rpc).toHaveBeenCalledWith("begin_maths_attempt", { _request_id: "c1aef100-9761-4a00-9027-f5c680c91e88" });
    expect(mocks.rpc.mock.invocationCallOrder[0]).toBeLessThan(mocks.call.mock.invocationCallOrder[0] ?? 0);
    expect(result).toContain('"credits":4'); expect(result).toContain('"answer":"4"');
  });
  it("growth phase: still solves after daily free solves are used up", async () => {
    mocks.rpc.mockResolvedValue({ data: -1, error: null });
    expect((await handleMaths(request())).status).toBe(200); expect(mocks.call).toHaveBeenCalled();
  });
  it("does not generate twice for a duplicate request", async () => {
    mocks.rpc.mockResolvedValue({ data: null, error: { message: "Request already started" } });
    expect((await handleMaths(request())).status).toBe(409); expect(mocks.call).not.toHaveBeenCalled();
  });
  it("refunds a failed generation once through the server", async () => {
    mocks.call.mockReturnValue({ result: { get output() { return Promise.reject(new Error("failed")); } } });
    const response = await handleMaths(request()); expect(await response.text()).toContain('"type":"error"');
    expect(mocks.refund).toHaveBeenCalledTimes(1);
    expect(mocks.refund).toHaveBeenCalledWith("refund_maths_attempt", { _request_id: "c1aef100-9761-4a00-9027-f5c680c91e88" });
  });
  it("blocks signed-out callers", async () => {
    mocks.user.mockRejectedValue(new Error("Please sign in."));
    expect((await handleMaths(request())).status).toBe(401); expect(mocks.rpc).not.toHaveBeenCalled();
  });
  it("does not repeat a persisted denied call", async () => {
    mocks.state.mockResolvedValue("Provider access denied");
    expect((await handleMaths(request())).status).toBe(403); expect(mocks.call).not.toHaveBeenCalled(); expect(mocks.rpc).not.toHaveBeenCalled();
  });
});