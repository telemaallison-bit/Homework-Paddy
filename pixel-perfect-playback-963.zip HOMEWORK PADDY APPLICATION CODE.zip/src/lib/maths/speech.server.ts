import { mathsUser, accessState, rememberDenial, safeError } from "./access.server";
import { requestSpeech } from "./speech-request.server";
import { getLovableAiGatewayResponseHeaders } from "./run-id.server.ts";

export async function handleMathsSpeech(request: Request) {
  try { await mathsUser(request); } catch { return Response.json({ message: "Please sign in." }, { status: 401 }); }
  const data = await request.json().catch(() => null) as { text?: unknown } | null;
  if (typeof data?.text !== "string" || !data.text.trim() || data.text.length > 1600) return Response.json({ message: "Choose a short explanation to hear." }, { status: 400 });
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return Response.json({ message: "Voice is not configured." }, { status: 503 });
  const model = "google/gemini-3.1-flash-tts-preview";
  const blocked = await accessState(model);
  if (blocked) return Response.json({ message: blocked }, { status: 403 });
  let upstream: Response;
  try {
    upstream = await requestSpeech({ baseURL: "https://ai.gateway.lovable.dev", apiKey, model, format: "gemini", voice: "Kore" }, `Speak naturally, warmly and slowly as a patient maths teacher. Read only this explanation: ${data.text}`, false, request.signal);
  } catch {
    return Response.json({ message: request.signal.aborted ? "Voice stopped." : "Voice could not connect now." }, { status: request.signal.aborted ? 499 : 502 });
  }
  if (upstream.status === 403) await rememberDenial(model, safeError(await upstream.clone().json().catch(() => null), "Voice access is currently blocked."));
  return new Response(upstream.body, { status: upstream.status, headers: getLovableAiGatewayResponseHeaders(upstream.headers, { "Content-Type": upstream.headers.get("Content-Type") ?? "text/event-stream", "Cache-Control": "no-store" }) });
}