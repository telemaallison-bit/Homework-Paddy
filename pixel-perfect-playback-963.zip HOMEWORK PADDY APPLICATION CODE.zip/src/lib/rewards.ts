import { lagosDay } from './free-learning';

export type RewardState = {
  stars: number;
  streak: number;
  lastLagosDay: string | null;
};

export const EMPTY_REWARD_STATE: RewardState = { stars: 0, streak: 0, lastLagosDay: null };

const STARS_KEY = 'total_stars';
const STREAK_KEY = 'ss_super_paddy_streak';
const DAY_KEY = 'ss_super_paddy_day';

function wholeNumber(value: string | null) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
}

export function readRewardState(): RewardState {
  if (typeof window === 'undefined') return EMPTY_REWARD_STATE;
  try {
    return {
      stars: wholeNumber(localStorage.getItem(STARS_KEY) ?? localStorage.getItem('ss_super_paddy_stars')),
      streak: currentStreak(wholeNumber(localStorage.getItem(STREAK_KEY)), localStorage.getItem(DAY_KEY)),
      lastLagosDay: localStorage.getItem(DAY_KEY),
    };
  } catch {
    return EMPTY_REWARD_STATE;
  }
}

export function writeRewardState(state: RewardState) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STARS_KEY, String(state.stars));
  localStorage.setItem(STREAK_KEY, String(state.streak));
  if (state.lastLagosDay) localStorage.setItem(DAY_KEY, state.lastLagosDay);
}

export type RewardGender = 'girl' | 'boy';
export function readRewardGender(): RewardGender | null {
  try { const value = localStorage.getItem('user_gender'); return value === 'girl' || value === 'boy' ? value : null; } catch { return null; }
}
export function rewardLevel(stars: number) { return Math.floor(Math.max(0, stars) / 50) + 1; }
export function currentStreak(streak: number, day: string | null, now = new Date()) {
  const today = lagosDay(now);
  const yesterday = lagosDay(new Date(now.getTime() - 86400000));
  return day === today || day === yesterday ? streak : 0;
}

/** Every correct answer earns ten stars; the streak advances once per Lagos day. */
export function awardSolveReward(state: RewardState, now = new Date()): RewardState {
  const today = lagosDay(now);
  const yesterday = lagosDay(new Date(now.getTime() - 24 * 60 * 60 * 1000));
  const streak = state.lastLagosDay === today
    ? Math.max(1, state.streak)
    : state.lastLagosDay === yesterday
      ? state.streak + 1
      : 1;
  return { stars: state.stars + 10, streak, lastLagosDay: today };
}
