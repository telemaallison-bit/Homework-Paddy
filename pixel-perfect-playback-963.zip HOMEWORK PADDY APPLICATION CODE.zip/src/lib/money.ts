export const PLANNER_BUDGET = 1000;
export const COIN_VALUE = 50;
export const TOTAL_COINS = 10;
export const AGE_BANDS = ['2–5', '5–10', '10–15', '15–18', 'Adult'] as const;
export function progressKey(userId: string | undefined) { return `hp_money_progress:${userId ?? 'guest'}`; }
export function parseProgress(raw: string | null): number[] {
  try {
    const data: unknown = JSON.parse(raw ?? '[]');
    return Array.isArray(data) ? [...new Set(data.filter((n): n is number => Number.isInteger(n) && n >= 0 && n < 5))] : [];
  } catch { return []; }
}
export type Bucket = 'need' | 'want';
export const MONEY_ITEMS = [
  { id: 'food', emoji: '🍲', bucket: 'need' },
  { id: 'water', emoji: '💧', bucket: 'need' },
  { id: 'home', emoji: '🏠', bucket: 'need' },
  { id: 'toy', emoji: '🧸', bucket: 'want' },
  { id: 'sweet', emoji: '🍬', bucket: 'want' },
  { id: 'game', emoji: '🎮', bucket: 'want' },
] as const;
export const EXPENSES = [400, 200, 300, 250] as const;
export function correctBucket(id: string, bucket: Bucket) {
  return MONEY_ITEMS.some(item => item.id === id && item.bucket === bucket);
}
export function budgetLeft(amounts: readonly number[], budget = PLANNER_BUDGET) {
  return budget - amounts.reduce((total, n) => total + n, 0);
}
export function interestLesson(principal: number, rate: number, luxury: number) {
  const interest = Math.floor(principal * rate / 100);
  return { interest, affordable: luxury <= interest, principal };
}