import { describe, expect, it } from "vitest";
import { creditsForPayment, FREE_CREDITS, AD_REWARD } from "./packages";

describe("pricing", () => {
  it("₦200 buys 10 tries", () => expect(creditsForPayment("p10", 200)).toBe(10));
  it("₦500 buys 30 tries", () => expect(creditsForPayment("p30", 500)).toBe(30));
  it("₦1000 buys 80 tries", () => expect(creditsForPayment("p80", 1000)).toBe(80));
  it("underpaying gives nothing", () => expect(creditsForPayment("p30", 200)).toBeNull());
  it("new users get 5 free, ads give 2", () => { expect(FREE_CREDITS).toBe(5); expect(AD_REWARD).toBe(2); });
});
