// @vitest-environment node
import { describe, expect, it, beforeEach } from "vitest";
import { containsBlockedText, blockedFileName, MAX_BLOCKS, COOLDOWN_MS } from "./moderation";

// localStorage stub for cooldown tests
const store = new Map<string, string>();
(globalThis as unknown as { localStorage: Storage }).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => void store.set(k, v),
  removeItem: (k: string) => void store.delete(k),
  clear: () => store.clear(),
  key: () => null,
  get length() { return store.size; },
} as Storage;
const { recordBlock, blocksLeft, cooldownRemaining } = await import("./moderation");

describe("text filter", () => {
  it("blocks sexual words", () => {
    expect(containsBlockedText("send me nude pics")).toBe(true);
    expect(containsBlockedText("ASHAWO")).toBe(true);
  });
  it("blocks fraud phrases", () => {
    expect(containsBlockedText("double your money fast")).toBe(true);
    expect(containsBlockedText("yahoo yahoo boys")).toBe(true);
    expect(containsBlockedText("send me your BVN")).toBe(true);
  });
  it("blocks insults and hate", () => {
    expect(containsBlockedText("you are a mumu")).toBe(true);
  });
  it("allows clean feedback", () => {
    expect(containsBlockedText("I love the braids try-on, please add more styles")).toBe(false);
    expect(containsBlockedText("The app no dey open for my phone")).toBe(false);
    expect(containsBlockedText("Please add a section for pants and trousers")).toBe(false);
  });
  it("checks file names", () => {
    expect(blockedFileName("my_nude_selfie.jpg")).toBe(true);
    expect(blockedFileName("IMG_2024_portrait.png")).toBe(false);
  });
});

describe("cooldown", () => {
  beforeEach(() => store.clear());
  it("allows 3 blocks then starts a 10 minute cooldown", () => {
    expect(blocksLeft(1000)).toBe(MAX_BLOCKS);
    expect(recordBlock(1000)).toBe(false);
    expect(recordBlock(1000)).toBe(false);
    expect(recordBlock(1000)).toBe(true);
    expect(blocksLeft(1000)).toBe(0);
    expect(cooldownRemaining(1000)).toBe(COOLDOWN_MS);
    expect(cooldownRemaining(1000 + COOLDOWN_MS + 1)).toBe(0);
  });
});
