import { expect, it } from 'vitest';
import { nextUnsolved, reviewedQuestions } from './assignment';
import { PICTURES, LEARNING_BANDS } from './learning-content';
it('keeps all five detected questions in sequence', () => { expect(nextUnsolved(5, {0:true,1:true})).toBe(2); expect(nextUnsolved(2,{0:true,1:true})).toBe(-1); });
it('confirms corrected assignment questions in their reviewed order', () => {
  expect(reviewedQuestions([{number:' 2b ',subject:' Maths ',question:' 12 + 7 = ? '},{number:'3',subject:'English',question:'Name a noun.'}])).toEqual([{number:'2b',subject:'Maths',question:'12 + 7 = ?'},{number:'3',subject:'English',question:'Name a noun.'}]);
});
it('does not confirm empty or incomplete question reviews', () => {
  expect(reviewedQuestions([])).toBeNull();
  for (const field of ['number','subject','question']) expect(reviewedQuestions([{number:'1',subject:'Maths',question:'2 + 2', [field]:' '}])).toBeNull();
});
it('offers all four requested age bands', () => { expect(LEARNING_BANDS.map(b=>b.id)).toEqual(['nursery','early','primary','secondary']); });
it('has a picture and five names for every letter A–Z', () => { expect(PICTURES.slice(0,26).map(p=>p.letter).join('')).toBe('ABCDEFGHIJKLMNOPQRSTUVWXYZ'); for(const p of PICTURES.slice(0,26)) { expect(p.image.length).toBeGreaterThan(0); expect(Object.values(p.names).filter(Boolean)).toHaveLength(5); } });