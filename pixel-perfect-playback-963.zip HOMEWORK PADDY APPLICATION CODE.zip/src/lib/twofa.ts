/** Client helpers for two-factor authentication. */

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

/** Generate 5 human-friendly backup codes like "K7M2-Q9PX". */
export function generateBackupCodes(): string[] {
  const out: string[] = [];
  const rnd = new Uint32Array(5 * 8);
  crypto.getRandomValues(rnd);
  for (let i = 0; i < 5; i++) {
    let c = "";
    for (let j = 0; j < 8; j++) {
      c += CODE_CHARS[rnd[i * 8 + j]! % CODE_CHARS.length];
      if (j === 3) c += "-";
    }
    out.push(c);
  }
  return out;
}

/** SHA-256 hex of a normalized backup code (uppercase, trimmed). */
export async function hashCode(code: string): Promise<string> {
  const data = new TextEncoder().encode(code.trim().toUpperCase());
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export const twofaMarker = (userId: string) => `ss_2fa_ok_${userId}`;
