import { describe, expect, it } from 'vitest';
import { resolveTheme } from './theme';
describe('saved background choice', () => {
  it('defaults to Calm Cream when no choice exists', () => expect(resolveTheme(null)).toBe('cream'));
  it('restores each of the five saved choices', () => {
    for (const choice of ['cream', 'sky', 'yellow', 'mint', 'pink']) expect(resolveTheme(choice)).toBe(choice);
  });
  it('rejects an unknown saved choice', () => expect(resolveTheme('invalid')).toBe('cream'));
});