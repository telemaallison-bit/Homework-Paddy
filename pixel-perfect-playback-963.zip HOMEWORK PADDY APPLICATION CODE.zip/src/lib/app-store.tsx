import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { DICT, LANGS, type Age, type Lang } from "./i18n";
import type { Gender } from "./hair";
import type { SavedLoc } from "./geo";
import { getWallet, spendCredit } from "./wallet.functions";
import { lagosDay } from "./free-learning";
import { EMPTY_REWARD_STATE, awardSolveReward, readRewardState, writeRewardState, readRewardGender, rewardLevel, type RewardState, type RewardGender } from "./rewards";

type Feature = "solve" | "tryon" | "spell";
type Ctx = {
  ready: boolean;
  lang: Lang | null; setLang: (l: Lang) => void;
  age: Age | null; setAge: (a: Age | null) => void;
  gender: Gender | null; setGender: (g: Gender | null) => void;
  loc: SavedLoc | null; setLoc: (l: SavedLoc | null) => void;
  name: string; setName: (n: string) => void;
  session: Session | null;
  credits: number; isPaid: boolean; isAdmin: boolean; totalPurchased: number;
  setCredits: (n: number) => void; refreshWallet: () => Promise<void>;
  spend: (f: Feature) => Promise<boolean>;
  freeSolvesToday: number; addBonusStar: () => void;
  rewardState: RewardState; rewardOpen: boolean; awardSuperPaddy: () => void; closeReward: () => void;
  awardCorrectAnswer: () => void; rewardGender: RewardGender | null; setRewardGender: (gender: RewardGender) => void;
  rewardId: number; levelUp: boolean;
  paywall: boolean; setPaywall: (b: boolean) => void;
  t: (k: string, vars?: Record<string, string | number>) => string;
  speak: (text: string, as?: Lang) => void;
};
// Keep one context object across hot reloads so the provider and consumers always match.
const g = globalThis as { __ssAppCtx?: React.Context<Ctx | null> };
const C = (g.__ssAppCtx ??= createContext<Ctx | null>(null));

function readLoc(): SavedLoc | null {
  try {
    const raw = localStorage.getItem("ss_loc");
    if (!raw) return null;
    const j = JSON.parse(raw) as SavedLoc;
    return typeof j.lat === "number" && typeof j.lng === "number" ? j : null;
  } catch { return null; }
}

function readFreeSolves(): number {
  try {
    const j = JSON.parse(localStorage.getItem("ss_free_solves") ?? "null") as { day: string; count: number } | null;
    return j && j.day === lagosDay(new Date()) ? j.count : 0;
  } catch { return 0; }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [lang, setLangS] = useState<Lang | null>(null);
  const [age, setAgeS] = useState<Age | null>(null);
  const [gender, setGenderS] = useState<Gender | null>(null);
  const [loc, setLocS] = useState<SavedLoc | null>(null);
  const [name, setNameS] = useState("");
  const [session, setSession] = useState<Session | null>(null);
  const [credits, setCredits] = useState(0);
  const [isPaid, setIsPaid] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [totalPurchased, setTotalPurchased] = useState(0);
  const [rewardState, setRewardState] = useState<RewardState>(EMPTY_REWARD_STATE);
  const [rewardOpen, setRewardOpen] = useState(false);
  const [paywall, setPaywall] = useState(false);
  const [freeSolvesToday, setFreeSolves] = useState(0);
  const [rewardGender, setRewardGenderState] = useState<RewardGender | null>(null);
  const [rewardId, setRewardId] = useState(0);
  const [levelUp, setLevelUp] = useState(false);

  const refreshWallet = useCallback(async () => {
    try {
      const w = await getWallet();
      setCredits(w.credits); setIsPaid(w.isPaid); setIsAdmin(w.isAdmin); setTotalPurchased(w.totalPurchased);
    } catch { /* signed out */ }
  }, []);

  useEffect(() => {
    setRewardState(readRewardState());
    setRewardGenderState(readRewardGender());
    setFreeSolves(readFreeSolves());
    setLangS((localStorage.getItem("ss_lang") as Lang) || null);
    setAgeS((localStorage.getItem("ss_age") as Age) || null);
    setGenderS((localStorage.getItem("ss_gender") as Gender) || null);
    setLocS(readLoc());
    setNameS(localStorage.getItem("ss_name") ?? "");
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      if (event === "SIGNED_IN" || event === "USER_UPDATED") setTimeout(refreshWallet, 0);
      if (event === "SIGNED_OUT") { setCredits(0); setIsPaid(false); setIsAdmin(false); setTotalPurchased(0); }
    });
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session) await refreshWallet();
      setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, [refreshWallet]);

  const setLang = (l: Lang) => { localStorage.setItem("ss_lang", l); setLangS(l); };
  const setAge = (a: Age | null) => {
    if (a) localStorage.setItem("ss_age", a); else localStorage.removeItem("ss_age");
    setAgeS(a);
  };
  const setGender = (v: Gender | null) => {
    if (v) localStorage.setItem("ss_gender", v); else localStorage.removeItem("ss_gender");
    setGenderS(v);
  };
  const setLoc = (l: SavedLoc | null) => {
    if (l) localStorage.setItem("ss_loc", JSON.stringify(l)); else localStorage.removeItem("ss_loc");
    setLocS(l);
  };
  const setName = (n: string) => { localStorage.setItem("ss_name", n); setNameS(n); };
  const spend = async (feature: Feature) => {

    const r = await spendCredit({ data: { feature } });
    setCredits(r.credits);
    if (!r.ok) { setPaywall(true); return false; }
    return true;
  };
  const awardCorrectAnswer = () => {
    const current = readRewardState();
    const next = awardSolveReward(current);
    writeRewardState(next);
    setRewardState(next);
    setLevelUp(rewardLevel(next.stars) > rewardLevel(current.stars));
    setRewardId(id => id + 1);
    setRewardOpen(true);
  };
  const awardSuperPaddy = () => {
    awardCorrectAnswer();
    const n = readFreeSolves() + 1;
    localStorage.setItem("ss_free_solves", JSON.stringify({ day: lagosDay(new Date()), count: n }));
    setFreeSolves(n);
    setRewardOpen(true);
  };
  const addBonusStar = () => setRewardState(current => { const next = { ...current, stars: current.stars + 1 }; writeRewardState(next); return next; });
  const setRewardGender = (gender: RewardGender) => { localStorage.setItem('user_gender', gender); setRewardGenderState(gender); };
  const closeReward = () => setRewardOpen(false);
  const t = (k: string, vars?: Record<string, string | number>) => {
    let s = DICT[lang ?? "en"][k] ?? DICT.en[k] ?? k;
    if (vars) for (const [a, b] of Object.entries(vars)) s = s.replace(`{${a}}`, String(b));
    return s;
  };
  const speak = (text: string, as?: Lang) => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = LANGS.find((x) => x.id === (as ?? lang ?? "en"))?.voice ?? "en-NG";
    u.rate = 0.85;
    window.speechSynthesis.speak(u);
  };
  return (
      <C.Provider value={{ ready, lang, setLang, age, setAge, gender, setGender, loc, setLoc, name, setName, session, credits, isPaid, isAdmin, totalPurchased, setCredits, refreshWallet, spend, freeSolvesToday, addBonusStar, rewardState, rewardOpen, awardSuperPaddy, awardCorrectAnswer, rewardGender, setRewardGender, rewardId, levelUp, closeReward, paywall, setPaywall, t, speak }}>
      {children}
    </C.Provider>
  );
}
export const useApp = () => {
  const c = useContext(C);
  if (!c) throw new Error("useApp outside provider");
  return c;
};
