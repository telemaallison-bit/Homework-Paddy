export type Provider = "Paystack";
export type PackageId = "p10" | "p30" | "p80";

export const PACKAGES: Record<PackageId, { credits: number; naira: number }> = {
  p10: { credits: 10, naira: 200 },
  p30: { credits: 30, naira: 500 },
  p80: { credits: 80, naira: 1000 },
};

export const FREE_CREDITS = 5;
export const AD_REWARD = 2;

/** Credits for a verified payment, or null if the paid amount doesn't match the package. */
export function creditsForPayment(pkg: PackageId, paidNaira: number): number | null {
  const p = PACKAGES[pkg];
  if (!p || paidNaira < p.naira) return null;
  return p.credits;
}
