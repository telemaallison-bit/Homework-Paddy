import { NG_STATES } from "./barbers";
import { reverseGeocode } from "./geo.functions";

export type SavedLoc = { lat: number; lng: number; city: string; state: string; label: string };

function toNgState(raw: string): string {
  const s = raw.toLowerCase();
  if (s.includes("federal capital") || s.includes("abuja")) return "FCT (Abuja)";
  return NG_STATES.find((n) => s.includes((n.split(" ")[0] ?? n).toLowerCase())) ?? raw;
}

// Ask the phone for GPS permission, then turn coordinates into "City, State".
export async function detectLocation(): Promise<SavedLoc> {
  const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
    navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 12000, maximumAge: 300000 }),
  );
  const { latitude: lat, longitude: lng } = pos.coords;
  const r = await reverseGeocode({ data: { lat, lng } });
  const state = toNgState(r.state);
  return { lat, lng, city: r.city, state, label: state ? `${r.city}, ${state}` : r.city };
}
