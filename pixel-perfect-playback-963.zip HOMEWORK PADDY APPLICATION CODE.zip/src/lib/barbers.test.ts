import { describe, expect, it } from "vitest";
import { BARBERS, NG_STATES, barbersInState, distanceKm, filterBarbers } from "./barbers";
import { HAIR_STYLES, hairStylesFor } from "./hair";

describe("barber dummy data", () => {
  it("has 15 Lagos, 10 Abuja (FCT), 2 each in Rivers, Kano, Oyo, Enugu", () => {
    expect(barbersInState("Lagos")).toHaveLength(15);
    expect(barbersInState("FCT (Abuja)")).toHaveLength(10);
    expect(barbersInState("Rivers")).toHaveLength(2);
    expect(barbersInState("Kano")).toHaveLength(2);
    expect(barbersInState("Oyo")).toHaveLength(2);
    expect(barbersInState("Enugu")).toHaveLength(2);
    expect(BARBERS).toHaveLength(33);
  });

  it("covers all 36 states + FCT in the state list", () => {
    expect(NG_STATES).toHaveLength(37);
    expect(NG_STATES).toContain("Lagos");
    expect(NG_STATES).toContain("Sokoto");
    expect(NG_STATES).toContain("FCT (Abuja)");
  });

  it("every barber has a phone, rating and price", () => {
    for (const b of BARBERS) {
      expect(b.phone).toMatch(/^23480\d{8}$/);
      expect(b.rating).toBeGreaterThanOrEqual(3.6);
      expect(b.rating).toBeLessThanOrEqual(5);
      expect(b.priceFrom).toBeGreaterThan(0);
    }
  });
});

describe("distanceKm", () => {
  it("Lagos to Abuja is roughly 530 km", () => {
    const d = distanceKm({ lat: 6.5244, lng: 3.3792 }, { lat: 9.0765, lng: 7.3986 });
    expect(d).toBeGreaterThan(450);
    expect(d).toBeLessThan(600);
  });
});

describe("filterBarbers", () => {
  const user = { lat: 6.5244, lng: 3.3792 };
  it("distance filter keeps only barbers within the radius", () => {
    const near = filterBarbers(barbersInState("Lagos"), user, { maxKm: 5 });
    expect(near.length).toBeGreaterThan(0);
    for (const b of near) expect(b.km!).toBeLessThanOrEqual(5);
  });
  it("price and rating filters are respected", () => {
    const cheap = filterBarbers(barbersInState("Lagos"), user, { maxPrice: 2000, minRating: 4 });
    for (const b of cheap) {
      expect(b.priceFrom).toBeLessThanOrEqual(2000);
      expect(b.rating).toBeGreaterThanOrEqual(4);
    }
  });
  it("sorts by distance when the user location is known", () => {
    const sorted = filterBarbers(barbersInState("Lagos"), user, {});
    for (let i = 1; i < sorted.length; i++) expect(sorted[i]!.km!).toBeGreaterThanOrEqual(sorted[i - 1]!.km!);
  });
});

describe("hairStylesFor", () => {
  it("female list: braids, cornrows, afro, twists, high bun, low cut", () => {
    expect(hairStylesFor("female").map((s) => s.id)).toEqual(["braids", "cornrows", "afro", "lowcut", "twists", "bun"]);
  });
  it("male list: full barbing collection with hair cuts and beard styles", () => {
    const male = hairStylesFor("male").map((s) => s.id);
    expect(male).toContain("lowcut_skin_fade");
    expect(male).toContain("cornrows_zigzag");
    expect(male).toContain("beard_fade");
    expect(male).toContain("clean_shave");
    expect(male).not.toContain("braids");
  });
  it("every style id is unique", () => {
    expect(new Set(HAIR_STYLES.map((s) => s.id)).size).toBe(HAIR_STYLES.length);
  });
});
