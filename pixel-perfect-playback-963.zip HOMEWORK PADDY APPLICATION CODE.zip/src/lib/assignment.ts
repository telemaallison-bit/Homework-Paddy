import { z } from 'zod';
export const assignmentSchema = z.object({ questions: z.array(z.object({ number: z.string(), question: z.string(), subject: z.string() }).strict()), warning: z.string() }).strict();
export type AssignmentQuestion = z.infer<typeof assignmentSchema>['questions'][number];
export function reviewedQuestions(questions: AssignmentQuestion[]): AssignmentQuestion[] | null {
  if (!questions.length || questions.some(q => !q.number.trim() || !q.question.trim() || !q.subject.trim())) return null;
  return questions.map(q => ({ number: q.number.trim(), question: q.question.trim(), subject: q.subject.trim() }));
}
export function nextUnsolved(total: number, solved: Record<number, unknown>) { for (let i=0;i<total;i++) if (!solved[i]) return i; return -1; }