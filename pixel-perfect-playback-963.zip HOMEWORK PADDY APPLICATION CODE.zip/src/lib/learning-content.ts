import type { Lang } from "./i18n";
import appleImage from "@/assets/learning/apple.jpg";
import ballImage from "@/assets/learning/ball.jpg";
import catImage from "@/assets/learning/cat.jpg";
import dogImage from "@/assets/learning/dog.jpg";
import elephantImage from "@/assets/learning/elephant.jpg";
import fishImage from "@/assets/learning/fish.jpg";
import goatImage from "@/assets/learning/goat.jpg";
import houseImage from "@/assets/learning/house.jpg";
import icecreamImage from "@/assets/learning/icecream.jpg";
import jugImage from "@/assets/learning/jug.jpg";
import kiteImage from "@/assets/learning/kite.jpg";
import lionImage from "@/assets/learning/lion.jpg";
import mangoImage from "@/assets/learning/mango.jpg";
import nestImage from "@/assets/learning/nest.jpg";
import orangeImage from "@/assets/learning/orange.jpg";
import pencilImage from "@/assets/learning/pencil.jpg";
import queenImage from "@/assets/learning/queen.jpg";
import rabbitImage from "@/assets/learning/rabbit.jpg";
import sunImage from "@/assets/learning/sun.jpg";
import treeImage from "@/assets/learning/tree.jpg";
import umbrellaImage from "@/assets/learning/umbrella.jpg";
import violinImage from "@/assets/learning/violin.jpg";
import whaleImage from "@/assets/learning/whale.jpg";
import xylophoneImage from "@/assets/learning/xylophone.jpg";
import yamImage from "@/assets/learning/yam.jpg";
import zebraImage from "@/assets/learning/zebra.jpg";
import starImage from "@/assets/learning/star.jpg";
import triangleImage from "@/assets/learning/triangle.jpg";
import squareImage from "@/assets/learning/square.jpg";
import circleImage from "@/assets/learning/circle.jpg";
export const LEARNING_BANDS = [{id:"nursery",label:"2–5 years · Nursery"},{id:"early",label:"5–7 years · Primary 1–2"},{id:"primary",label:"8–12 years · Primary 3–6"},{id:"secondary",label:"13+ · JSS / SSS"}] as const;
export type LearningBand = typeof LEARNING_BANDS[number]["id"];
export const PICTURES = [
{id:"apple",image:appleImage,letter:"A",names:{"en": "Apple", "pcm": "Apple", "yo": "Àpù", "ig": "Apụl", "ha": "Tuffa"}},
{id:"ball",image:ballImage,letter:"B",names:{"en": "Ball", "pcm": "Ball", "yo": "Bọ́ọ̀lù", "ig": "Bọọlụ", "ha": "Ƙwallo"}},
{id:"cat",image:catImage,letter:"C",names:{"en": "Cat", "pcm": "Cat", "yo": "Ológbò", "ig": "Nwamba", "ha": "Mage"}},
{id:"dog",image:dogImage,letter:"D",names:{"en": "Dog", "pcm": "Dog", "yo": "Ajá", "ig": "Nkịta", "ha": "Kare"}},
{id:"elephant",image:elephantImage,letter:"E",names:{"en": "Elephant", "pcm": "Elephant", "yo": "Erin", "ig": "Enyi", "ha": "Giwa"}},
{id:"fish",image:fishImage,letter:"F",names:{"en": "Fish", "pcm": "Fish", "yo": "Ẹja", "ig": "Azụ", "ha": "Kifi"}},
{id:"goat",image:goatImage,letter:"G",names:{"en": "Goat", "pcm": "Goat", "yo": "Ewúrẹ́", "ig": "Ewu", "ha": "Akuya"}},
{id:"house",image:houseImage,letter:"H",names:{"en": "House", "pcm": "House", "yo": "Ilé", "ig": "Ụlọ", "ha": "Gida"}},
{id:"icecream",image:icecreamImage,letter:"I",names:{"en": "Ice cream", "pcm": "Ice cream", "yo": "Yinyin dídùn", "ig": "Ice cream", "ha": "Ice cream"}},
{id:"jug",image:jugImage,letter:"J",names:{"en": "Jug", "pcm": "Jug", "yo": "Àgò", "ig": "Ite mmiri", "ha": "Tulu"}},
{id:"kite",image:kiteImage,letter:"K",names:{"en": "Kite", "pcm": "Kite", "yo": "Káìtì", "ig": "Egbe akwụkwọ", "ha": "Kite"}},
{id:"lion",image:lionImage,letter:"L",names:{"en": "Lion", "pcm": "Lion", "yo": "Kìnnìún", "ig": "Ọdụm", "ha": "Zaki"}},
{id:"mango",image:mangoImage,letter:"M",names:{"en": "Mango", "pcm": "Mango", "yo": "Mángòrò", "ig": "Mangoro", "ha": "Mangwaro"}},
{id:"nest",image:nestImage,letter:"N",names:{"en": "Nest", "pcm": "Nest", "yo": "Ìtẹ́ ẹyẹ", "ig": "Akwụ́", "ha": "Gida na tsuntsu"}},
{id:"orange",image:orangeImage,letter:"O",names:{"en": "Orange", "pcm": "Orange", "yo": "Ọsàn", "ig": "Oroma", "ha": "Lemu"}},
{id:"pencil",image:pencilImage,letter:"P",names:{"en": "Pencil", "pcm": "Pencil", "yo": "Pẹ́ńsù", "ig": "Pensụl", "ha": "Fensir"}},
{id:"queen",image:queenImage,letter:"Q",names:{"en": "Queen", "pcm": "Queen", "yo": "Ayaba", "ig": "Eze nwanyị", "ha": "Sarauniya"}},
{id:"rabbit",image:rabbitImage,letter:"R",names:{"en": "Rabbit", "pcm": "Rabbit", "yo": "Ehoro", "ig": "Ewi", "ha": "Zomo"}},
{id:"sun",image:sunImage,letter:"S",names:{"en": "Sun", "pcm": "Sun", "yo": "Oòrùn", "ig": "Anwụ", "ha": "Rana"}},
{id:"tree",image:treeImage,letter:"T",names:{"en": "Tree", "pcm": "Tree", "yo": "Igi", "ig": "Osisi", "ha": "Itace"}},
{id:"umbrella",image:umbrellaImage,letter:"U",names:{"en": "Umbrella", "pcm": "Umbrella", "yo": "Agboorun", "ig": "Nche anwụ", "ha": "Laima"}},
{id:"violin",image:violinImage,letter:"V",names:{"en": "Violin", "pcm": "Violin", "yo": "Fayolini", "ig": "Violin", "ha": "Violin"}},
{id:"whale",image:whaleImage,letter:"W",names:{"en": "Whale", "pcm": "Whale", "yo": "Ẹja ńlá", "ig": "Azụ ukwu", "ha": "Babban kifi"}},
{id:"xylophone",image:xylophoneImage,letter:"X",names:{"en": "Xylophone", "pcm": "Xylophone", "yo": "Xylophone", "ig": "Xylophone", "ha": "Xylophone"}},
{id:"yam",image:yamImage,letter:"Y",names:{"en": "Yam", "pcm": "Yam", "yo": "Iṣu", "ig": "Ji", "ha": "Doya"}},
{id:"zebra",image:zebraImage,letter:"Z",names:{"en": "Zebra", "pcm": "Zebra", "yo": "Kẹ́tẹ́kẹ́tẹ́ alárà", "ig": "Zebra", "ha": "Zebra"}},
{id:"star",image:starImage,letter:"",names:{"en": "Star", "pcm": "Star", "yo": "Ìràwọ̀", "ig": "Kpakpando", "ha": "Tauraro"}},
{id:"triangle",image:triangleImage,letter:"",names:{"en": "Triangle", "pcm": "Triangle", "yo": "Onígun mẹ́ta", "ig": "Akụkụ atọ", "ha": "Siffa mai kusurwa uku"}},
{id:"square",image:squareImage,letter:"",names:{"en": "Square", "pcm": "Square", "yo": "Onígun mẹ́rin", "ig": "Akụkụ anọ", "ha": "Murabba’i"}},
{id:"circle",image:circleImage,letter:"",names:{"en": "Circle", "pcm": "Circle", "yo": "Ìyíká", "ig": "Gburugburụ", "ha": "Da’ira"}},
];
export function pictureName(index:number, lang:Lang) { return PICTURES[index]?.names[lang] ?? ""; }
export function learningBand(age:string|null):LearningBand { return age === "nursery" ? "nursery" : age === "jss" || age === "sss" || age === "adult" ? "secondary" : "primary"; }
