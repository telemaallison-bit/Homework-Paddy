import type { Lang } from './i18n';

type ParentHomeCopy = { title: string; activities: string; recent: string; all: string; signIn: string; account: string };
export const PARENT_HOME_COPY: Record<Lang, ParentHomeCopy> = {
  en: { title: 'Your family’s learning today', activities: 'Your child’s activities', recent: 'Recent answers', all: 'View full progress', signIn: 'Sign in to see learning progress', account: 'Learning activity for this account' },
  pcm: { title: 'Wetin your family dey learn today', activities: 'Your pikin learning activities', recent: 'Latest answers', all: 'See all learning progress', signIn: 'Sign in to see how learning dey go', account: 'Learning activity for this account' },
  yo: { title: 'Ẹ̀kọ́ ẹbí rẹ lónìí', activities: 'Àwọn ìṣe ẹ̀kọ́ ọmọ rẹ', recent: 'Àwọn ìdáhùn tuntun', all: 'Wo gbogbo ìlọsíwájú', signIn: 'Wọlé láti wo ìlọsíwájú ẹ̀kọ́', account: 'Ìṣe ẹ̀kọ́ fún àkọọ́lẹ̀ yìí' },
  ig: { title: 'Ọmụmụ ezinụlọ gị taa', activities: 'Ihe ọmụmụ nwa gị', recent: 'Azịza ndị ọhụrụ', all: 'Lee ọganihu niile', signIn: 'Banye ka ị hụ ọganihu ọmụmụ', account: 'Ihe ọmụmụ emere na akaụntụ a' },
  ha: { title: 'Koyon iyalinka yau', activities: 'Ayyukan koyon yaranka', recent: 'Amsoshin baya-bayan nan', all: 'Duba duk ci gaba', signIn: 'Shiga don ganin ci gaban koyo', account: 'Ayyukan koyo na wannan asusun' },
};