import { describe, expect, it } from 'vitest';
import { LANGS } from './i18n';
import { LEARN_PLAY_COPY, LEARN_PLAY_ITEMS } from './learn-play';

describe('Learn & Play section', () => {
  it('contains exactly ABC Rhyme, 123 Song, Colours and Money Rhyme', () => {
    expect(LEARN_PLAY_ITEMS.map(item => item.id)).toEqual(['abc', 'numbers', 'colours', 'money']);
    expect(LEARN_PLAY_COPY.en.heading).toBe('Learn & Play 🎵');
    expect(Object.values(LEARN_PLAY_COPY.en.items).map(item => item.title)).toEqual(['ABC Rhyme', '123 Song', 'Colours', 'Money Rhyme']);
  });

  it('has playable lyrics in all five app languages', () => {
    for (const { id: lang } of LANGS) {
      for (const item of LEARN_PLAY_ITEMS) {
        expect(LEARN_PLAY_COPY[lang].items[item.id].title.length).toBeGreaterThan(2);
        expect(LEARN_PLAY_COPY[lang].items[item.id].lyrics.length).toBeGreaterThan(30);
      }
    }
  });
});
