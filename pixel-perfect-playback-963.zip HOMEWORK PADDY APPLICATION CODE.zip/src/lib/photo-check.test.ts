import { describe, expect, it } from "vitest";
import { judgePhoto } from "./photo-check";

const W = 50, H = 50;
const fill = (f: (i: number) => number) => Array.from({ length: W * H }, (_, i) => f(i));

describe("judgePhoto", () => {
  it("flags tiny photos", () => expect(judgePhoto(fill(() => 128), W, H, 200, 200)).toBe("small"));
  it("flags dark photos", () => expect(judgePhoto(fill(() => 10), W, H, 1000, 1000)).toBe("dark"));
  it("flags flat (blurry) photos", () => expect(judgePhoto(fill(() => 128), W, H, 1000, 1000)).toBe("blurry"));
  it("accepts sharp, well-lit photos", () => expect(judgePhoto(fill((i) => ((i % W) + Math.floor(i / W)) % 2 ? 200 : 60), W, H, 1000, 1000)).toBe("ok"));
});
