export const BACKGROUND_THEMES = [
  { id: 'cream', name: 'Calm Cream' },
  { id: 'sky', name: 'Sky Blue' },
  { id: 'yellow', name: 'Soft Yellow' },
  { id: 'mint', name: 'Mint Green' },
  { id: 'pink', name: 'Light Pink' },
] as const;
export type BackgroundTheme = typeof BACKGROUND_THEMES[number]['id'];
export const THEME_STORAGE_KEY = 'hp_background_theme';
export function resolveTheme(value: string | null): BackgroundTheme {
  return BACKGROUND_THEMES.find(theme => theme.id === value)?.id ?? 'cream';
}