// Content moderation: free client-side filters (no paid API).
// First line of defence only — the AI gateway also moderates, and prompts forbid explicit edits.

const SEXUAL = [
  "nude", "naked", "porn", "sex", "sexy", "boobs", "breast", "vagina", "penis", "dick", "pussy",
  "bikini", "underwear", "pant", "bra only", "topless", "erotic", "fuck", "ashawo", "olosho", "nyash", "bumbum",
];
const FRAUD = [
  "yahoo", "yahoo yahoo", "send money", "send me money", "double your money", "wire transfer",
  "click this link", "click the link", "you have won", "you don win", "gift card", "bitcoin investment",
  "pay before delivery", "send money before", "urgent transfer", "bank details", "bvn", "otp code", "pin number",
];
const INSULT_HATE = [
  "stupid", "idiot", "fool", "mumu", "ode", "olodo", "hate you", "kill", "die", "useless",
  "tribal", "infidel", "bastard", "mad you", "werey",
];

const ALL_BLOCKED = [...SEXUAL, ...FRAUD, ...INSULT_HATE];

/** True when the text contains a blocked word or phrase (case-insensitive, word-ish match). */
export function containsBlockedText(text: string): boolean {
  const t = ` ${text.toLowerCase().replace(/[^a-z0-9\s]/g, " ")} `;
  return ALL_BLOCKED.some((w) => t.includes(` ${w} `) || (w.includes(" ") && t.includes(w)));
}

/** True when the file name itself suggests explicit content. */
export function blockedFileName(name: string): boolean {
  return containsBlockedText(name.replace(/[._-]/g, " "));
}

export type ImageVerdict = { ok: true } | { ok: false; reason: "skin" | "noface" | "filename" };

/**
 * Rough free image check: flags photos that are almost entirely skin-toned
 * (a normal face portrait is ~30-50% skin; explicit full-body shots are far higher).
 * Also runs a best-effort face check when the browser supports FaceDetector.
 */
export async function checkImage(file: File): Promise<ImageVerdict> {
  if (blockedFileName(file.name)) return { ok: false, reason: "filename" };
  const bmp = await createImageBitmap(file);
  const W = 96, H = 96;
  const canvas = document.createElement("canvas");
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return { ok: true };
  ctx.drawImage(bmp, 0, 0, W, H);
  const { data } = ctx.getImageData(0, 0, W, H);
  let skin = 0, total = 0;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i]!, g = data[i + 1]!, b = data[i + 2]!;
    total++;
    // Common skin-tone rule of thumb (works across dark and light skin).
    if (r > 60 && r >= g && g >= b && r - b > 10 && r - g >= 5 && r - g < 120) skin++;
  }
  const skinRatio = skin / total;
  if (skinRatio > 0.7) return { ok: false, reason: "skin" };
  // Best-effort face check: only when the browser ships FaceDetector (Chrome Android does).
  const FD = (window as unknown as { FaceDetector?: new () => { detect: (s: CanvasImageSource) => Promise<unknown[]> } }).FaceDetector;
  if (FD) {
    try {
      const faces = await new FD().detect(bmp);
      if (faces.length === 0) return { ok: false, reason: "noface" };
    } catch { /* detector failed — allow, gateway moderation still applies */ }
  }
  return { ok: true };
}

// --- cooldown: 3 blocked tries, then 10 minutes ---
const COUNT_KEY = "ss_mod_count";
const UNTIL_KEY = "ss_mod_until";
export const MAX_BLOCKS = 3;
export const COOLDOWN_MS = 10 * 60 * 1000;

export function cooldownRemaining(now = Date.now()): number {
  const until = Number(localStorage.getItem(UNTIL_KEY) ?? 0);
  return Math.max(0, until - now);
}

export function blocksLeft(now = Date.now()): number {
  if (cooldownRemaining(now) > 0) return 0;
  return Math.max(0, MAX_BLOCKS - Number(localStorage.getItem(COUNT_KEY) ?? 0));
}

/** Record a blocked attempt; returns true when the cooldown just started. */
export function recordBlock(now = Date.now()): boolean {
  const n = Number(localStorage.getItem(COUNT_KEY) ?? 0) + 1;
  localStorage.setItem(COUNT_KEY, String(n));
  if (n >= MAX_BLOCKS) {
    localStorage.setItem(UNTIL_KEY, String(now + COOLDOWN_MS));
    localStorage.setItem(COUNT_KEY, "0");
    return true;
  }
  return false;
}
