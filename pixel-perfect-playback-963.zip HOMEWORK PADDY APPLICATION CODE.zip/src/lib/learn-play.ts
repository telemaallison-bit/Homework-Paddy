import type { Lang } from './i18n';
import abcArt from '@/assets/engagement/abc-rhyme-3d.png';
import numbersArt from '@/assets/engagement/numbers-song-3d.png';
import coloursArt from '@/assets/engagement/colours-3d.png';
import moneyArt from '@/assets/engagement/money-rhyme-3d.png';

export type LearnPlayId = 'abc' | 'numbers' | 'colours' | 'money';

export const LEARN_PLAY_ITEMS: { id: LearnPlayId; image: string; card: string }[] = [
  { id: 'abc', image: abcArt, card: 'card-homework' },
  { id: 'numbers', image: numbersArt, card: 'card-maths' },
  { id: 'colours', image: coloursArt, card: 'card-learning' },
  { id: 'money', image: moneyArt, card: 'card-money' },
];

type ItemCopy = { title: string; lyrics: string };
type LearnPlayCopy = {
  heading: string;
  play: string;
  stop: string;
  lyricsLabel: string;
  items: Record<LearnPlayId, ItemCopy>;
};

const en: LearnPlayCopy = {
  heading: 'Learn & Play 🎵',
  play: 'Play ▶️',
  stop: 'Stop',
  lyricsLabel: 'Song lyrics',
  items: {
    abc: {
      title: 'ABC Rhyme',
      lyrics: 'A, B, C, come and sing with me. D, E, F, learning is fun for you and me. G, H, I, we can reach the sky. ABC, one more time!',
    },
    numbers: {
      title: '123 Song',
      lyrics: 'One little step, two little feet, three loud claps and four hearts beat. Five, six, seven, count with me. Eight, nine, ten, happy as can be!',
    },
    colours: {
      title: 'Colours',
      lyrics: 'Red like a tomato, yellow like the sun. Blue like the river, green like leaves that run. Colours all around us, bright for everyone.',
    },
    money: {
      title: 'Money Rhyme',
      lyrics: 'Save a little, spend with care, share a little, show you care. Coin by coin your savings grow. Money Paddy helps you know.',
    },
  },
};

export const LEARN_PLAY_COPY: Record<Lang, LearnPlayCopy> = {
  en,
  pcm: {
    ...en,
    items: {
      abc: { title: 'ABC Rhyme', lyrics: 'A, B, C, make you sing with me. D, E, F, learning dey sweet for you and me. G, H, I, we fit touch the sky. ABC, sing am one more time!' },
      numbers: { title: '123 Song', lyrics: 'One small step, two small legs, three loud claps, four hearts dey beat. Five, six, seven, count with me. Eight, nine, ten, happiness complete!' },
      colours: { title: 'Colours', lyrics: 'Red like tomato, yellow like sun. Blue like river, green like leaf wey dey run. Colours dey around us, bright for everyone.' },
      money: { title: 'Money Rhyme', lyrics: 'Save small-small, spend with sense, share small too, show say you care. Coin by coin your money go grow. Money Paddy go help you know.' },
    },
  },
  yo: {
    ...en,
    items: {
      abc: { title: 'Orin ABC', lyrics: 'A, B, C, wá jọ kọrin pẹ̀lú mi. D, E, F, ẹ̀kọ́ dùn fún ìwọ àti emi. G, H, I, a lè dé ọ̀run. ABC, jẹ́ ká tún kọ ọ́!' },
      numbers: { title: 'Orin 123', lyrics: 'Ọ̀kan ìgbésẹ̀, ẹ̀jì ẹsẹ̀, ẹ̀mẹ́ta káàkìri, ẹ̀mẹ́rin ọkàn ń lù. Marùn, mẹ́fà, méje, ka pẹ̀lú mi. Mẹ́jọ, mẹ́sàn-án, mẹ́wàá, ayọ̀ kún!' },
      colours: { title: 'Àwọ̀', lyrics: 'Pupa bíi tomato, ofeefee bíi oòrùn. Búlùù bíi odò, aláwọ̀ ewéko bíi ewé. Àwọ̀ yí ká káàkiri, ó mọ́lẹ̀ fún gbogbo wa.' },
      money: { title: 'Orin Owó', lyrics: 'Fipamọ́ díẹ̀, ná ní ọgbọ́n, pín díẹ̀, fi àánú hàn. Kóògì lẹ́yìn kóògì, owó rẹ máa dàgbà. Money Paddy máa kọ́ ọ́.' },
    },
  },
  ig: {
    ...en,
    items: {
      abc: { title: 'Abụ ABC', lyrics: 'A, B, C, bịa bụrụ abụ m. D, E, F, mmụta na-atọ ụtọ maka gị na m. G, H, I, anyị nwere ike iru eluigwe. ABC, ka anyị bụọ ya ọzọ!' },
      numbers: { title: 'Abụ 123', lyrics: 'Otu nzọụkwụ, ụkwụ abụọ, ụda atọ, obi anọ na-aku. Ise, isii, asaa, gụnye m. Asatọ, itoolu, iri, obi dị ụtọ!' },
      colours: { title: 'Agba', lyrics: 'Uhie dị ka tomato, edo edo dị ka anwụ. Anụnụ dị ka osimiri, akwụkwọ ndụ dị ka akwụkwọ. Agba gbara anyị gburugburu, na-enwu maka anyị niile.' },
      money: { title: 'Abụ Ego', lyrics: 'Chekwaa obere, mefuo nke ọma, kesaa obere, gosi ịrịba ama. Ego nwantịrị nwantịrị na-eto. Money Paddy na-akụzi gị.' },
    },
  },
  ha: {
    ...en,
    items: {
      abc: { title: 'Waƙar ABC', lyrics: 'A, B, C, zo mu rera waƙa tare. D, E, F, koyo yana da daɗi a gare ka da ni. G, H, I, za mu iya kaiwa sama. ABC, mu sake rera ta!' },
      numbers: { title: 'Waƙar 123', lyrics: 'Ɗaya taki, biyu ƙafafu, uku tafi, huɗu zuciya na bugawa. Biyar, shida, bakwai, ƙidaya tare da ni. Takwas, tara, goma, cike da farin ciki!' },
      colours: { title: 'Launuka', lyrics: 'Ja kamar tumatur, rawaya kamar rana. Shuɗi kamar kogi, kore kamar ganye. Launuka suna kewaye da mu, suna haske ga kowa.' },
      money: { title: 'Waƙar Kuɗi', lyrics: 'Ajiye kaɗan, kashe da hankali, raba kaɗan, nuna kula. Kuɗi kaɗan kaɗan yana girma. Money Paddy zai koya maka.' },
    },
  },
};
