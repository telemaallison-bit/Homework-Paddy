import { describe, expect, it } from 'vitest';
import { correctPronunciation, correctTyping } from './spelling-score';
describe('Correct spelling and pronunciation rewards', () => {
  it('requires matching typed spelling, ignoring case and outer spaces', () => {
    expect(correctTyping('banana', ' BANANA ')).toBe(true);
    expect(correctTyping('banana', 'bananna')).toBe(false);
    expect(correctTyping('', '')).toBe(false);
  });
  it('uses the existing passing pronunciation threshold', () => {
    expect(correctPronunciation('banana', 'banana')).toBe(true);
    expect(correctPronunciation('banana', 'banano')).toBe(true);
    expect(correctPronunciation('banana', 'book')).toBe(false);
    expect(correctPronunciation('banana', '')).toBe(false);
  });
});