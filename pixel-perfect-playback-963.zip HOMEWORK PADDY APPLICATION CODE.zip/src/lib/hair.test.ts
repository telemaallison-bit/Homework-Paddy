// @vitest-environment node
import { describe, expect, it, vi, beforeEach } from "vitest";
const mocks = vi.hoisted(() => ({ rpc: vi.fn(), getUser: vi.fn(), editImage: vi.fn() }));
vi.mock("@supabase/supabase-js", () => ({ createClient: () => ({ auth: { getUser: mocks.getUser }, rpc: mocks.rpc }) }));
vi.mock("./image-gateway.server", () => ({ editImage: mocks.editImage }));
import { handleHairTryOn } from "./hair-route.server";
import { FASHION_SEARCH, HAIR_COPY, HAIR_STYLES, hairPrompt } from "./hair";

function request(stream = "true") {
  const form = new FormData();
  form.set("image", new File(["photo"], "portrait.png", { type: "image/png" }));
  form.set("style", "cornrows"); form.set("lang", "pcm");
  form.set("requestId", "c1aef100-9761-4a00-9027-f5c680c91e88"); form.set("stream", stream);
  return new Request("https://app.test/api/hair-try-on", { method: "POST", body: form, headers: { Authorization: "Bearer test" } });
}
beforeEach(() => {
  vi.resetAllMocks();
  vi.stubEnv("SUPABASE_URL", "https://backend.test"); vi.stubEnv("SUPABASE_PUBLISHABLE_KEY", "publishable"); vi.stubEnv("LOVABLE_API_KEY", "test");
  mocks.getUser.mockResolvedValue({ data: { user: { id: "test-user" } }, error: null });
  mocks.rpc.mockResolvedValue({ data: 4, error: null });
  mocks.editImage.mockResolvedValue(new Response("event: image_edit.completed\n\n", { headers: { "Content-Type": "text/event-stream" } }));
});
describe("Hair try-on wallet rules", () => {
  it("reserves exactly one charged attempt before calling AI", async () => {
    await handleHairTryOn(request());
    expect(mocks.rpc).toHaveBeenCalledTimes(1);
    expect(mocks.rpc).toHaveBeenCalledWith("begin_hair_tryon_request", { _request_id: "c1aef100-9761-4a00-9027-f5c680c91e88", _replay: false });
    expect(mocks.editImage).toHaveBeenCalledTimes(1);
    expect(mocks.rpc.mock.invocationCallOrder[0] ?? Infinity).toBeLessThan(mocks.editImage.mock.invocationCallOrder[0] ?? 0);
  });
  it("blocks AI when no tries remain", async () => {
    mocks.rpc.mockResolvedValue({ data: -1, error: null });
    const response = await handleHairTryOn(request());
    expect(response.status).toBe(402);
    expect(mocks.editImage).not.toHaveBeenCalled();
  });
  it("uses the same attempt ID for an uncharged zero-event recovery", async () => {
    await handleHairTryOn(request("false"));
    expect(mocks.rpc).toHaveBeenCalledWith("begin_hair_tryon_request", { _request_id: "c1aef100-9761-4a00-9027-f5c680c91e88", _replay: true });
  });
  it("does not let a signed-out caller generate a photo", async () => {
    const response = await handleHairTryOn(new Request("https://app.test/api/hair-try-on", { method: "POST" }));
    expect(response.status).toBe(401);
    expect(mocks.rpc).not.toHaveBeenCalled();
    expect(mocks.editImage).not.toHaveBeenCalled();
  });
  it("restricts the edit to hair without changing the learner's age or identity", () => {
    const prompt = hairPrompt("cornrows");
    expect(prompt).toContain("Change ONLY the hair");
    expect(prompt).toContain("Preserve the exact person's face, age, skin tone");
  });
});
describe("Male barbing collection", () => {
  it("offers at least 30 styles for men and keeps the 6 female styles", async () => {
    const { hairStylesFor, HAIR_STYLES } = await import("./hair");
    expect(hairStylesFor("male").length).toBeGreaterThanOrEqual(30);
    expect(hairStylesFor("female").length).toBe(6);
    expect(new Set(HAIR_STYLES.map((s) => s.id)).size).toBe(HAIR_STYLES.length);
  });
  it("splits male styles into hair cuts and beard styles", async () => {
    const { hairStylesFor } = await import("./hair");
    const male = hairStylesFor("male");
    expect(male.filter((s) => s.cat === "beard").length).toBeGreaterThanOrEqual(11);
    expect(male.filter((s) => s.cat === "hair").length).toBeGreaterThanOrEqual(15);
  });
  it("restricts beard styles to the lower face only", () => {
    const prompt = hairPrompt("goatee_classic");
    expect(prompt).toContain("Change ONLY the facial hair");
    expect(prompt).toContain("lower face");
    expect(prompt).toContain("Do not touch the hair on the head");
  });
  it("gives every style a Nigerian price range", async () => {
    const { HAIR_STYLES, priceRange } = await import("./hair");
    for (const s of HAIR_STYLES) {
      expect(s.price[0]).toBeGreaterThan(0);
      expect(s.price[1]).toBeGreaterThanOrEqual(s.price[0]);
      expect(priceRange(s)).toContain("₦");
    }
  });
});
describe("Google variety search + inspiration", () => {
  it("every style has a Google Images search query", () => {
    for (const s of HAIR_STYLES) {
      expect(s.gsearch.length).toBeGreaterThan(5);
    }
  });
  it("female fashion search mentions ankara", () => {
    expect(FASHION_SEARCH).toContain("ankara");
  });
  it("every language has the new gallery and Google copy", () => {
    for (const lang of ["en", "pcm", "yo", "ig", "ha"] as const) {
      const c = HAIR_COPY[lang];
      expect(c.moreOnGoogle).toContain("Google");
      expect(c.inspo.length).toBeGreaterThan(3);
      expect(c.tryLook.length).toBeGreaterThan(3);
      expect(c.fashionLink).toContain("Google");
    }
  });
});
