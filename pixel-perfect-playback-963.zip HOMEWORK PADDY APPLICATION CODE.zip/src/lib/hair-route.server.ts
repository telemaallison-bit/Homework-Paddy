import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { editImage } from "./image-gateway.server";
import { hairPrompt, hairRequestSchema } from "./hair";

export async function handleHairTryOn(request: Request) {
  const authorization = request.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) return Response.json({ message: "Please sign in." }, { status: 401 });
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!url || !key || !apiKey) return Response.json({ message: "Photo AI is not configured." }, { status: 503 });
  const client = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: authorization }, fetch: (input, init) => {
      const headers = new Headers(init?.headers);
      headers.set("apikey", key);
      if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
      return fetch(input, { ...init, headers });
    } },
  });
  const { data: user, error: authError } = await client.auth.getUser(authorization.slice(7));
  if (authError || !user.user) return Response.json({ message: "Please sign in again." }, { status: 401 });
  let form: FormData;
  try { form = await request.formData(); } catch { return Response.json({ message: "Choose a valid photo." }, { status: 400 }); }
  const parsed = hairRequestSchema.safeParse({ style: form.get("style"), lang: form.get("lang"), requestId: form.get("requestId") });
  const image = form.get("image");
  if (!parsed.success || !(image instanceof File) || image.size === 0 || image.size > 8 * 1024 * 1024 || !["image/jpeg", "image/png", "image/webp"].includes(image.type)) {
    return Response.json({ message: "Choose a JPG, PNG or WebP photo under 8 MB and a hairstyle." }, { status: 400 });
  }
  const { data: credits, error } = await client.rpc("begin_hair_tryon_request", { _request_id: parsed.data.requestId, _replay: form.get("stream") === "false" });
  if (error) return Response.json({ message: "This request could not start. Choose the look again." }, { status: 409 });
  if (credits < 0) return Response.json({ message: "You don finish free tries", noCredits: true }, { status: 402 });
  const upstreamForm = new FormData();
  upstreamForm.set("image", image);
  upstreamForm.set("prompt", hairPrompt(parsed.data.style));
  upstreamForm.set("stream", form.get("stream") === "false" ? "false" : "true");
  upstreamForm.set("size", "1024x1024");
  upstreamForm.set("quality", "medium");
  const upstream = await editImage({ baseURL: "https://ai.gateway.lovable.dev", apiKey, model: "openai/gpt-image-2.5-sunburst", format: "openai" }, upstreamForm);
  const headers = new Headers({ "Content-Type": upstream.headers.get("Content-Type") ?? "application/json", "Cache-Control": "no-store" });
  upstream.headers.forEach((value, name) => { if (name.toLowerCase().startsWith("x-lovable-aig-")) headers.set(name, value); });
  return new Response(upstream.body, { status: upstream.status, headers });
}