import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getTwoFAStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("user_security")
      .select("twofa_enabled, backup_codes")
      .eq("user_id", context.userId)
      .maybeSingle();
    return { enabled: data?.twofa_enabled ?? false, codesLeft: data?.backup_codes?.length ?? 0 };
  });

export const enableTwoFA = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { codes: string[] }) => d)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("set_twofa", { _enabled: true, _codes: data.codes });
    if (error) throw new Error("Could not enable 2FA");
    return { ok: true };
  });

export const disableTwoFA = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase.rpc("set_twofa", { _enabled: false, _codes: [] });
    if (error) throw new Error("Could not disable 2FA");
    return { ok: true };
  });

/** One-time backup code login: returns true and consumes the code when valid. */
export const useBackupCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { code: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: ok, error } = await context.supabase.rpc("use_backup_code", { _code: data.code });
    if (error) throw new Error("Could not check code");
    return { ok: !!ok };
  });

export const submitSuggestion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { category: string; rating: number; message: string }) => {
    if (!d.message.trim()) throw new Error("Message is empty");
    return { category: d.category, rating: Math.min(5, Math.max(1, Math.round(d.rating))), message: d.message.trim().slice(0, 2000) };
  })
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("suggestions").insert({
      user_id: context.userId,
      category: data.category,
      rating: data.rating,
      message: data.message,
    });
    if (error) throw new Error("Could not send feedback");
    return { ok: true };
  });
