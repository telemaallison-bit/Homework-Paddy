export type PhotoIssue = "ok" | "dark" | "bright" | "blurry" | "small";

/** Pure check on grayscale pixels (0-255). Exported for tests. */
export function judgePhoto(gray: Uint8ClampedArray | number[], w: number, h: number, origW: number, origH: number): PhotoIssue {
  if (Math.min(origW, origH) < 300) return "small";
  let sum = 0;
  for (let i = 0; i < gray.length; i++) sum += gray[i]!;
  const mean = sum / gray.length;
  if (mean < 50) return "dark";
  if (mean > 235) return "bright";
  // Laplacian variance = sharpness
  let lsum = 0, lsq = 0, n = 0;
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const i = y * w + x;
    const l = 4 * gray[i]! - gray[i - 1]! - gray[i + 1]! - gray[i - w]! - gray[i + w]!;
    lsum += l; lsq += l * l; n++;
  }
  const v = lsq / n - (lsum / n) ** 2;
  if (v < 60) return "blurry";
  return "ok";
}

export function checkPhoto(dataUrl: string): Promise<PhotoIssue> {
  return new Promise((res) => {
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1, 256 / Math.max(img.width, img.height));
      const w = Math.max(3, Math.round(img.width * s)), h = Math.max(3, Math.round(img.height * s));
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const ctx = c.getContext("2d")!; ctx.drawImage(img, 0, 0, w, h);
      const d = ctx.getImageData(0, 0, w, h).data;
      const g = new Uint8ClampedArray(w * h);
      for (let i = 0; i < g.length; i++) g[i] = 0.299 * d[i * 4]! + 0.587 * d[i * 4 + 1]! + 0.114 * d[i * 4 + 2]!;
      res(judgePhoto(g, w, h, img.width, img.height));
    };
    img.onerror = () => res("ok");
    img.src = dataUrl;
  });
}
