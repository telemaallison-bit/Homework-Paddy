import { describe, expect, it } from "vitest";
import { googleSearchUrl, parseDdg, SUGGESTIONS, TIP_TOPICS, youtubeSearchUrl } from "./search";

describe("parseDdg", () => {
  it("uses the abstract as the first result", () => {
    const r = parseDdg({
      Heading: "Box braids",
      AbstractText: "Box braids are a protective style.",
      AbstractURL: "https://example.com/box-braids",
    });
    expect(r[0]).toEqual({
      title: "Box braids",
      snippet: "Box braids are a protective style.",
      url: "https://example.com/box-braids",
    });
  });

  it("flattens nested related topics and caps at 5", () => {
    const mk = (n: number) => ({ Text: `Style ${n} - some detail ${n}`, FirstURL: `https://example.com/${n}` });
    const r = parseDdg({ RelatedTopics: [{ Topics: [mk(1), mk(2)] }, mk(3), { Topics: [mk(4), mk(5), mk(6), mk(7)] }] });
    expect(r).toHaveLength(5);
    expect(r[0]!.title).toBe("Style 1");
    expect(r[0]!.snippet).toBe("some detail 1");
  });

  it("returns empty for an empty response", () => {
    expect(parseDdg({})).toEqual([]);
  });
});

describe("search helpers", () => {
  it("builds external search urls with the query encoded", () => {
    expect(googleSearchUrl("low cut fade")).toContain("low%20cut%20fade");
    expect(googleSearchUrl("low cut fade")).toContain("nigeria");
    expect(youtubeSearchUrl("360 waves")).toContain("360%20waves");
  });

  it("ships the user's suggestions and 3 tip topics", () => {
    expect(SUGGESTIONS).toContain("low cut fade");
    expect(SUGGESTIONS).toContain("best beard oil Nigeria");
    expect(TIP_TOPICS).toHaveLength(3);
  });
});
