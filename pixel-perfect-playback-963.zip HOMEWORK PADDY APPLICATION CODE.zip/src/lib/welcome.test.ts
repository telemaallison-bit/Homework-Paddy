import { describe, expect, it } from "vitest";
import { needsWelcome, welcomeKey } from "./welcome";

describe("First-time parent welcome", () => {
  it("shows after login on the first visit", () => {
    expect(needsWelcome("parent-1", null)).toBe(true);
    expect(needsWelcome(null, null)).toBe(false);
  });
  it("does not show again after Start or Skip saves completion", () => {
    expect(needsWelcome("parent-1", "1")).toBe(false);
    expect(needsWelcome("parent-1", "0")).toBe(true);
  });
  it("remembers completion separately for each parent on the device", () => {
    const saved = new Map([[welcomeKey("parent-1"), "1"]]);
    expect(needsWelcome("parent-1", saved.get(welcomeKey("parent-1")) ?? null)).toBe(false);
    expect(needsWelcome("parent-2", saved.get(welcomeKey("parent-2")) ?? null)).toBe(true);
  });
});