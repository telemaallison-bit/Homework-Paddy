export const WELCOME_STORAGE_KEY = "hp_welcome_done";

export function welcomeKey(userId: string) {
  return `${WELCOME_STORAGE_KEY}:${userId}`;
}

export function needsWelcome(userId: string | null, completed: string | null) {
  return Boolean(userId) && completed !== "1";
}