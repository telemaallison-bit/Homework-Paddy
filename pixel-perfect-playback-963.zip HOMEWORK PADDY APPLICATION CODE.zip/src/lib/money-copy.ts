import type { Lang } from './i18n';
type MoneyCopy = {
  subtitle: string; level: string; titles: string[]; lessons: string[];
  items: string[]; needs: string; wants: string; banks: string[];
  listen: string; check: string; again: string; next: string; success: string; retry: string;
  left: string; total: string; add: string; remove: string; expenses: string[];
  saved: string; interest: string; luxury: string; buy: string; wait: string;
  disclaimer: string; complete: string;
};
export const MONEY_COPY: Record<Lang, MoneyCopy> = {
  en: {
    subtitle: 'Learn Money from Age 2 to Adult', level: 'Level',
    titles: ['Needs vs Wants', 'Save Small', 'Plan Before Spend', 'Avoid Overspending', 'Spend Interest on Luxuries'],
    lessons: ['Need first! Needs keep us healthy and safe. Wants are nice extras. Sort the pictures. Grown-ups can help.', 'Small savings grow. Share ten ₦50 coins between Save, Spend and Share. Put at least one coin in each bank.', 'You have ₦1,000. Choose food and transport first, then savings and wants. Plan every naira before spending.', 'Ada has ₦1,000. Shoes cost ₦1,200. Borrowing ₦200 means money to repay later, and there may be fees. Saving ₦200 more lets Ada buy without borrowing. Which keeps her out of debt?', 'Ada has a ₦10,000 salary saved. In this pretend example, it earns 5% interest: ₦500. Shoes cost ₦400. Buy with salary: ₦9,600 salary remains. Buy with interest: the ₦10,000 stays and ₦100 interest remains. Needs and emergency savings come first.'],
    items: ['Food', 'Water', 'Home', 'Teddy', 'Sweets', 'Video game'], needs: 'Needs', wants: 'Wants', banks: ['Save', 'Spend', 'Share'],
    listen: 'Hear lesson', check: 'Check my plan', again: 'Try again', next: 'Next level', success: 'Well done! Your plan works.', retry: 'Not yet. Check the lesson and try again.',
    left: 'Money left', total: 'Total', add: 'Add', remove: 'Remove', expenses: ['Food', 'Transport', 'Book', 'Sweets'],
    saved: 'Savings kept', interest: 'Interest earned', luxury: 'Treat price', buy: 'Use interest', wait: 'Save and wait',
    disclaimer: 'Pretend money only. Interest is not guaranteed; rates, fees and risks vary. Ask a trusted adult or qualified adviser.', complete: 'All five levels complete!'
  },
  pcm: {
    subtitle: 'Learn Money from Age 2 reach Adult', level: 'Level',
    titles: ['Need or Want?', 'Save Small Small', 'Plan Before You Spend', 'No Spend Pass Your Money', 'Use Interest for Enjoyment'],
    lessons: ['Need first! Needs dey keep us healthy and safe. Wants na extra enjoyment. Sort pictures. Adult fit help.', 'Small savings dey grow. Share ten ₦50 coins for Save, Spend and Share. Put at least one coin for each bank.', 'You get ₦1,000. Choose food and transport first, then savings and wants. Plan every naira before spending.', 'Ada get ₦1,000, shoe cost ₦1,200. Borrow ₦200 mean say she go pay back later; fees fit join. Save ₦200 more, she fit buy without borrowing. Which one no go put her for debt?', 'Ada save ₦10,000 salary. For this pretend example, 5% interest na ₦500. Shoe na ₦400. Buy from salary: ₦9,600 remain. Buy from interest: salary ₦10,000 remain, interest ₦100 remain. Needs and emergency savings first.'],
    items: ['Food', 'Water', 'House', 'Teddy', 'Sweets', 'Video game'], needs: 'Needs', wants: 'Wants', banks: ['Save', 'Spend', 'Share'],
    listen: 'Hear lesson', check: 'Check my plan', again: 'Try again', next: 'Next level', success: 'You do well! Your plan correct.', retry: 'E never correct. Check lesson, try again.',
    left: 'Money remain', total: 'Total', add: 'Add', remove: 'Remove', expenses: ['Food', 'Transport', 'Book', 'Sweets'],
    saved: 'Savings safe', interest: 'Interest wey enter', luxury: 'Enjoyment price', buy: 'Use interest', wait: 'Save and wait',
    disclaimer: 'Na pretend money. Interest no sure; rate, fees and risk fit change. Ask trusted adult or qualified adviser.', complete: 'You finish all five levels!'
  },
  yo: {
    subtitle: 'Kọ́ nípa owó láti ọdún 2 sí àgbà', level: 'Ìpele',
    titles: ['Àìní àti Ìfẹ́', 'Fi Díẹ̀ Pamọ́', 'Gbero Kí O Tó Náwó', 'Má Ná Ju Owó Rẹ Lọ', 'Lo Èlé fún Ohun Ìgbádùn'],
    lessons: ['Àìní kọ́kọ́! Àìní ń dáàbò bo ìlera àti ààbò wa. Ìfẹ́ jẹ́ àfikún. Pín àwọn àwòrán. Àgbà lè ràn ọ́ lọ́wọ́.', 'Ìfipamọ́ kékeré ń dàgbà. Pín owó ₦50 mẹ́wàá sí Pamọ́, Ná àti Pín. Fi ẹyọ kan sí ọkọọkan.', 'O ní ₦1,000. Yan oúnjẹ àti ìrìnnà kọ́kọ́, lẹ́yìn náà ìfipamọ́ àti ìfẹ́. Gbero gbogbo owó.', 'Ada ní ₦1,000; bàtà jẹ́ ₦1,200. Yíyá ₦200 túmọ̀ sí gbèsè tí yóò san padà, ó sì lè ní owó iṣẹ́. Fífipamọ́ ₦200 sí i jẹ́ kí ó rà láìyá. Èwo kò ní gbèsè?', 'Ada fi owó oṣù ₦10,000 pamọ́. Nínú àpẹẹrẹ yìí, èlé 5% jẹ́ ₦500. Bàtà jẹ́ ₦400. Láti owó oṣù: ₦9,600 kù. Láti èlé: ₦10,000 àti èlé ₦100 kù. Àìní àti owó pàjáwìrì kọ́kọ́.'],
    items: ['Oúnjẹ', 'Omi', 'Ilé', 'Ọmọlangidi', 'Suwiti', 'Eré fídíò'], needs: 'Àìní', wants: 'Ìfẹ́', banks: ['Pamọ́', 'Ná', 'Pín'],
    listen: 'Gbọ́ ẹ̀kọ́', check: 'Ṣàyẹ̀wò ètò mi', again: 'Gbìyànjú lẹ́ẹ̀kan sí i', next: 'Ìpele tó kàn', success: 'O ṣe dáadáa! Ètò rẹ dára.', retry: 'Kò tíì tọ́. Ka ẹ̀kọ́, gbìyànjú lẹ́ẹ̀kan sí i.',
    left: 'Owó tó kù', total: 'Àpapọ̀', add: 'Fi kún', remove: 'Yọ', expenses: ['Oúnjẹ', 'Ìrìnnà', 'Ìwé', 'Suwiti'],
    saved: 'Ìfipamọ́ tó wà', interest: 'Èlé', luxury: 'Iye ohun ìgbádùn', buy: 'Lo èlé', wait: 'Pamọ́ kí o dúró',
    disclaimer: 'Owó àpẹẹrẹ nìkan. Èlé kì í ṣe ìlérí; iye, owó iṣẹ́ àti ewu lè yàtọ̀. Béèrè lọ́wọ́ àgbà tí o gbẹ́kẹ̀ lé tàbí amọ̀ràn tó yẹ.', complete: 'O parí gbogbo ìpele márùn-ún!'
  },
  ig: {
    subtitle: 'Mụta ego site n’afọ 2 ruo okenye', level: 'Ọkwa',
    titles: ['Ihe Dị Mkpa na Ihe Ị Chọrọ', 'Chekwaa Obere Ego', 'Mee Atụmatụ Tupu I Mee Mmefu', 'Ejila Ego Karịa I Nwere', 'Jiri Ọmụrụ Nwa Rụọ Ihe Ọchị'],
    lessons: ['Mkpa buru ụzọ! Ihe dị mkpa na-echebe ahụike na nchekwa. Ihe ị chọrọ bụ mgbakwunye. Kesaa foto. Okenye nwere ike inye aka.', 'Obere ego echekwara na-eto. Kesaa mkpụrụ ego ₦50 iri n’ime Nchekwa, Mmefu na Inye. Tinye otu n’ime nke ọ bụla.', 'Ị nwere ₦1,000. Họrọ nri na ụgbọ njem mbụ, mgbe ahụ nchekwa na ihe ị chọrọ. Mee atụmatụ ego niile.', 'Ada nwere ₦1,000; akpụkpọ ụkwụ bụ ₦1,200. Ịgbazite ₦200 pụtara ụgwọ ọ ga-akwụghachi, ụgwọ ọrụ nwere ike ịdị. Ichekwa ₦200 ọzọ na-eme ka ọ zụta n’enweghị ụgwọ. Kedu nke na-ezere ụgwọ?', 'Ada chekwara ụgwọ ọnwa ₦10,000. N’ihe atụ a, ọmụrụ nwa 5% bụ ₦500. Akpụkpọ ụkwụ bụ ₦400. Site na ụgwọ ọnwa: ₦9,600 fọdụrụ. Site n’ọmụrụ nwa: ₦10,000 na ₦100 fọdụrụ. Mkpa na ego mberede buru ụzọ.'],
    items: ['Nri', 'Mmiri', 'Ụlọ', 'Nwa bebi', 'Swiiti', 'Egwuregwu vidio'], needs: 'Mkpa', wants: 'Ihe a chọrọ', banks: ['Nchekwa', 'Mmefu', 'Inye'],
    listen: 'Nụrụ ihe ọmụmụ', check: 'Lelee atụmatụ m', again: 'Nwaa ọzọ', next: 'Ọkwa ọzọ', success: 'Ị mere nke ọma! Atụmatụ gị dị mma.', retry: 'Ọ kabeghị. Lelee ihe ọmụmụ ma nwaa ọzọ.',
    left: 'Ego fọdụrụ', total: 'Mkpokọta', add: 'Tinye', remove: 'Wepụ', expenses: ['Nri', 'Ụgbọ njem', 'Akwụkwọ', 'Swiiti'],
    saved: 'Ego echekwara', interest: 'Ọmụrụ nwa', luxury: 'Ọnụ ihe ọchị', buy: 'Jiri ọmụrụ nwa', wait: 'Chekwaa ma chere',
    disclaimer: 'Naanị ego ihe atụ. Ọmụrụ nwa abụghị nkwa; ọnụego, ụgwọ na ihe ize ndụ dị iche. Jụọ okenye ị tụkwasịrị obi ma ọ bụ onye ndụmọdụ ruru eru.', complete: 'Ị mechara ọkwa ise niile!'
  },
  ha: {
    subtitle: 'Koyi kuɗi daga shekara 2 zuwa babba', level: 'Mataki',
    titles: ['Buƙata da So', 'Ajiye Kaɗan', 'Tsara Kafin Kashe Kuɗi', 'Guji Kashe Fiye da Kuɗinka', 'Yi Amfani da Riba don Jin Daɗi'],
    lessons: ['Buƙata da farko! Buƙatu suna kare lafiya da tsaro. Abubuwan so ƙari ne. Raba hotuna. Babba zai iya taimakawa.', 'Ƙananan ajiya na taruwa. Raba tsabar ₦50 guda goma zuwa Ajiye, Kashe da Raba. Saka ɗaya a kowanne.', 'Kana da ₦1,000. Zaɓi abinci da sufuri da farko, sai ajiya da abubuwan so. Tsara duk kuɗin.', 'Ada tana da ₦1,000; takalma ₦1,200 ne. Aron ₦200 yana nufin bashi da za ta biya, kuma caji na iya ƙaruwa. Ajiye ƙarin ₦200 zai hana bashi. Wanne ya guji bashi?', 'Ada ta ajiye albashi ₦10,000. A wannan misali riba 5% ita ce ₦500. Takalma ₦400 ne. Daga albashi: ₦9,600 ya rage. Daga riba: ₦10,000 da riba ₦100 sun rage. Buƙatu da ajiyar gaggawa su fara.'],
    items: ['Abinci', 'Ruwa', 'Gida', 'Ɗan tsana', 'Alewa', 'Wasan bidiyo'], needs: 'Buƙatu', wants: 'Abubuwan so', banks: ['Ajiye', 'Kashe', 'Raba'],
    listen: 'Saurari darasi', check: 'Duba tsarina', again: 'Sake gwadawa', next: 'Mataki na gaba', success: 'Madalla! Tsarinka ya yi kyau.', retry: 'Ba tukuna ba. Duba darasi ka sake gwadawa.',
    left: 'Kuɗin da ya rage', total: 'Jimla', add: 'Ƙara', remove: 'Rage', expenses: ['Abinci', 'Sufuri', 'Littafi', 'Alewa'],
    saved: 'Ajiyar da ta rage', interest: 'Ribar da aka samu', luxury: 'Farashin jin daɗi', buy: 'Yi amfani da riba', wait: 'Ajiye ka jira',
    disclaimer: 'Kuɗin misali ne kawai. Riba ba tabbas ba ce; ƙima, caji da haɗari suna bambanta. Tambayi babban da ka amince da shi ko ƙwararren mai ba da shawara.', complete: 'Ka gama duk matakai biyar!'
  }
};
export const MONEY_EXTRA: Record<Lang, { borrow: string; save: string; salary: string; instruction: string; badge: string; local: string }> = {
  en: { borrow: 'Borrow ₦200', save: 'Save ₦200 more', salary: 'Buy with salary', instruction: 'Drag a picture, or tap it then a basket.', badge: 'Badge earned', local: 'Progress saved on this device.' },
  pcm: { borrow: 'Borrow ₦200', save: 'Save ₦200 join', salary: 'Buy with salary', instruction: 'Drag picture, or tap am then basket.', badge: 'You win badge', local: 'Progress save for this device.' },
  yo: { borrow: 'Yá ₦200', save: 'Fi ₦200 sí i pamọ́', salary: 'Rà pẹ̀lú owó oṣù', instruction: 'Fa àwòrán tàbí tẹ̀ ẹ́, lẹ́yìn náà apẹ̀rẹ̀.', badge: 'O gba àmì', local: 'Ìlọsíwájú wà lórí ẹ̀rọ yìí.' },
  ig: { borrow: 'Gbazite ₦200', save: 'Chekwaa ₦200 ọzọ', salary: 'Zụta na ụgwọ ọnwa', instruction: 'Dọrọ foto, ma ọ bụ pịa ya na nkata.', badge: 'Ị nwetara baajị', local: 'A na-echekwa ọganihu na ngwaọrụ a.' },
  ha: { borrow: 'Aro ₦200', save: 'Ajiye ƙarin ₦200', salary: 'Saya da albashi', instruction: 'Ja hoto, ko taɓa shi sannan kwando.', badge: 'Ka samu lamba', local: 'An adana ci gaba a wannan na’urar.' }
};