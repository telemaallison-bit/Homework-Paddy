import { z } from "zod";
import type { Lang } from "./i18n";

export type Gender = "female" | "male";
export type StyleCat = "hair" | "beard";

export type StyleEntry = {
  id: string;
  g: "female" | "male" | "both";
  cat: StyleCat;
  prompt: string;
  beard?: true;
  /** Typical Nigerian price range in naira, shown as an estimate. */
  price: [number, number];
  /** English display name; legacy ids also have translated names in HAIR_COPY. */
  name: string;
  /** Google Images search query for "see more varieties". */
  gsearch: string;
};

export const HAIR_STYLES: StyleEntry[] = [
  // Female hair
  { id: "braids", g: "female", cat: "hair", prompt: "neat shoulder-length black box braids", price: [8000, 15000], name: "Box braids", gsearch: "black women box braids styles 2026" },
  { id: "cornrows", g: "female", cat: "hair", prompt: "neat black cornrows braided close to the scalp, going straight back", price: [3000, 6000], name: "Cornrows", gsearch: "black women cornrows styles 2026" },
  { id: "afro", g: "both", cat: "hair", prompt: "a natural rounded black afro", price: [1500, 3000], name: "Afro", gsearch: "natural afro hairstyles 2026" },
  { id: "lowcut", g: "both", cat: "hair", prompt: "a tidy short natural black low haircut", price: [1500, 2500], name: "Low cut", gsearch: "black low cut hairstyles 2026" },
  { id: "twists", g: "female", cat: "hair", prompt: "shoulder-length black two-strand twists", price: [5000, 10000], name: "Twists", gsearch: "two strand twists natural hair styles 2026" },
  { id: "bun", g: "female", cat: "hair", prompt: "natural black hair gathered into a high bun", price: [3000, 6000], name: "High bun", gsearch: "natural hair high bun styles 2026" },
  // Male hair cuts
  { id: "lowcut_skin_fade", g: "male", cat: "hair", prompt: "a low haircut with a skin fade, shaved down to the skin at the sides and back", price: [1500, 2500], name: "Low cut - Skin fade", gsearch: "nigerian men skin fade low cut styles" },
  { id: "lowcut_low_fade", g: "male", cat: "hair", prompt: "a low haircut with a low fade, gradually tapering just above the ears", price: [1500, 2500], name: "Low cut - Low fade", gsearch: "nigerian men low fade haircut styles" },
  { id: "lowcut_high_fade", g: "male", cat: "hair", prompt: "a low haircut with a high fade, tapering high up the sides of the head", price: [1500, 2500], name: "Low cut - High fade", gsearch: "nigerian men high fade haircut styles" },
  { id: "afro_short", g: "male", cat: "hair", prompt: "a short neat natural black afro", price: [1000, 2000], name: "Short afro", gsearch: "men short afro hairstyles 2026" },
  { id: "afro_big", g: "male", cat: "hair", prompt: "a big full rounded natural black afro", price: [1500, 3000], name: "Big afro", gsearch: "men big afro hairstyles 2026" },
  { id: "afro_fade", g: "male", cat: "hair", prompt: "a natural black afro with a clean fade on the sides", price: [2000, 3500], name: "Afro with fade", gsearch: "men afro with fade hairstyles 2026" },
  { id: "dreadlocks", g: "male", cat: "hair", prompt: "neat shoulder-length black dreadlocks", price: [5000, 15000], name: "Dreadlocks", gsearch: "men dreadlocks styles 2026" },
  { id: "dreads_short", g: "male", cat: "hair", prompt: "short neat black dreadlocks just past the ears", price: [4000, 8000], name: "Short dreads", gsearch: "men short dreads styles 2026" },
  { id: "dreads_long", g: "male", cat: "hair", prompt: "long black dreadlocks reaching past the shoulders", price: [8000, 20000], name: "Long dreads", gsearch: "men long dreads styles 2026" },
  { id: "dreads_palm", g: "male", cat: "hair", prompt: "black palm-rolled dreadlocks, thin and neatly twisted", price: [6000, 12000], name: "Palm dreads", gsearch: "palm rolled dreads styles men" },
  { id: "waves", g: "male", cat: "hair", prompt: "short black hair with deep 360 waves", price: [1500, 3000], name: "Waves", gsearch: "360 waves haircut black men" },
  { id: "waves_360", g: "male", cat: "hair", prompt: "short black hair brushed into deep 360 waves all around the head", price: [1500, 3000], name: "360 waves", gsearch: "360 waves haircut black men" },
  { id: "waves_180", g: "male", cat: "hair", prompt: "short black hair with 180 waves on top and neat sides", price: [1500, 2500], name: "180 waves", gsearch: "180 waves haircut black men" },
  { id: "waves_lowcut", g: "male", cat: "hair", prompt: "a low haircut with visible waves on top", price: [1500, 2500], name: "Waves with low cut", gsearch: "waves with low cut black men" },
  { id: "cornrows_2", g: "male", cat: "hair", prompt: "two straight black cornrow braids for a man, going straight back", price: [2000, 4000], name: "Cornrows - 2 lines", gsearch: "men two cornrows braids styles" },
  { id: "cornrows_6", g: "male", cat: "hair", prompt: "six straight black cornrow braids for a man, going straight back", price: [3000, 5000], name: "Cornrows - 6 lines", gsearch: "men six cornrows braids styles" },
  { id: "cornrows_zigzag", g: "male", cat: "hair", prompt: "black cornrow braids for a man in a zigzag pattern", price: [3000, 6000], name: "Cornrows - Zigzag", gsearch: "men zigzag cornrows styles" },
  { id: "twists_men", g: "male", cat: "hair", prompt: "short black two-strand twists for a man", price: [3000, 6000], name: "Twists for men", gsearch: "men two strand twists hairstyles" },
  { id: "dye", g: "male", cat: "hair", prompt: "the same hairstyle dyed a rich auburn brown colour", price: [3000, 7000], name: "Hair dye", gsearch: "men auburn dyed hair black men styles" },
  // Male beard styles
  { id: "beard_full_short", g: "male", cat: "beard", prompt: "a short boxed full black beard, neatly trimmed close to the face", beard: true, price: [500, 1500], name: "Full beard - Short boxed", gsearch: "short boxed beard black men styles" },
  { id: "beard_full_long", g: "male", cat: "beard", prompt: "a long natural full black beard, full and well kept", beard: true, price: [1000, 2500], name: "Full beard - Long natural", gsearch: "long natural beard black men styles" },
  { id: "goatee_classic", g: "male", cat: "beard", prompt: "a classic black goatee on the chin only, no mustache", beard: true, price: [500, 1000], name: "Classic goatee", gsearch: "classic goatee black men styles" },
  { id: "goatee_mustache", g: "male", cat: "beard", prompt: "a black goatee connected to a mustache", beard: true, price: [500, 1200], name: "Goatee with mustache", gsearch: "goatee with mustache black men styles" },
  { id: "mustache_chevron", g: "male", cat: "beard", prompt: "a thick black chevron mustache only, no beard", beard: true, price: [300, 800], name: "Mustache - Chevron", gsearch: "chevron mustache styles men" },
  { id: "mustache_pencil", g: "male", cat: "beard", prompt: "a thin black pencil mustache only, no beard", beard: true, price: [300, 800], name: "Mustache - Pencil", gsearch: "pencil mustache styles men" },
  { id: "stubble_light", g: "male", cat: "beard", prompt: "light three-day black stubble across the jaw and chin", beard: true, price: [300, 700], name: "Light stubble (3-day)", gsearch: "light stubble beard black men" },
  { id: "stubble_heavy", g: "male", cat: "beard", prompt: "heavy black stubble, short and even across the jaw and chin", beard: true, price: [500, 1000], name: "Heavy stubble", gsearch: "heavy stubble beard black men" },
  { id: "clean_shave", g: "male", cat: "beard", prompt: "a completely clean-shaven face with no facial hair at all", beard: true, price: [500, 1000], name: "Clean shave", gsearch: "clean shave black men grooming" },
  { id: "beard_lineup", g: "male", cat: "beard", prompt: "a black beard with a sharp line-up, crisp edges on the cheeks and jawline", beard: true, price: [800, 1500], name: "Beard with line up", gsearch: "beard line up black men styles" },
  { id: "beard_fade", g: "male", cat: "beard", prompt: "a black beard with a fade, blending gradually into the sideburns", beard: true, price: [800, 1800], name: "Beard fade", gsearch: "beard fade black men styles" },
];
export type HairStyle = typeof HAIR_STYLES[number]["id"];

export function hairStylesFor(gender: Gender | null) {
  const g = gender ?? "female";
  return HAIR_STYLES.filter((s) => s.g === "both" || s.g === g);
}

export const hairRequestSchema = z.object({
  style: z.enum(HAIR_STYLES.map((s) => s.id) as [string, ...string[]]),
  lang: z.enum(["en", "pcm", "yo", "ig", "ha"]),
  requestId: z.string().uuid(),
});
export const HAIR_TRY_COST = 1;

type ExtraKey = "tabHair" | "tabBeard" | "myFavs" | "saveFav" | "favSaved" | "priceArea" | "modTitle" | "modMsg" | "modBtn" | "report" | "reportThanks" | "cooldown" | "moreOnGoogle" | "inspo" | "inspoHint" | "tryLook" | "fashion" | "fashionLink";
type HairCopy = Record<"title" | "upload" | "change" | "choose" | "try" | "busy" | "before" | "after" | "done" | "save" | "hear" | "privacy" | "invalid" | "buyLook" | ExtraKey, string> & Partial<Record<string, string>>;
export const HAIR_COPY: Record<Lang, HairCopy> = {
  en: { modTitle: "🙏 Let's Keep It Respectful", modMsg: "We noticed this image may contain content not allowed on Homework Paddy. We keep our app safe and respectful for everyone, including young students. Please upload a clear photo of your face and hair only, with decent clothing. Thank you for understanding - we appreciate you! ❤️", modBtn: "Okay, I Understand - Upload Decent Photo", report: "Report this", reportThanks: "Thank you - we will check it. 🙏", cooldown: "Please wait {n} minutes, then try again with a decent photo. We appreciate you! ❤️", moreOnGoogle: "🔍 See more varieties on Google", inspo: "Inspiration Gallery", inspoHint: "Inspiration from internet - Tap to try", tryLook: "Try this look", fashion: "Female Fashion", fashionLink: "👗 See Ankara & fashion styles on Google", title: "Try a hairstyle", upload: "Add your photo", change: "Change photo", choose: "Choose a hairstyle", try: "Try this look (1 try)", busy: "Creating your look…", before: "Your photo", after: "Your new look", done: "Your new look is ready!", save: "Save photo", hear: "Hear it", privacy: "Your photo is sent to AI for this look. We do not save it.", invalid: "Choose a JPG, PNG or WebP photo under 8 MB.", buyLook: "Buy this look ₦12k–₦18k from WhatsApp vendors", tabHair: "Hair Cut", tabBeard: "Beard Style", myFavs: "My Favorite Cuts", saveFav: "Save to favorites", favSaved: "Saved to your favorites!", priceArea: "{range} in your area", braids: "Box braids", cornrows: "Cornrows", afro: "Afro", lowcut: "Low cut", twists: "Twists", bun: "High bun", dreadlocks: "Dreadlocks", waves: "Waves", dye: "Hair dye" },
  pcm: { modTitle: "🙏 Make We Keep Am Clean", modMsg: "We see say this photo fit get wetin we no dey allow for Homework Paddy. We dey keep our app safe and clean for everybody, even small pikin dem. Abeg upload clear photo of your face and hair only, with correct cloth. Thank you for understanding - we appreciate you! ❤️", modBtn: "Okay, I Understand - Make I Upload Correct Photo", report: "Report this", reportThanks: "Thank you - we go check am. 🙏", cooldown: "Abeg wait {n} minutes, then try again with correct photo. We appreciate you! ❤️", moreOnGoogle: "🔍 See more styles for Google", inspo: "Inspiration Gallery", inspoHint: "Inspiration from internet - Tap make you try am", tryLook: "Try this look", fashion: "Woman Fashion", fashionLink: "👗 See Ankara & fashion styles for Google", title: "Try new hair", upload: "Add your photo", change: "Change photo", choose: "Choose the hair wey you like", try: "Try this hair (1 try)", busy: "We dey make your new look…", before: "Your photo", after: "Your new look", done: "Your new look don ready!", save: "Save photo", hear: "Hear am", privacy: "We send your photo to AI for this look. We no dey save am.", invalid: "Choose JPG, PNG or WebP photo wey no reach 8 MB.", buyLook: "Buy this look ₦12k–₦18k from WhatsApp sellers", tabHair: "Hair Cut", tabBeard: "Beard Style", myFavs: "Cuts Wey I Like", saveFav: "Keep am for favorites", favSaved: "E don enter your favorites!", priceArea: "{range} for your area", braids: "Box braids", cornrows: "Cornrows", afro: "Afro", lowcut: "Low cut", twists: "Twists", bun: "High bun", dreadlocks: "Dada", waves: "Waves", dye: "Dye hair" },
  yo: { modTitle: "🙏 Ẹ Jọ̀wọ́, Ẹ Ṣe Ọ̀ Pẹ̀lú Ọ̀wọ̀", modMsg: "A rí i pé fọto yìí lè ní ohun tí a kò gba àyè lórí Homework Paddy. A ń pa app wa mọ́ọ́ àti ní ọ̀wọ̀ fún gbogbo ènìyàn, pẹ̀lú àwọn akẹ́kọ̀ọ́ kéékèèké. Ẹ jọ̀wọ́ fi fọto ojú àti irun yín nìkan kun, pẹ̀lú aṣọ tó tọ́. Ẹ ṣeun fún òyínbó yín - a mọ̀rírì yín! ❤️", modBtn: "Ó dáa, Mo Gbọ́ - Kìn Fi Fọto Tó Tọ́ Kun", report: "Fi ẹ̀sùn yìí kan", reportThanks: "Ẹ ṣeun - a máa ṣàyẹ̀wò ó. 🙏", cooldown: "Ẹ jọ̀wọ́ dúró ìṣẹ́jú {n}, kí ẹ sì gbiyanju pẹ̀lú fọto tó tọ́. A mọ̀rírì yín! ❤️", moreOnGoogle: "🔍 Wo àwọn ìrísí míì lórí Google", inspo: "Àwòrán Ìṣíṣẹ́yìn", inspoHint: "Ìṣíṣẹ́yìn láti inú ayélujára - Tẹ láti gbiyanju", tryLook: "Gbiyanju ìrísí yìí", fashion: "Aṣọ Obìnrin", fashionLink: "👗 Wo àwọn aṣọ Ankara lórí Google", title: "Gbiyanju irun tuntun", upload: "Fi fọto rẹ kun", change: "Yí fọto padà", choose: "Yan irú irun", try: "Gbiyanju irun yìí (ìgbìyànjú 1)", busy: "A ń ṣe ìrísí tuntun rẹ…", before: "Fọto rẹ", after: "Ìrísí tuntun rẹ", done: "Ìrísí tuntun rẹ ti ṣetan!", save: "Fi fọto pamọ́", hear: "Gbọ́ ọ", privacy: "A fi fọto rẹ ránṣẹ́ sí AI fún ìrísí yìí. A kò fi pamọ́.", invalid: "Yan fọto JPG, PNG tàbí WebP tí kò tó 8 MB.", buyLook: "Ra ìrísí yìí ₦12k–₦18k lọ́wọ́ àwọn oníṣòwò WhatsApp", tabHair: "Gígé Irun", tabBeard: "Ìrẹ̀hìn", myFavs: "Àwọn Tó Wù Mí", saveFav: "Fi pamọ́ sí àwọn ayanfẹ́", favSaved: "A ti fi í pamọ́!", priceArea: "{range} ní agbègbè rẹ", braids: "Irun dídì", cornrows: "Dídì irun sí orí", afro: "Afro", lowcut: "Irun kúkúrú", twists: "Irun yíyí", bun: "Irun tí a kó sókè", dreadlocks: "Dada", waves: "Waves", dye: "Àwọ̀ irun" },
  ig: { modTitle: "🙏 Ka Anyị Nwee Nkwanye Ùgwù", modMsg: "Anyị hụrụ na foto a nwere ike ịnwe ihe a na-anabata na Homework Paddy. Anyị na-edebe app anyị nchebe na nkwanye ùgwù maka mmadụ niile, gụnyere ụmụ akwụkwọ. Biko tinye foto doro anya nke ihu na ntutu gị naanị, yie uwe kwesịrị ekwesị. Daalụ maka nghọta gị - anyị na-enwe ekele maka gị! ❤️", modBtn: "Ọ Dị Mma, Aghọtara M - Ka M Tinye Foto Kwesịrị Ekwesị", report: "Kọrọ ihe a", reportThanks: "Daalụ - anyị ga-ele ya anya. 🙏", cooldown: "Biko chere nkeji {n}, wee nwaa ọzọ na foto kwesịrị ekwesị. Anyị na-enwe ekele maka gị! ❤️", moreOnGoogle: "🔍 Lee ụdị ndị ọzọ na Google", inspo: "Gallery Inspiration", inspoHint: "Inspiration si na internet - Kpatu iji nwaa ya", tryLook: "Nwaa ọdịdị a", fashion: "Uwe Ụmụnwanyị", fashionLink: "👗 Lee ụdị Ankara na uwe na Google", title: "Nwaa ụdị ntutu ọhụrụ", upload: "Tinye foto gị", change: "Gbanwee foto", choose: "Họrọ ụdị ntutu", try: "Nwaa ntutu a (ohere 1)", busy: "Anyị na-eme ọdịdị ọhụrụ gị…", before: "Foto gị", after: "Ọdịdị ọhụrụ gị", done: "Ọdịdị ọhụrụ gị adịla njikere!", save: "Chekwaa foto", hear: "Nụrụ ya", privacy: "Anyị na-ezigara AI foto gị maka ọdịdị a. Anyị anaghị echekwa ya.", invalid: "Họrọ foto JPG, PNG ma ọ bụ WebP na-erughị 8 MB.", buyLook: "Gọta ọdịdị a ₦12k–₦18k n'aka ndị na-ere na WhatsApp", tabHair: "Ibe Ntutu", tabBeard: "Ntutu Ahụ", myFavs: "Ndị M Hụrụ N'anya", saveFav: "Chekwaa n'ndị m hụrụ n'anya", favSaved: "Echekwala ya!", priceArea: "{range} n'ógbè gị", braids: "Ntutu a kpara", cornrows: "Ntutu a kpara n'isi", afro: "Afro", lowcut: "Ntutu dị mkpụmkpụ", twists: "Ntutu a tụgharịrị", bun: "Ntutu a chịkọtara elu", dreadlocks: "Dada", waves: "Waves", dye: "Agba ntutu" },
  ha: { modTitle: "🙏 Bari Mu Yi Mutunci", modMsg: "Mun lura cewa wannan hoton na iya ɗaukar abin da ba a yarda da shi a Homework Paddy. Muna kiyaye app ɗinmu lafiya da mutunci ga kowa, har da ƙananan ɗaliban. Don Allah ku ɗora hoton fuska da gashinku kawai, tare da tufafi masu kyau. Mun godiya da fahimtarku - muna godiya da ku! ❤️", modBtn: "To, Na Fahimta - Zan Ɗora Hoto Mai Kyau", report: "Kai rahoto", reportThanks: "Mun godiya - za mu duba shi. 🙏", cooldown: "Don Allah ku jira minti {n}, sannan ku sake gwadawa da hoto mai kyau. Muna godiya da ku! ❤️", moreOnGoogle: "🔍 Duba ƙarin salo a Google", inspo: "Gallery na Inspiration", inspoHint: "Inspiration daga intanet - Danna don gwada", tryLook: "Gwada wannan salon", fashion: "Kayan Mata", fashionLink: "👗 Duba salon Ankara da kayan mata a Google", title: "Gwada sabon salon gashi", upload: "Ƙara hotonka", change: "Canja hoto", choose: "Zaɓi salon gashi", try: "Gwada wannan salon (dama 1)", busy: "Ana ƙirƙirar sabon kamanninka…", before: "Hotonka", after: "Sabon kamanninka", done: "Sabon kamanninka ya shirya!", save: "Ajiye hoto", hear: "Saurara", privacy: "Ana aika hotonka zuwa AI don wannan salon. Ba ma adana shi.", invalid: "Zaɓi hoton JPG, PNG ko WebP ƙasa da 8 MB.", buyLook: "Sayi wannan salon ₦12k–₦18k daga 'yan kasuwar WhatsApp", tabHair: "Askar Gashi", tabBeard: "Geme", myFavs: "Waɗanda Na So", saveFav: "Ajiye a waɗanda ka so", favSaved: "An ajiye shi!", priceArea: "{range} a yankinku", braids: "Kitso", cornrows: "Kitso a kan kai", afro: "Afro", lowcut: "Gajeren gashi", twists: "Murɗaɗɗen gashi", bun: "Gashi da aka ɗaure sama", dreadlocks: "Dada", waves: "Waves", dye: "Rina gashi" },
};

/** Display name: translated when the language has one, otherwise the English name. */
export function styleName(copy: HairCopy, style: StyleEntry) {
  return copy[style.id] ?? style.name;
}

export function priceRange(style: StyleEntry) {
  const fmt = (n: number) => `₦${n.toLocaleString("en-NG")}`;
  return `${fmt(style.price[0])} – ${fmt(style.price[1])}`;
}

export const FASHION_SEARCH = "ankara styles 2026 female nigerian fashion";

export function hairPrompt(style: HairStyle) {
  const choice = HAIR_STYLES.find((s) => s.id === style);
  if (!choice) throw new Error("Invalid hairstyle");
  const change = choice.beard
    ? `Change ONLY the facial hair to ${choice.prompt}. Work only on the lower face (jaw, chin, cheeks, upper lip). Do not touch the hair on the head.`
    : `Change ONLY the hair to ${choice.prompt}.`;
  return `Edit the uploaded portrait for a family-friendly hairstyle try-on. ${change} Preserve the exact person's face, age, skin tone, expression, body, clothing, camera framing, lighting and background. Keep the result photorealistic, with natural hairline and realistic hair texture. Do not change age or beautify the face. Do not add text, labels, accessories or additional people.`;
}
