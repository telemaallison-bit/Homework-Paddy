export type BarberFilters = { maxKm?: number | undefined; maxPrice?: number | undefined; minRating?: number | undefined };

export type Barber = {
  id: string; name: string; area: string; city: string; state: string;
  lat: number; lng: number; rating: number; priceFrom: number; open: boolean; phone: string;
};

export const NG_STATES = [
  "Abia","Adamawa","Akwa Ibom","Anambra","Bauchi","Bayelsa","Benue","Borno","Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","FCT (Abuja)","Gombe","Imo","Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi","Kwara","Lagos","Nasarawa","Niger","Ogun","Ondo","Osun","Oyo","Plateau","Rivers","Sokoto","Taraba","Yobe","Zamfara",
] as const;

export const BARBERS: Barber[] = [
  {
    "id": "b1",
    "name": "Prime Styles Salon",
    "area": "Oshodi",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.49572,
    "lng": 3.29737,
    "rating": 4.1,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348042756110"
  },
  {
    "id": "b2",
    "name": "Braids Palace Barbers",
    "area": "Victoria Island",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.54237,
    "lng": 3.35616,
    "rating": 3.9,
    "priceFrom": 1500,
    "open": true,
    "phone": "2348015735478"
  },
  {
    "id": "b3",
    "name": "Classic Hands Barbers",
    "area": "Egbeda",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.5842,
    "lng": 3.34168,
    "rating": 4.6,
    "priceFrom": 5000,
    "open": true,
    "phone": "2348074078881"
  },
  {
    "id": "b4",
    "name": "Royal Blend Salon",
    "area": "Oshodi",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.60877,
    "lng": 3.32553,
    "rating": 4.4,
    "priceFrom": 5000,
    "open": true,
    "phone": "2348027262875"
  },
  {
    "id": "b5",
    "name": "Master Stroke Salon",
    "area": "Ikorodu",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.54026,
    "lng": 3.26991,
    "rating": 4.3,
    "priceFrom": 3500,
    "open": true,
    "phone": "2348018486646"
  },
  {
    "id": "b6",
    "name": "Fine Touch Barbers",
    "area": "Maryland",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.62116,
    "lng": 3.42594,
    "rating": 4.2,
    "priceFrom": 5000,
    "open": false,
    "phone": "2348019634812"
  },
  {
    "id": "b7",
    "name": "Classic Hands Salon",
    "area": "Ikorodu",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.52181,
    "lng": 3.37417,
    "rating": 4.3,
    "priceFrom": 1500,
    "open": true,
    "phone": "2348062692285"
  },
  {
    "id": "b8",
    "name": "Velvet Touch Barbers",
    "area": "Apapa",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.51093,
    "lng": 3.29004,
    "rating": 3.8,
    "priceFrom": 4000,
    "open": true,
    "phone": "2348038620344"
  },
  {
    "id": "b9",
    "name": "Fresh Look Barbers",
    "area": "Gbagada",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.53926,
    "lng": 3.44642,
    "rating": 3.6,
    "priceFrom": 4000,
    "open": true,
    "phone": "2348016290787"
  },
  {
    "id": "b10",
    "name": "Gidi Cuts Salon",
    "area": "Oshodi",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.4307,
    "lng": 3.46334,
    "rating": 4.7,
    "priceFrom": 4000,
    "open": true,
    "phone": "2348086567780"
  },
  {
    "id": "b11",
    "name": "Lush Locks Salon",
    "area": "Egbeda",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.51223,
    "lng": 3.39476,
    "rating": 5,
    "priceFrom": 5000,
    "open": true,
    "phone": "2348087172910"
  },
  {
    "id": "b12",
    "name": "Fresh Look Barbers",
    "area": "Ajah",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.44542,
    "lng": 3.33611,
    "rating": 5,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348030175046"
  },
  {
    "id": "b13",
    "name": "Crown & Comb Barbers",
    "area": "Ikorodu",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.60273,
    "lng": 3.33539,
    "rating": 4.6,
    "priceFrom": 3000,
    "open": true,
    "phone": "2348030375873"
  },
  {
    "id": "b14",
    "name": "Master Stroke Salon",
    "area": "Apapa",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.42976,
    "lng": 3.4213,
    "rating": 4.5,
    "priceFrom": 2500,
    "open": true,
    "phone": "2348044097048"
  },
  {
    "id": "b15",
    "name": "Kings & Queens Salon",
    "area": "Maryland",
    "city": "Lagos",
    "state": "Lagos",
    "lat": 6.57655,
    "lng": 3.41908,
    "rating": 3.9,
    "priceFrom": 1500,
    "open": true,
    "phone": "2348073115511"
  },
  {
    "id": "b16",
    "name": "Naija Fresh Salon",
    "area": "Maitama",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 9.1399,
    "lng": 7.32037,
    "rating": 4.4,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348054906901"
  },
  {
    "id": "b17",
    "name": "Velvet Touch Salon",
    "area": "Garki",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 9.09777,
    "lng": 7.45215,
    "rating": 4.8,
    "priceFrom": 1500,
    "open": true,
    "phone": "2348042942680"
  },
  {
    "id": "b18",
    "name": "Kings & Queens Barbers",
    "area": "Asokoro",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 8.98918,
    "lng": 7.43495,
    "rating": 3.7,
    "priceFrom": 4000,
    "open": false,
    "phone": "2348068987046"
  },
  {
    "id": "b19",
    "name": "City Glow Barbers",
    "area": "Asokoro",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 9.00556,
    "lng": 7.41912,
    "rating": 4.4,
    "priceFrom": 4000,
    "open": false,
    "phone": "2348050186177"
  },
  {
    "id": "b20",
    "name": "Star Barbers Salon",
    "area": "Asokoro",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 9.12462,
    "lng": 7.31632,
    "rating": 4.1,
    "priceFrom": 4000,
    "open": true,
    "phone": "2348045802958"
  },
  {
    "id": "b21",
    "name": "Fine Touch Salon",
    "area": "Wuse 2",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 8.96838,
    "lng": 7.37557,
    "rating": 4.4,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348073397461"
  },
  {
    "id": "b22",
    "name": "De-Choice Salon",
    "area": "Lugbe",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 8.99007,
    "lng": 7.46702,
    "rating": 4.1,
    "priceFrom": 2000,
    "open": false,
    "phone": "2348082540932"
  },
  {
    "id": "b23",
    "name": "True Cut Barbers",
    "area": "Nyanya",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 9.06185,
    "lng": 7.46365,
    "rating": 3.8,
    "priceFrom": 3500,
    "open": true,
    "phone": "2348038816186"
  },
  {
    "id": "b24",
    "name": "Glow Salon Salon",
    "area": "Garki",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 8.97166,
    "lng": 7.40802,
    "rating": 4.3,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348085426623"
  },
  {
    "id": "b25",
    "name": "Smooth Finish Barbers",
    "area": "Maitama",
    "city": "Abuja",
    "state": "FCT (Abuja)",
    "lat": 9.02147,
    "lng": 7.39595,
    "rating": 4.5,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348070097817"
  },
  {
    "id": "b26",
    "name": "City Glow Salon",
    "area": "Trans Amadi",
    "city": "Port Harcourt",
    "state": "Rivers",
    "lat": 4.75925,
    "lng": 6.98952,
    "rating": 3.9,
    "priceFrom": 2500,
    "open": true,
    "phone": "2348082928886"
  },
  {
    "id": "b27",
    "name": "Prime Styles Salon",
    "area": "Trans Amadi",
    "city": "Port Harcourt",
    "state": "Rivers",
    "lat": 4.79769,
    "lng": 7.09018,
    "rating": 4.5,
    "priceFrom": 2500,
    "open": true,
    "phone": "2348087752466"
  },
  {
    "id": "b28",
    "name": "Naija Fresh Salon",
    "area": "Nassarawa",
    "city": "Kano",
    "state": "Kano",
    "lat": 12.07667,
    "lng": 8.62783,
    "rating": 4.2,
    "priceFrom": 5000,
    "open": false,
    "phone": "2348033325327"
  },
  {
    "id": "b29",
    "name": "Master Stroke Salon",
    "area": "Sabon Gari",
    "city": "Kano",
    "state": "Kano",
    "lat": 12.09943,
    "lng": 8.64678,
    "rating": 4.6,
    "priceFrom": 2000,
    "open": true,
    "phone": "2348055065210"
  },
  {
    "id": "b30",
    "name": "Velvet Touch Salon",
    "area": "Bodija",
    "city": "Ibadan",
    "state": "Oyo",
    "lat": 7.44111,
    "lng": 3.95004,
    "rating": 4.9,
    "priceFrom": 2500,
    "open": true,
    "phone": "2348053990137"
  },
  {
    "id": "b31",
    "name": "Fine Line Salon",
    "area": "Bodija",
    "city": "Ibadan",
    "state": "Oyo",
    "lat": 7.30627,
    "lng": 4.04963,
    "rating": 3.6,
    "priceFrom": 3500,
    "open": true,
    "phone": "2348075089299"
  },
  {
    "id": "b32",
    "name": "Smooth Finish Salon",
    "area": "New Haven",
    "city": "Enugu",
    "state": "Enugu",
    "lat": 6.48706,
    "lng": 7.5896,
    "rating": 4.9,
    "priceFrom": 4000,
    "open": true,
    "phone": "2348033586103"
  },
  {
    "id": "b33",
    "name": "Crown & Comb Salon",
    "area": "Independence Layout",
    "city": "Enugu",
    "state": "Enugu",
    "lat": 6.49259,
    "lng": 7.45906,
    "rating": 4.5,
    "priceFrom": 2500,
    "open": true,
    "phone": "2348021384344"
  }
];

export function barbersInState(state: string): Barber[] {
  return BARBERS.filter((b) => b.state === state);
}

export function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}


export function filterBarbers(
  list: Barber[],
  user: { lat: number; lng: number } | null,
  f: BarberFilters,
): (Barber & { km?: number | undefined })[] {
  return list
    .map((b) => ({ ...b, km: user ? distanceKm(user, b) : undefined }))
    .filter((b) => (f.maxKm == null || b.km == null ? true : b.km <= f.maxKm))
    .filter((b) => (f.maxPrice == null ? true : b.priceFrom <= f.maxPrice))
    .filter((b) => (f.minRating == null ? true : b.rating >= f.minRating))
    .sort((x, y) => (x.km ?? 1e9) - (y.km ?? 1e9));
}
