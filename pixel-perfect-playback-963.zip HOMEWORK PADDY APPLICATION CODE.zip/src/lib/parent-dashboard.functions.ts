import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { dashboardStatsSchema } from './parent-dashboard';
import { solutionSchema } from './maths/model';
export const getParentDashboard = createServerFn({method:'POST'})
 .middleware([requireSupabaseAuth])
 .inputValidator(z.object({page:z.number().int().min(1).max(10000)}))
 .handler(async ({data,context}) => {
  const offset=(data.page-1)*20;
  const [stats,history]=await Promise.all([
   context.supabase.rpc('parent_learning_stats'),
   context.supabase.from('learning_history').select('id,question,topic,answer,solution,level,method,lang,feature,created_at',{count:'exact'}).eq('user_id',context.userId).order('created_at',{ascending:false}).order('id',{ascending:false}).range(offset,offset+19),
  ]);
  if(stats.error||history.error) throw new Error('Learning progress could not load.');
  return {stats:dashboardStatsSchema.parse(stats.data), count:history.count??0, history:(history.data??[]).map(row=>({...row,solution:solutionSchema.parse(row.solution)}))};
 });