import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { PACKAGES, creditsForPayment, type PackageId, type Provider } from "./packages";
import { PAYMENTS_ENABLED } from "./free-learning";

export const getWallet = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [w, tx, admin] = await Promise.all([
      supabase.rpc("get_free_solves"),
      supabase.from("transactions").select("credits_bought").eq("user_id", userId),
      supabase.rpc("has_role", { _user_id: userId, _role: "admin" }),
    ]);
    const totalPurchased = (tx.data ?? []).reduce((s, r) => s + r.credits_bought, 0);
    if (w.error) throw new Error("Could not check today's free solves.");
    return { credits: w.data ?? 3, isPaid: totalPurchased > 0, isAdmin: !!admin.data, totalPurchased };
  });

export const spendCredit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { feature: "solve" | "tryon" | "spell" }) => d)
  .handler(async ({ data, context }) => {
    const { data: n, error } = await context.supabase.rpc("spend_credit", { _feature: data.feature });
    if (error) throw new Error("Could not use credit");
    return { ok: n >= 0, credits: Math.max(0, n) };
  });

export const claimAdReward = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: n, error } = await context.supabase.rpc("claim_ad_reward");
    if (error) throw new Error("Could not add tries");
    return { ok: n >= 0, credits: Math.max(0, n) };
  });

export const getPayConfig = createServerFn({ method: "GET" }).handler(async () => ({
  paystackKey: PAYMENTS_ENABLED ? process.env['PAYSTACK_PUBLIC_KEY'] ?? null : null,
}));

export const verifyPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { provider: Provider; reference: string; pkg: PackageId }) => d)
  .handler(async ({ data, context }) => {
    if (!PAYMENTS_ENABLED) throw new Error("Enjoy Free For Now - Coming Soon");
    if (!PACKAGES[data.pkg]) throw new Error("Bad package");
    if (data.provider !== "Paystack") throw new Error("Bad provider");
    // Test secret is saved as STRIPE_TEST_API_KEY for now. On the live swap, save
    // PAYSTACK_SECRET_KEY with the sk_live_ key, then delete STRIPE_TEST_API_KEY.
    const key = process.env['PAYSTACK_SECRET_KEY'] ?? process.env['STRIPE_TEST_API_KEY'];
    if (!key) throw new Error("Paystack not set up");
    const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(data.reference)}`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    const j: any = await r.json();
    if (!j?.status || j.data?.status !== "success" || j.data?.currency !== "NGN") throw new Error("Payment not confirmed");
    const paidNaira = j.data.amount / 100;
    const credits = creditsForPayment(data.pkg, paidNaira);
    if (!credits) throw new Error("Amount does not match");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const ins = await supabaseAdmin.from("transactions").insert({
      user_id: context.userId, amount: paidNaira, credits_bought: credits, payment_method: data.provider, reference: data.reference,
    });
    if (ins.error) {
      if (ins.error.code === "23505") throw new Error("Payment already used");
      throw new Error("Could not save payment");
    }
    const { data: n } = await supabaseAdmin.rpc("add_credits", { _user_id: context.userId, _n: credits });
    return { credits: n ?? 0, added: credits };
  });

export const getAdminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) throw new Error("Forbidden");
    const [users, tx, usage] = await Promise.all([
      supabase.from("wallets").select("user_id", { count: "exact", head: true }),
      supabase.from("transactions").select("amount, credits_bought, payment_method, date"),
      supabase.from("usage_events").select("kind").neq("kind", "ad"),
    ]);
    const today = new Date().toISOString().slice(0, 10);
    const rev = { Paystack: 0 };
    let soldToday = 0;
    for (const t of tx.data ?? []) {
      if (t.payment_method === "Paystack") rev.Paystack += t.amount;
      if (t.date.slice(0, 10) === today) soldToday += t.credits_bought;
    }
    const counts: Record<string, number> = {};
    for (const u of usage.data ?? []) counts[u.kind] = (counts[u.kind] ?? 0) + 1;
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    return { totalUsers: users.count ?? 0, revenue: rev, soldToday, topFeature: top ? { kind: top[0], uses: top[1] } : null, counts };
  });
