import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { parseDdg, type SearchResult } from "@/lib/search";

// Free, keyless web answers via DuckDuckGo's instant-answer API.
// Runs server-side because the API does not allow browser (CORS) calls.
export const searchWeb = createServerFn({ method: "GET" })
  .validator((d: unknown) => z.object({ q: z.string().trim().min(2).max(120) }).parse(d))
  .handler(async ({ data }): Promise<SearchResult[]> => {
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(data.q)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(url, { headers: { "User-Agent": "HomeworkPaddyApp/1.0" } });
    if (!res.ok) return [];
    const j = (await res.json()) as Parameters<typeof parseDdg>[0];
    return parseDdg(j, 5);
  });
