import { describe, expect, it } from 'vitest';
import { budgetLeft, correctBucket, interestLesson, PLANNER_BUDGET, TOTAL_COINS, parseProgress, progressKey } from './money';
describe('Money Paddy rules', () => {
  it('gives ten coins and saves valid badges separately for each learner', () => {
    expect(TOTAL_COINS).toBe(10);
    expect(parseProgress('[0,1,1,4,5,-1]')).toEqual([0,1,4]);
    expect(progressKey('a')).not.toBe(progressKey('b'));
    expect(parseProgress('bad')).toEqual([]);
  });
  it('plans exactly one thousand naira', () => {
    expect(PLANNER_BUDGET).toBe(1000);
    expect(budgetLeft([500, 300, 200])).toBe(0);
    expect(budgetLeft([800, 300])).toBe(-100);
  });
  it('sorts basic needs separately from optional wants', () => {
    expect(correctBucket('food', 'need')).toBe(true);
    expect(correctBucket('water', 'want')).toBe(false);
    expect(correctBucket('toy', 'want')).toBe(true);
  });
  it('luxuries use interest without spending the saved principal', () => {
    expect(interestLesson(10000, 5, 400)).toEqual({ interest: 500, affordable: true, principal: 10000 });
    expect(interestLesson(10000, 5, 600).affordable).toBe(false);
  });
});