export const DAILY_FREE_SOLVES = 3;
export const AD_EXTRA_SOLVES = 2;
export const MAX_DAILY_ADS = 3;
export const PREMIUM_OPTIONS = [{ days: 3, naira: 200 }, { days: 7, naira: 500 }] as const;
export const PAYMENTS_ENABLED = false; // growth phase: app is 100% free, solves never blocked
export function remainingSolves(used: number, bonus = 0) { return Math.max(0, DAILY_FREE_SOLVES + bonus - used); }
export function lagosDay(date: Date) { return new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Lagos', year: 'numeric', month: '2-digit', day: '2-digit' }).format(date); }