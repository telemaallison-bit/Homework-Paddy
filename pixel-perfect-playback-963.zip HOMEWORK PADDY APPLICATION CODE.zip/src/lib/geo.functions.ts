import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

// Reverse-geocode coordinates to a Nigerian city/state label via OpenStreetMap Nominatim.
export const reverseGeocode = createServerFn({ method: "GET" })
  .validator((d: unknown) => z.object({ lat: z.number(), lng: z.number() }).parse(d))
  .handler(async ({ data }) => {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${data.lat}&lon=${data.lng}&zoom=10`;
    const res = await fetch(url, {
      headers: { "User-Agent": "HomeworkPaddyApp/1.0 (contact: telema.allison@yahoo.com)", "Accept-Language": "en" },
    });
    if (!res.ok) throw new Error("Could not find your area");
    const j = (await res.json()) as { address?: Record<string, string> };
    const a = j.address ?? {};
    const city = a["city"] ?? a["town"] ?? a["village"] ?? a["suburb"] ?? a["county"] ?? "your area";
    const state = a["state"] ?? "";
    return { city, state };
  });
