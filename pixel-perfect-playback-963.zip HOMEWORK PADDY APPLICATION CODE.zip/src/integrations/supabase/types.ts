export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      ai_access_state: {
        Row: {
          blocked: boolean
          model: string
          reason: string
          updated_at: string
        }
        Insert: {
          blocked?: boolean
          model: string
          reason: string
          updated_at?: string
        }
        Update: {
          blocked?: boolean
          model?: string
          reason?: string
          updated_at?: string
        }
        Relationships: []
      }
      blocked_logs: {
        Row: {
          created_at: string
          id: string
          reason: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          reason: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_learning_allowance: {
        Row: {
          ad_claims: number
          bonus: number
          day: string
          used: number
          user_id: string
        }
        Insert: {
          ad_claims?: number
          bonus?: number
          day: string
          used?: number
          user_id: string
        }
        Update: {
          ad_claims?: number
          bonus?: number
          day?: string
          used?: number
          user_id?: string
        }
        Relationships: []
      }
      hair_tryon_attempts: {
        Row: {
          created_at: string
          id: string
          replayed: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          id: string
          replayed?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          replayed?: boolean
          user_id?: string
        }
        Relationships: []
      }
      learning_history: {
        Row: {
          answer: string
          created_at: string
          feature: string
          id: string
          lang: string
          level: string
          method: string
          question: string
          solution: Json
          topic: string
          user_id: string
        }
        Insert: {
          answer: string
          created_at?: string
          feature: string
          id: string
          lang: string
          level: string
          method: string
          question: string
          solution: Json
          topic: string
          user_id: string
        }
        Update: {
          answer?: string
          created_at?: string
          feature?: string
          id?: string
          lang?: string
          level?: string
          method?: string
          question?: string
          solution?: Json
          topic?: string
          user_id?: string
        }
        Relationships: []
      }
      maths_attempts: {
        Row: {
          allowance_day: string | null
          created_at: string
          id: string
          refunded: boolean
          user_id: string
        }
        Insert: {
          allowance_day?: string | null
          created_at?: string
          id: string
          refunded?: boolean
          user_id: string
        }
        Update: {
          allowance_day?: string | null
          created_at?: string
          id?: string
          refunded?: boolean
          user_id?: string
        }
        Relationships: []
      }
      suggestions: {
        Row: {
          category: string
          created_at: string
          id: string
          message: string
          rating: number
          user_id: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          message: string
          rating: number
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          message?: string
          rating?: number
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          credits_bought: number
          date: string
          id: string
          payment_method: string
          reference: string
          user_id: string
        }
        Insert: {
          amount: number
          credits_bought: number
          date?: string
          id?: string
          payment_method: string
          reference: string
          user_id: string
        }
        Update: {
          amount?: number
          credits_bought?: number
          date?: string
          id?: string
          payment_method?: string
          reference?: string
          user_id?: string
        }
        Relationships: []
      }
      usage_events: {
        Row: {
          created_at: string
          id: string
          kind: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          kind: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_security: {
        Row: {
          backup_codes: string[]
          created_at: string
          twofa_enabled: boolean
          user_id: string
        }
        Insert: {
          backup_codes?: string[]
          created_at?: string
          twofa_enabled?: boolean
          user_id: string
        }
        Update: {
          backup_codes?: string[]
          created_at?: string
          twofa_enabled?: boolean
          user_id?: string
        }
        Relationships: []
      }
      waitlist: {
        Row: {
          created_at: string
          email: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          created_at: string
          credits: number
          user_id: string
        }
        Insert: {
          created_at?: string
          credits?: number
          user_id: string
        }
        Update: {
          created_at?: string
          credits?: number
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_credits: { Args: { _n: number; _user_id: string }; Returns: number }
      begin_hair_tryon: { Args: { _request_id: string }; Returns: number }
      begin_hair_tryon_request: {
        Args: { _replay: boolean; _request_id: string }
        Returns: number
      }
      begin_maths_attempt: { Args: { _request_id: string }; Returns: number }
      claim_ad_reward: { Args: never; Returns: number }
      get_free_solves: { Args: never; Returns: number }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      parent_learning_stats: { Args: never; Returns: Json }
      refund_maths_attempt: {
        Args: { _request_id: string }
        Returns: undefined
      }
      set_twofa: {
        Args: { _codes: string[]; _enabled: boolean }
        Returns: undefined
      }
      spend_credit: { Args: { _feature: string }; Returns: number }
      use_backup_code: { Args: { _code: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
