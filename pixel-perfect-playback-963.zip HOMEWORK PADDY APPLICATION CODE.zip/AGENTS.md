<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Rules
- The root session boundary runs Gate before all signed-in pages; WelcomeOnce follows second-factor checks and stores per-user device-local completion, so welcome cannot precede login or repeat between features.
- Parent welcome uses bundled illustrations and Embla swipe navigation with browser speech; no uploaded photos, remote media, or wallet changes are involved.
- Maths lives in a dedicated module with authenticated streaming routes, strict declarative drawing data rendered on canvas, and server-side country-method prompts; this keeps uploads and executable AI output off the browser.
- Authored practice is browser-safe level-filtered data; viewing it never solves or adds history. Shared MathsSourceNote uses the captured solve method for live answers and saved history.
- Maths and homework share a Lagos-day allowance reserved with unique request IDs and refunded once through service-only SQL; historical purchased wallets are not consumed during free-for-now mode.
- Maths natural speech streams authenticated PCM audio in sentence-sized chunks; provider access denials persist in service-only ai_access_state to stop repeated blocked calls.
- Allowances change only in database functions; spend_credit uses daily_learning_allowance for solves and leaves hair/spelling free, preserving hair request/replay guards and historical wallets.
- Payments are verified server-side against the Paystack API before inserting a transaction (unique reference prevents double credit); Paystack is the only payment provider the app offers.
- The Paystack secret is read from PAYSTACK_SECRET_KEY first, falling back to a temporary named secret; when new keys arrive, save them as PAYSTACK_SECRET_KEY and delete the temporary one, so a key swap never touches code.
- Historical package prices stay in packages.ts; active free-for-now and disabled premium rules live in free-learning.ts with focused tests, and payment handlers refuse purchases while disabled.
- Hair try-on streams authenticated multipart edits through a server-only helper; prompts and photo handling stay off the browser's gateway calls.
- Hair attempts are charged atomically in the database with a unique request ID and at most one uncharged zero-event replay, preventing duplicate spending during stream recovery.
- Hair photos and generated results remain transient in the page and are never written to application storage.
- All pages use Header and shared AppLogo; TopBar is retired. Root ThemeChooser persists browser-local background via semantic tokens without changing learning or wallet state.
- Screen owns the shared fluid page width and safe wrapping; repeated content uses the responsive collection-grid utility so phone, tablet, and desktop layouts stay consistent.
- Onboarding choices (language, level, gender) and the saved location live in localStorage (ss_lang, ss_age, ss_gender, ss_loc, ss_name); the wallet and payments live server-side.
- The hairstyle catalog lives in src/lib/hair.ts: each style has a gender, a category (hair/beard), a naira price range and an AI prompt; beard prompts restrict the edit to the lower face. Male users get Hair Cut/Beard Style tabs; favorite cuts persist in localStorage (ss_favs).
- Barber/salon listings are deterministic dummy data in src/lib/barbers.ts (counts per state verified in barbers.test.ts); replace with a real table only when vendors actually sign up.
- Location uses browser geolocation plus a Nominatim reverse-geocode server function; the Leaflet map loads client-only via React.lazy + ClientOnly so SSR never touches it.
- 2FA is optional and user-controlled: state lives in public.user_security (enabled flag + SHA-256-hashed one-time backup codes, mutated only via set_twofa/use_backup_code DB functions); login second factor is Supabase email OTP (verifyOtp type 'email'), with TOTP authenticator as a bonus via supabase.auth.mfa. Gate.tsx enforces the code screen per tab session (sessionStorage marker).
- Feedback submissions go to the public.suggestions table via the submitSuggestion server function; never back to mailto.
- Style "see more varieties" links open Google Images in a new tab (Google blocks in-app iframes); the Inspiration Gallery uses curated AI-generated portraits bundled in src/assets, not hotlinked Unsplash/Google images (no working free API key). "Try this look" selects that style for the user's own uploaded photo — the AI cannot copy a style from a reference image.
- Content moderation is free and client-side (src/lib/moderation.ts): blocked word lists (sexual/fraud/insults, English + Pidgin), filename check, >70% skin-pixel heuristic, best-effort FaceDetector. Blocked attempts log reason+time only (never the image) to public.blocked_logs; 3 blocks trigger a 10-min cooldown in localStorage. Decline copy stays warm and respectful in all 5 languages.
- Smart search: /search page + home search bar; DuckDuckGo instant-answer API via searchWeb server fn (free, keyless, server-side because of CORS); Google/YouTube open in new tab (Google blocks iframes); "Today's Hair Tips" shows 3 topic cards, falling back to Google links when DDG has no instant answer.
- Age-band and Money Paddy lessons stay browser-local, free and separate from wallets; Money Paddy has five-language copy and tested sorting, budget and interest helpers.
- Assignment scanning uses an authenticated structured streaming route; the ordered reviewed questions are solved individually through the existing drawing/speech flow, with transient uploads and accumulated on-page answers.
- Scanned assignments enter a browser-local review stage before solving; confirmation validates corrected questions, and completed answers lock the reviewed list to preserve question-to-answer alignment.
- Solves save owner-readable photo-free history; parent stats use Lagos days. Shared browser-local rewards separate correct answers from homework counting; dancer gender is separate from hair gender, prior stars migrate, and image-backed Lottie loads behind ClientOnly.
